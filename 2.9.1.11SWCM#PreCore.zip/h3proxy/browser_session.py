from __future__ import annotations

import time
import hashlib
import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from .config import ServerConfig
from .dom_mapper import DomMapper
from .tile_engine import TileEngine, TilePacket


@dataclass
class FrameBundle:
    frame_id: int
    page_meta: dict[str, Any] | None
    dom_items: list[dict[str, Any]] | None
    tiles: list[TilePacket]
    capture_ms: int
    loading: bool
    dom_changed: bool


@dataclass
class MediaStreamState:
    media_id: str
    dom_id: int
    kind: str
    x: int
    y: int
    w: int
    h: int
    fps: float
    jpeg_quality: int

    def rect(self) -> dict[str, int]:
        return {"x": self.x, "y": self.y, "w": self.w, "h": self.h}

    def as_message(self) -> dict[str, Any]:
        return {
            "media_id": self.media_id,
            "dom_id": self.dom_id,
            "kind": self.kind,
            "x": self.x,
            "y": self.y,
            "w": self.w,
            "h": self.h,
            "format": "jpeg",
            "target_fps": self.fps,
            "jpeg_quality": self.jpeg_quality,
        }


@dataclass
class MediaFrameBundle:
    header: dict[str, Any]
    payload: bytes
    capture_ms: int


@dataclass
class ClientRuntimePolicy:
    profile: str = "unknown"
    calibrated: bool = False
    max_page_fps: float = 10.0
    max_media_fps: float = 15.0
    safe_ram_bytes: int = 0
    safe_texture_cache_tiles: int = 96
    decode_jpeg_400x225_ms_p95: float = 0.0
    decode_png_tile_ms_p95: float = 0.0
    sd_write_mb_s: float = 0.0
    network_recv_kb_s: float = 0.0


@dataclass
class ClientRuntimeStats:
    decode_ms_p95: float = 0.0
    queue_bytes: int = 0
    dropped_frames: int = 0
    vram_used_bytes: int = 0
    ram_used_bytes: int = 0
    media_decode_ms_p95: float = 0.0
    tile_decode_ms_p95: float = 0.0
    last_update_at: float = 0.0


class BrowserSession:
    def __init__(self, token: str, config: ServerConfig) -> None:
        self.token = token
        self.config = config
        self.viewport = dict(config.viewport)
        self.quality = "normal"
        self.created_at = time.monotonic()
        self.last_used_at = self.created_at

        self._playwright: Any = None
        self._browser: Any = None
        self._context: Any = None
        self.page: Any = None

        self.tile_engine = TileEngine(config.tile_width, config.tile_height, config.jpeg_quality)
        self.dom_mapper = DomMapper()
        self.previous_tile_hashes: dict[str, str] = {}
        self.latest_dom_items: list[dict[str, Any]] = []
        self._last_dom_signature = ""
        self.frame_id = 0
        self.media_frame_id = 0
        self.active_media: MediaStreamState | None = None
        self.client_policy = ClientRuntimePolicy(
            max_page_fps=min(config.animation_fps, config.protocol_max_fps),
            max_media_fps=min(config.media_fps, config.protocol_max_fps),
        )
        self.client_stats = ClientRuntimeStats()

    @property
    def expired(self) -> bool:
        return (time.monotonic() - self.last_used_at) > self.config.session_ttl_seconds

    async def start(self) -> None:
        self.touch()
        if self.page is not None:
            return
        try:
            from playwright.async_api import async_playwright
        except Exception as exc:
            raise RuntimeError(
                "Playwright is not installed. Install requirements in the active venv, "
                "then run: python -m playwright install firefox"
            ) from exc

        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.firefox.launch(headless=self.config.headless)
        self._context = await self._browser.new_context(
            viewport=self.viewport,
            ignore_https_errors=False,
            accept_downloads=False,
        )
        self.page = await self._context.new_page()
        self.page.set_default_timeout(self.config.browser_timeout_ms)
        await self.page.goto("about:blank")

    async def close(self) -> None:
        for obj in (self._context, self._browser):
            if obj is not None:
                try:
                    await obj.close()
                except Exception:
                    pass
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception:
                pass
        self._playwright = None
        self._browser = None
        self._context = None
        self.page = None

    def touch(self) -> None:
        self.last_used_at = time.monotonic()

    async def open_url(self, url: str) -> None:
        await self.start()
        self.touch()
        self.stop_media()
        assert self.page is not None
        await self.page.goto(self._normalize_url(url), wait_until="domcontentloaded")

    async def capture_frame(
        self,
        *,
        include_page_meta: bool = True,
        include_dom: bool = True,
        suppress_tile_rects: list[dict[str, int]] | None = None,
    ) -> FrameBundle:
        await self.start()
        self.touch()
        assert self.page is not None
        self.frame_id += 1
        started_at = time.monotonic()

        loading = await self._is_loading() if (include_page_meta or include_dom) else False
        screenshot = await self.page.screenshot(type="png", full_page=False)
        tiles = self.tile_engine.build_changed_tiles(
            screenshot,
            self.previous_tile_hashes,
            self.frame_id,
            self.quality,
            suppress_rects=suppress_tile_rects,
        )
        dom_items: list[dict[str, Any]] | None = None
        dom_changed = False
        if include_dom:
            dom_items = await self.dom_mapper.extract(self.page, self.viewport)
            dom_signature = self._dom_signature(dom_items)
            dom_changed = bool(self._last_dom_signature and dom_signature != self._last_dom_signature)
            self._last_dom_signature = dom_signature
            self.latest_dom_items = dom_items

        title = await self.page.title() if include_page_meta else ""
        capture_ms = int((time.monotonic() - started_at) * 1000)
        page_meta = None
        if include_page_meta:
            page_meta = {
                "type": "page_meta",
                "frame_id": self.frame_id,
                "url": self.page.url,
                "title": title,
                "loading": loading,
                "dom_changed": dom_changed,
                "viewport": self.viewport,
                "quality": self.quality,
            }

        return FrameBundle(
            frame_id=self.frame_id,
            page_meta=page_meta,
            dom_items=dom_items,
            tiles=tiles,
            capture_ms=capture_ms,
            loading=loading,
            dom_changed=dom_changed,
        )

    async def click(self, x: int, y: int) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.mouse.click(x, y)

    async def touch_down(self, x: int, y: int, button: str = "left") -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.mouse.move(x, y)
        await self.page.mouse.down(button=button)

    async def touch_move(self, x: int, y: int) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.mouse.move(x, y)

    async def touch_up(self, x: int, y: int, button: str = "left") -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.mouse.move(x, y)
        await self.page.mouse.up(button=button)

    async def scroll(self, dx: int, dy: int) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.mouse.wheel(dx, dy)

    async def press_key(self, key: str) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.keyboard.press(key)

    async def key_down(self, key: str) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.keyboard.down(key)

    async def key_up(self, key: str) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.keyboard.up(key)

    async def type_text(self, text: str) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.keyboard.type(text)

    async def back(self) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.go_back(wait_until="domcontentloaded")

    async def forward(self) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.go_forward(wait_until="domcontentloaded")

    async def reload(self) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.reload(wait_until="domcontentloaded")

    async def stop(self) -> None:
        await self.start()
        self.touch()
        assert self.page is not None
        await self.page.evaluate("() => window.stop()")

    async def set_viewport(self, width: int, height: int) -> None:
        await self.start()
        self.touch()
        self.stop_media()
        assert self.page is not None
        self.viewport = {"width": int(width), "height": int(height)}
        self.previous_tile_hashes.clear()
        await self.page.set_viewport_size(self.viewport)

    def set_quality(self, quality: str) -> None:
        self.touch()
        self.quality = quality.strip().lower() or "normal"
        self.previous_tile_hashes.clear()

    @property
    def media_stream_active(self) -> bool:
        return self.active_media is not None

    def active_media_rects(self) -> list[dict[str, int]]:
        if self.active_media is None:
            return []
        return [self.active_media.rect()]

    async def start_media(
        self,
        *,
        media_id: str | None = None,
        dom_id: int | None = None,
        fps: float | None = None,
        jpeg_quality: int | None = None,
    ) -> dict[str, Any] | None:
        await self.start()
        self.touch()
        assert self.page is not None
        if not self.latest_dom_items:
            self.latest_dom_items = await self.dom_mapper.extract(self.page, self.viewport)

        item = self._find_media_item(media_id=media_id, dom_id=dom_id)
        if item is None:
            return None

        state = self._media_state_from_item(
            item,
            fps=fps if fps is not None else self.client_policy.max_media_fps,
            jpeg_quality=jpeg_quality if jpeg_quality is not None else self.config.jpeg_quality,
        )
        self.active_media = state
        return state.as_message()

    def stop_media(self) -> dict[str, Any] | None:
        previous = self.active_media
        self.active_media = None
        if previous is None:
            return None
        return previous.as_message()

    async def capture_media_frame(self) -> MediaFrameBundle | None:
        await self.start()
        self.touch()
        assert self.page is not None
        if self.active_media is None:
            return None

        refreshed = self._find_media_item(media_id=self.active_media.media_id, dom_id=self.active_media.dom_id)
        if refreshed is not None:
            self.active_media = self._media_state_from_item(
                refreshed,
                fps=self.active_media.fps,
                jpeg_quality=self.active_media.jpeg_quality,
            )

        state = self.active_media
        if state is None or state.w <= 1 or state.h <= 1:
            self.stop_media()
            return None

        self.media_frame_id += 1
        started_at = time.monotonic()
        payload = await self.page.screenshot(
            type="jpeg",
            quality=state.jpeg_quality,
            clip={
                "x": state.x,
                "y": state.y,
                "width": state.w,
                "height": state.h,
            },
        )
        capture_ms = int((time.monotonic() - started_at) * 1000)
        header = {
            "type": "media_frame",
            "frame_id": self.media_frame_id,
            "page_frame_id": self.frame_id,
            "media_id": state.media_id,
            "dom_id": state.dom_id,
            "kind": state.kind,
            "x": state.x,
            "y": state.y,
            "w": state.w,
            "h": state.h,
            "format": "jpeg",
            "payload_len": len(payload),
            "capture_ms": capture_ms,
        }
        return MediaFrameBundle(header=header, payload=payload, capture_ms=capture_ms)

    def update_client_caps(self, payload: dict[str, Any]) -> dict[str, Any]:
        profile = str(payload.get("profile", self.client_policy.profile) or "unknown")
        self.client_policy = ClientRuntimePolicy(
            profile=profile,
            calibrated=bool(payload.get("calibrated", False)),
            max_page_fps=self._clamp_fps(payload.get("max_page_fps"), self.client_policy.max_page_fps),
            max_media_fps=self._clamp_fps(payload.get("max_media_fps"), self.client_policy.max_media_fps),
            safe_ram_bytes=max(0, int(payload.get("safe_ram_bytes", self.client_policy.safe_ram_bytes) or 0)),
            safe_texture_cache_tiles=max(
                1,
                int(payload.get("safe_texture_cache_tiles", self.client_policy.safe_texture_cache_tiles) or 1),
            ),
            decode_jpeg_400x225_ms_p95=max(
                0.0,
                float(payload.get("decode_jpeg_400x225_ms_p95", self.client_policy.decode_jpeg_400x225_ms_p95) or 0.0),
            ),
            decode_png_tile_ms_p95=max(
                0.0,
                float(payload.get("decode_png_tile_ms_p95", self.client_policy.decode_png_tile_ms_p95) or 0.0),
            ),
            sd_write_mb_s=max(0.0, float(payload.get("sd_write_mb_s", self.client_policy.sd_write_mb_s) or 0.0)),
            network_recv_kb_s=max(
                0.0,
                float(payload.get("network_recv_kb_s", self.client_policy.network_recv_kb_s) or 0.0),
            ),
        )
        if self.active_media is not None:
            self.active_media.fps = min(self.active_media.fps, self.effective_media_fps())
        return self.client_policy_message()

    def update_client_stats(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.client_stats = ClientRuntimeStats(
            decode_ms_p95=max(0.0, float(payload.get("decode_ms_p95", self.client_stats.decode_ms_p95) or 0.0)),
            queue_bytes=max(0, int(payload.get("queue_bytes", self.client_stats.queue_bytes) or 0)),
            dropped_frames=max(0, int(payload.get("dropped_frames", self.client_stats.dropped_frames) or 0)),
            vram_used_bytes=max(0, int(payload.get("vram_used_bytes", self.client_stats.vram_used_bytes) or 0)),
            ram_used_bytes=max(0, int(payload.get("ram_used_bytes", self.client_stats.ram_used_bytes) or 0)),
            media_decode_ms_p95=max(
                0.0,
                float(payload.get("media_decode_ms_p95", self.client_stats.media_decode_ms_p95) or 0.0),
            ),
            tile_decode_ms_p95=max(
                0.0,
                float(payload.get("tile_decode_ms_p95", self.client_stats.tile_decode_ms_p95) or 0.0),
            ),
            last_update_at=time.monotonic(),
        )
        if self.active_media is not None:
            self.active_media.fps = min(self.active_media.fps, self.effective_media_fps())
        return self.client_stats_message()

    def client_policy_message(self) -> dict[str, Any]:
        return {
            "profile": self.client_policy.profile,
            "calibrated": self.client_policy.calibrated,
            "max_page_fps": self.client_policy.max_page_fps,
            "max_media_fps": self.client_policy.max_media_fps,
            "safe_ram_bytes": self.client_policy.safe_ram_bytes,
            "safe_texture_cache_tiles": self.client_policy.safe_texture_cache_tiles,
            "decode_jpeg_400x225_ms_p95": self.client_policy.decode_jpeg_400x225_ms_p95,
            "decode_png_tile_ms_p95": self.client_policy.decode_png_tile_ms_p95,
            "sd_write_mb_s": self.client_policy.sd_write_mb_s,
            "network_recv_kb_s": self.client_policy.network_recv_kb_s,
            "effective_page_fps": self.effective_page_fps(),
            "effective_media_fps": self.effective_media_fps(),
        }

    def client_stats_message(self) -> dict[str, Any]:
        return {
            "decode_ms_p95": self.client_stats.decode_ms_p95,
            "queue_bytes": self.client_stats.queue_bytes,
            "dropped_frames": self.client_stats.dropped_frames,
            "vram_used_bytes": self.client_stats.vram_used_bytes,
            "ram_used_bytes": self.client_stats.ram_used_bytes,
            "media_decode_ms_p95": self.client_stats.media_decode_ms_p95,
            "tile_decode_ms_p95": self.client_stats.tile_decode_ms_p95,
            "effective_page_fps": self.effective_page_fps(),
            "effective_media_fps": self.effective_media_fps(),
        }

    def snapshot(self) -> dict[str, Any]:
        now = time.monotonic()
        return {
            "token": self.token,
            "age_seconds": round(now - self.created_at, 3),
            "idle_seconds": round(now - self.last_used_at, 3),
            "started": self.page is not None,
            "url": self.page.url if self.page is not None else "about:blank",
            "viewport": self.viewport,
            "quality": self.quality,
            "frame_id": self.frame_id,
            "media_frame_id": self.media_frame_id,
            "active_media": self.active_media.as_message() if self.active_media is not None else None,
            "client_policy": self.client_policy_message(),
            "client_stats": self.client_stats_message(),
        }

    def effective_page_fps(self) -> float:
        fps = min(self.client_policy.max_page_fps, self.config.protocol_max_fps)
        if self.client_stats.queue_bytes > 2 * 1024 * 1024 or self.client_stats.dropped_frames:
            fps = min(fps, 6.0)
        if self.client_stats.queue_bytes > 4 * 1024 * 1024:
            fps = min(fps, 3.0)
        if self.client_stats.tile_decode_ms_p95 >= 16:
            fps = min(fps, max(3.0, 1000.0 / (self.client_stats.tile_decode_ms_p95 * 1.35)))
        if self.client_stats.tile_decode_ms_p95 >= 80:
            fps = min(fps, 5.0)
        return max(0.2, fps)

    def effective_media_fps(self) -> float:
        fps = min(self.client_policy.max_media_fps, self.config.protocol_max_fps)
        if self.client_stats.queue_bytes > 2 * 1024 * 1024 or self.client_stats.dropped_frames:
            fps = min(fps, 15.0)
        if self.client_stats.queue_bytes > 4 * 1024 * 1024:
            fps = min(fps, 8.0)
        if self.client_stats.media_decode_ms_p95 >= 12:
            fps = min(fps, max(6.0, 1000.0 / (self.client_stats.media_decode_ms_p95 * 1.35)))
        if self.client_stats.media_decode_ms_p95 >= 80 or self.client_stats.decode_ms_p95 >= 80:
            fps = min(fps, 8.0)
        return max(1.0, fps)

    async def activate_dom_id(self, dom_id: int) -> bool:
        item = next((entry for entry in self.latest_dom_items if int(entry.get("id", -1)) == dom_id), None)
        if item is None:
            return False
        await self.click(int(item["x"]) + int(item["w"]) // 2, int(item["y"]) + int(item["h"]) // 2)
        return True

    async def focus_dom_id(self, dom_id: int) -> bool:
        item = next((entry for entry in self.latest_dom_items if int(entry.get("id", -1)) == dom_id), None)
        if item is None:
            return False
        await self.click(int(item["x"]) + int(item["w"]) // 2, int(item["y"]) + int(item["h"]) // 2)
        return True

    def _find_media_item(self, *, media_id: str | None = None, dom_id: int | None = None) -> dict[str, Any] | None:
        resolved_dom_id = dom_id
        if resolved_dom_id is None and media_id and media_id.startswith("m"):
            try:
                resolved_dom_id = int(media_id[1:])
            except ValueError:
                resolved_dom_id = None

        candidates = [
            item
            for item in self.latest_dom_items
            if item.get("kind") in {"video", "canvas"}
        ]
        if resolved_dom_id is not None:
            return next((item for item in candidates if int(item.get("id", -1)) == resolved_dom_id), None)
        return candidates[0] if candidates else None

    def _media_state_from_item(self, item: dict[str, Any], *, fps: float, jpeg_quality: int) -> MediaStreamState:
        x = int(item.get("x", 0))
        y = int(item.get("y", 0))
        w = int(item.get("w", 0))
        h = int(item.get("h", 0))
        viewport_w = int(self.viewport["width"])
        viewport_h = int(self.viewport["height"])
        x = max(0, min(viewport_w - 1, x))
        y = max(0, min(viewport_h - 1, y))
        w = max(1, min(viewport_w - x, w))
        h = max(1, min(viewport_h - y, h))
        dom_id = int(item["id"])
        return MediaStreamState(
            media_id=f"m{dom_id}",
            dom_id=dom_id,
            kind=str(item.get("kind", "video")),
            x=x,
            y=y,
            w=w,
            h=h,
            fps=max(1.0, min(self.config.protocol_max_fps, self.effective_media_fps(), float(fps))),
            jpeg_quality=max(20, min(95, int(jpeg_quality))),
        )

    def _clamp_fps(self, value: Any, fallback: float) -> float:
        try:
            fps = float(value)
        except (TypeError, ValueError):
            fps = fallback
        return max(0.2, min(self.config.protocol_max_fps, fps))

    def _normalize_url(self, url: str) -> str:
        cleaned = url.strip()
        if not cleaned:
            return "about:blank"
        parsed = urlparse(cleaned)
        if parsed.scheme in {"http", "https", "about"}:
            return cleaned
        if parsed.scheme:
            raise ValueError(f"URL scheme is not allowed: {parsed.scheme}")
        return f"https://{cleaned}"

    async def _is_loading(self) -> bool:
        assert self.page is not None
        try:
            ready_state = await self.page.evaluate("() => document.readyState")
            return ready_state != "complete"
        except Exception:
            return True

    def _dom_signature(self, dom_items: list[dict[str, Any]]) -> str:
        compact_items = [
            {
                "kind": item.get("kind"),
                "x": item.get("x"),
                "y": item.get("y"),
                "w": item.get("w"),
                "h": item.get("h"),
                "text": item.get("text"),
                "href": item.get("href"),
                "focused": item.get("focused"),
            }
            for item in dom_items
        ]
        payload = json.dumps(compact_items, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        return hashlib.blake2s(payload.encode("utf-8"), digest_size=8).hexdigest()
