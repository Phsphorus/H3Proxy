#pragma once

#include <3ds.h>
#include <stdbool.h>
#include <stdint.h>

#define H3P_UI_URL_BYTES 256
#define H3P_UI_TITLE_BYTES 128
#define H3P_UI_STATUS_BYTES 128

typedef enum {
    H3P_UI_PAGE = 0,
    H3P_UI_URL_ENTRY,
    H3P_UI_SOFTWARE_KEYBOARD,
    H3P_UI_MENU,
    H3P_UI_MEDIA,
    H3P_UI_DEBUG,
} H3PUIMode;

typedef struct {
    H3PUIMode mode;
    char url[H3P_UI_URL_BYTES];
    char title[H3P_UI_TITLE_BYTES];
    char status[H3P_UI_STATUS_BYTES];
    int selected_dom_id;
    int dom_count;
    bool connected;
    bool loading;
    bool debug_overlay;
    bool webview_on_bottom;
} H3PUIState;

void h3p_ui_set_consoles(PrintConsole *top, PrintConsole *bottom);
void h3p_ui_init(H3PUIState *ui);
void h3p_ui_set_status(H3PUIState *ui, const char *status);
void h3p_ui_draw_top_debug(const H3PUIState *ui);
void h3p_ui_draw_bottom(const H3PUIState *ui);
