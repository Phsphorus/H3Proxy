#include "input.h"

#define CIRCLE_DEADZONE 14

static int abs_i(int value) {
    return value < 0 ? -value : value;
}

void h3p_input_init(H3PInputState *state) {
    if (!state) {
        return;
    }
    state->touching = false;
    state->page_touching = false;
    state->last_touch.px = 0;
    state->last_touch.py = 0;
    state->last_browser_touch.px = 0;
    state->last_browser_touch.py = 0;
    state->last_circle.dx = 0;
    state->last_circle.dy = 0;
}

static void push_event(H3PInputEvent *events, int max_events, int *count, H3PInputEvent event) {
    if (*count >= max_events) {
        return;
    }
    events[*count] = event;
    *count += 1;
}

int h3p_input_poll(H3PInputState *state, H3PInputEvent *events, int max_events) {
    if (!state || !events || max_events <= 0) {
        return 0;
    }

    int count = 0;
    u32 down = hidKeysDown();
    u32 held = hidKeysHeld();
    u32 up = hidKeysUp();

    if (down & KEY_L) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_BACK });
    }
    if (down & KEY_R) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_FORWARD });
    }
    if (down & KEY_ZL) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_RELOAD });
    }
    if (down & KEY_A) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_ENTER });
    }
    if (down & KEY_B) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_DESELECT });
    }
    if (down & KEY_X) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_DOCK_WEBVIEW_TOP });
    }
    if (down & KEY_Y) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_DOCK_WEBVIEW_BOTTOM });
    }
    if (down & KEY_SELECT) {
        push_event(events, max_events, &count, (H3PInputEvent){ .kind = H3P_INPUT_DEBUG_TOGGLE });
    }

    circlePosition circle;
    hidCircleRead(&circle);
    state->last_circle = circle;
    if (abs_i(circle.dx) > CIRCLE_DEADZONE || abs_i(circle.dy) > CIRCLE_DEADZONE) {
        push_event(events, max_events, &count, (H3PInputEvent){
            .kind = H3P_INPUT_SCROLL,
            .dx = circle.dx / 3,
            .dy = -circle.dy / 3,
        });
    }

    touchPosition touch;
    hidTouchRead(&touch);
    int page_touch_y = touch.py;
    if (page_touch_y >= H3P_PAGE_PAD_H) {
        page_touch_y = H3P_PAGE_PAD_H - 1;
    }
    touchPosition browser_touch = {
        .px = (u16)((int)touch.px * H3P_BROWSER_W / H3P_3DS_TOUCH_W),
        .py = (u16)(page_touch_y * H3P_BROWSER_H / H3P_PAGE_PAD_H),
    };
    bool in_page_pad = touch.py < H3P_PAGE_PAD_H;
    if ((down & KEY_TOUCH) && !state->touching) {
        state->touching = true;
        state->last_touch = touch;
        state->last_browser_touch = browser_touch;
        if (in_page_pad) {
            state->page_touching = true;
            push_event(events, max_events, &count, (H3PInputEvent){
                .kind = H3P_INPUT_TOUCH_DOWN,
                .x = browser_touch.px,
                .y = browser_touch.py,
            });
        } else {
            state->page_touching = false;
            push_event(events, max_events, &count, (H3PInputEvent){
                .kind = H3P_INPUT_DOCK_TOUCH,
                .x = touch.px,
                .y = touch.py,
            });
        }
    } else if ((held & KEY_TOUCH) && state->touching) {
        state->last_touch = touch;
        state->last_browser_touch = browser_touch;
        if (state->page_touching && in_page_pad) {
            push_event(events, max_events, &count, (H3PInputEvent){
                .kind = H3P_INPUT_TOUCH_MOVE,
                .x = browser_touch.px,
                .y = browser_touch.py,
            });
        }
    } else if ((up & KEY_TOUCH) && state->touching) {
        bool page_touching = state->page_touching;
        state->touching = false;
        state->page_touching = false;
        if (page_touching) {
            push_event(events, max_events, &count, (H3PInputEvent){
                .kind = H3P_INPUT_TOUCH_UP,
                .x = state->last_browser_touch.px,
                .y = state->last_browser_touch.py,
            });
        }
    }

    return count;
}
