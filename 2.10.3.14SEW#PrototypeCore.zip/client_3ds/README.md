# H3Proxy 3DS Client

This is the real client target: a devkitPro/libctru `.3dsx` homebrew app.

The PC simulator under `tools/pc_simulator.py` is a protocol harness, not the
project goal. This tree is where the hardware-shaped renderer, input mapping,
tile cache, PNG/JPEG decode path, and bottom-screen browser UI belong.

## Initial Decode And Render Plan

Server tile payload:

```text
PNG/JPEG payload -> stb_image decode -> RGB888/RGBA8888 -> texture upload
```

Server media payload:

```text
media_frame JPEG payload -> stb_image decode -> RGB888 -> RGB565 media texture
```

Initial texture policy:

- webpage tiles: RGB565
- MJPEG frames: RGB565
- UI/cursor/highlight overlays: RGBA8 when alpha is needed

Binary WebSocket frames share one transport:

- `tile`: page tile update
- `media_frame`: MJPEG-style JPEG frame for the active media rectangle

## Launch Calibration

The 3DS client has a safe calibration skeleton in `source/system/calibration.c`.
It does not intentionally crash or freeze the device. It probes allocatable RAM,
writes and deletes a capped SD probe file, estimates tile/media conversion cost,
and builds the `client_caps` JSON payload the server uses for per-device FPS and
cache policy.

The current skeleton displays the measured page/media FPS caps on launch. Once
WebSocket transport lands, that same profile should be sent to the server before
opening pages.

## Hardware Debug Logging

The current hardware test build draws a temporary debug console on both screens
and writes the same runtime stream to:

```text
sdmc:/h3proxy.log
```

Boot, calibration, input events, status changes, and shutdown are logged. The
top screen shows the page framebuffer once tiles or media frames arrive. Until
then the debug console stays visible so connection and protocol failures are not
silent.

## Hardware Config And Pairing

On launch the client now has two pre-boot stages:

1. hardware calibration
2. pre-connection pairing

The pairing screen lets the user select a server IP and port on the 3DS before
the WebSocket connection starts. D-Pad Up/Down changes between `10.0.0.0/8`,
`172.16.0.0/12`, and `192.168.0.0/16`; D-Pad Left/Right selects the editable
field; A increments; B decrements; X tests and pairs. Failed connection tests
return to the pairing screen.

The selected server is saved to:

```text
sdmc:/h3proxy.cfg
```

Manual SD editing still works:

```text
server=http://192.168.1.100:8766
start_url=/start
quality=normal
token=
```

Leaving `token` blank is preferred for normal testing; the 3DS will create a
fresh server session with `POST /sessions`, then connect to the returned
WebSocket path. `start_url` may be a full URL or a server-relative path such as
`/debug/media`.

Runtime controls:

- L/R: browser back/forward
- ZL: reload
- A: Enter
- B: deselect/Escape
- X: keep the page on the top display
- Y: mirror the page into the bottom touch area
- SELECT: debug/log overlay
- bottom dock: URL/Go, DOM selector/activate, quality cycle

`third_party/stb_image.h` is vendored from the public-domain/MIT `nothings/stb`
project to keep the first client build dependency-light.

## Build Target

Expected toolchain:

- devkitPro
- devkitARM
- libctru

Typical build after devkitPro is installed:

```powershell
.\tools\build_3ds.cmd
```

Or from inside `client_3ds` with MSYS-style devkitPro paths:

```bash
export DEVKITPRO=/d/db/Software/Codex/H3Proxy/Deps/devkitPro
export DEVKITARM=$DEVKITPRO/devkitARM
make
```

The first skeleton only initializes the 3DS app loop, renderer stubs, and image
decode/conversion helpers. WebSocket transport and full tile compositing are the
next client milestones.

## Network Policy

Trusted LAN/debug mode may use:

```text
ws://server-ip:8765/ws/token
```

Remote or untrusted-network mode must use encrypted transport. The architecture
must not depend on a VPN client running on the 3DS.
