#pragma once

#include <3ds.h>
#include <stdbool.h>

#include "config_store.h"
#include "net_client.h"

bool h3p_connection_setup_run(
    H3PClientConfig *config,
    H3PNetClient *net,
    const char *caps_json,
    PrintConsole *top_console,
    PrintConsole *bottom_console
);
