#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct {
    int width;
    int height;
    uint16_t *rgb565;
} H3PDecodedImage;

int h3p_decode_image_rgb565(const uint8_t *payload, size_t payload_len, H3PDecodedImage *out);
void h3p_free_decoded_image(H3PDecodedImage *image);
