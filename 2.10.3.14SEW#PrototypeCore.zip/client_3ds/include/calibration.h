#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define H3P_PROFILE_NAME_BYTES 32

typedef struct {
    char profile[H3P_PROFILE_NAME_BYTES];
    bool calibrated;
    uint32_t max_page_fps;
    uint32_t max_media_fps;
    uint32_t safe_ram_bytes;
    uint32_t aggressive_ram_bytes;
    uint32_t safe_texture_cache_tiles;
    uint32_t decode_jpeg_400x225_ms_p95;
    uint32_t decode_png_tile_ms_p95;
    uint32_t sd_write_kb_s;
    uint32_t network_recv_kb_s;
} H3PCalibratedProfile;

void h3p_calibration_defaults(H3PCalibratedProfile *profile);
void h3p_calibration_run_safe(H3PCalibratedProfile *profile);
int h3p_calibration_client_caps_json(const H3PCalibratedProfile *profile, char *out, size_t out_len);
