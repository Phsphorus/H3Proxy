#pragma once

#include <stdbool.h>
#include <stddef.h>

#define H3P_SERVER_URL_BYTES 256
#define H3P_TOKEN_BYTES 128
#define H3P_START_URL_BYTES 256
#define H3P_QUALITY_BYTES 16

typedef struct {
    char server_url[H3P_SERVER_URL_BYTES];
    char token[H3P_TOKEN_BYTES];
    char start_url[H3P_START_URL_BYTES];
    char quality[H3P_QUALITY_BYTES];
} H3PClientConfig;

void h3p_config_defaults(H3PClientConfig *config);
bool h3p_config_load(H3PClientConfig *config);
bool h3p_config_save(const H3PClientConfig *config);
const char *h3p_config_path(void);
void h3p_config_resolve_start_url(const H3PClientConfig *config, char *out, size_t out_len);
