#pragma once

#include <3ds.h>
#include <stdbool.h>
#include <stdint.h>

#define H3P_3DS_TOUCH_W 320
#define H3P_3DS_TOUCH_H 240
#define H3P_BOTTOM_DOCK_H 60
#define H3P_PAGE_PAD_H (H3P_3DS_TOUCH_H - H3P_BOTTOM_DOCK_H)
#define H3P_BROWSER_W 400
#define H3P_BROWSER_H 240

typedef enum {
    H3P_INPUT_NONE = 0,
    H3P_INPUT_BACK,
    H3P_INPUT_FORWARD,
    H3P_INPUT_RELOAD,
    H3P_INPUT_ENTER,
    H3P_INPUT_DESELECT,
    H3P_INPUT_DOCK_WEBVIEW_TOP,
    H3P_INPUT_DOCK_WEBVIEW_BOTTOM,
    H3P_INPUT_SCROLL,
    H3P_INPUT_TOUCH_DOWN,
    H3P_INPUT_TOUCH_MOVE,
    H3P_INPUT_TOUCH_UP,
    H3P_INPUT_DOCK_TOUCH,
    H3P_INPUT_SELECT,
} H3PInputKind;

typedef struct {
    H3PInputKind kind;
    int x;
    int y;
    int dx;
    int dy;
} H3PInputEvent;

typedef struct {
    bool touching;
    bool page_touching;
    touchPosition last_touch;
    touchPosition last_browser_touch;
    circlePosition last_circle;
    u64 last_scroll_at;
} H3PInputState;

void h3p_input_init(H3PInputState *state);
int h3p_input_poll(H3PInputState *state, H3PInputEvent *events, int max_events);
