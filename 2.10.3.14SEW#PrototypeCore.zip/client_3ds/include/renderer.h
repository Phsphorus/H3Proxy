#pragma once

#include <3ds.h>
#include <stdbool.h>
#include <stdint.h>

#define H3P_SCREEN_W 400
#define H3P_SCREEN_H 240
#define H3P_TILE_W 100
#define H3P_TILE_H 60
#define H3P_TILE_COLS 4
#define H3P_TILE_ROWS 4

typedef struct {
    int x;
    int y;
    int w;
    int h;
    uint16_t pixels[H3P_TILE_W * H3P_TILE_H];
    bool valid;
} H3PTileTexture;

void h3p_renderer_init(void);
void h3p_renderer_shutdown(void);
void h3p_renderer_begin_frame(void);
void h3p_renderer_draw_tile(const H3PTileTexture *tile);
void h3p_renderer_draw_image_rgb565(int x, int y, int w, int h, const uint16_t *pixels, int source_w, int source_h);
void h3p_renderer_clear(uint16_t color);
bool h3p_renderer_has_content(void);
void h3p_renderer_set_bottom_mirror(bool enabled);
void h3p_renderer_set_bottom_ui(bool enabled, bool mirror_page);
void h3p_renderer_set_bottom_info(const char *url_text, const char *web_text, unsigned int fps_x10);
void h3p_renderer_present_error(const char *code, const char *detail, const char *url, const char *title, bool fatal);
void h3p_renderer_end_frame(void);
