#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define H3P_HEADER_PREFIX_BYTES 4
#define H3P_MAX_HEADER_BYTES 4096
#define H3P_TILE_ID_BYTES 16
#define H3P_MEDIA_ID_BYTES 16

typedef struct {
    uint32_t header_len;
    const uint8_t *header_json;
    size_t payload_offset;
    size_t payload_len;
} H3PBinaryFrame;

typedef struct {
    uint32_t frame_id;
    char tile_id[H3P_TILE_ID_BYTES];
    int x;
    int y;
    int w;
    int h;
    char format[8];
    const uint8_t *payload;
    size_t payload_len;
} H3PTilePacket;

typedef struct {
    uint32_t frame_id;
    uint32_t page_frame_id;
    char media_id[H3P_MEDIA_ID_BYTES];
    int dom_id;
    int x;
    int y;
    int w;
    int h;
    char format[8];
    const uint8_t *payload;
    size_t payload_len;
} H3PMediaFramePacket;

bool h3p_parse_binary_frame(const uint8_t *data, size_t len, H3PBinaryFrame *out);
bool h3p_parse_tile_packet(const H3PBinaryFrame *frame, H3PTilePacket *out);
bool h3p_parse_media_frame_packet(const H3PBinaryFrame *frame, H3PMediaFramePacket *out);
bool h3p_json_get_type(const char *json, char *out, size_t out_len);
bool h3p_json_get_string(const char *json, const char *key, char *out, size_t out_len);
bool h3p_json_get_int(const char *json, const char *key, int *out);
