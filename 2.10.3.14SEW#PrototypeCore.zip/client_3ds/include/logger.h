#pragma once

#include <stdbool.h>
#include <stddef.h>

#define H3P_LOG_RING_LINES 18
#define H3P_LOG_LINE_BYTES 768
#define H3P_LOG_MESSAGE_BYTES 704

bool h3p_log_init(void);
void h3p_log_close(void);
void h3p_log_printf(const char *level, const char *fmt, ...);
int h3p_log_recent_count(void);
const char *h3p_log_recent_line(int index);
const char *h3p_log_path(void);
bool h3p_log_file_ready(void);
