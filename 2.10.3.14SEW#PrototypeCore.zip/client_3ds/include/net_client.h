#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "config_store.h"

#define H3P_NET_TEXT_BYTES 8192
#define H3P_NET_RX_BYTES (1024 * 1024)
#define H3P_NET_MESSAGE_BYTES (1024 * 1024)

typedef enum {
    H3P_NET_MESSAGE_NONE = 0,
    H3P_NET_MESSAGE_TEXT,
    H3P_NET_MESSAGE_BINARY,
    H3P_NET_MESSAGE_CLOSED,
    H3P_NET_MESSAGE_ERROR,
} H3PNetMessageKind;

typedef struct {
    H3PNetMessageKind kind;
    const uint8_t *data;
    size_t len;
    const char *text;
} H3PNetMessage;

typedef struct {
    bool soc_ready;
    bool connected;
    int sock;
    char websocket_url[512];
    char last_error[192];
    uint8_t *rx;
    size_t rx_len;
    size_t rx_cap;
    uint8_t *message;
    size_t message_len;
    size_t message_cap;
} H3PNetClient;

bool h3p_net_init(H3PNetClient *client);
void h3p_net_shutdown(H3PNetClient *client);
bool h3p_net_connect(H3PNetClient *client, const H3PClientConfig *config, const char *caps_json, const char *start_url);
void h3p_net_close(H3PNetClient *client);
int h3p_net_poll(H3PNetClient *client, H3PNetMessage *message);
bool h3p_net_send_text(H3PNetClient *client, const char *text);
bool h3p_net_send_textf(H3PNetClient *client, const char *fmt, ...);
bool h3p_net_is_connected(const H3PNetClient *client);
const char *h3p_net_last_error(const H3PNetClient *client);
