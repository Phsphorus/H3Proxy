#include "connection_setup.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "logger.h"

typedef struct {
    const char *name;
    int first;
    int second_fixed;
    int second_min;
    int second_max;
    int field_count;
} H3PPrivateRange;

typedef struct {
    int range_index;
    int field_index;
    int octets[4];
    int port;
    char status[128];
} H3PConnectionSetupState;

static const H3PPrivateRange RANGES[] = {
    {"10.0.0.0/8", 10, -1, 0, 255, 4},
    {"172.16.0.0/12", 172, -1, 16, 31, 4},
    {"192.168.0.0/16", 192, 168, 168, 168, 3},
};

static int clamp_i(int value, int low, int high) {
    if (value < low) {
        return low;
    }
    if (value > high) {
        return high;
    }
    return value;
}

static const H3PPrivateRange *active_range(const H3PConnectionSetupState *state) {
    return &RANGES[state->range_index];
}

static int selected_octet_index(const H3PConnectionSetupState *state) {
    const H3PPrivateRange *range = active_range(state);
    if (state->field_index >= range->field_count - 1) {
        return -1;
    }
    if (range->first == 192) {
        return state->field_index + 2;
    }
    return state->field_index + 1;
}

static void apply_range(H3PConnectionSetupState *state) {
    const H3PPrivateRange *range = active_range(state);
    state->octets[0] = range->first;
    if (range->second_fixed >= 0) {
        state->octets[1] = range->second_fixed;
    } else {
        state->octets[1] = clamp_i(state->octets[1], range->second_min, range->second_max);
    }
    state->octets[2] = clamp_i(state->octets[2], 0, 255);
    state->octets[3] = clamp_i(state->octets[3], 1, 254);
    state->port = clamp_i(state->port, 1, 65535);
    state->field_index = clamp_i(state->field_index, 0, range->field_count - 1);
}

static bool parse_server_url(const char *url, int octets[4], int *port) {
    if (!url || !octets || !port) {
        return false;
    }
    const char *cursor = strstr(url, "://");
    cursor = cursor ? cursor + 3 : url;
    int parsed_port = 8766;
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 0;
    int consumed = 0;
    int matched = sscanf(cursor, "%d.%d.%d.%d:%d%n", &a, &b, &c, &d, &parsed_port, &consumed);
    if (matched < 4) {
        matched = sscanf(cursor, "%d.%d.%d.%d%n", &a, &b, &c, &d, &consumed);
    }
    if (matched < 4) {
        return false;
    }
    octets[0] = clamp_i(a, 0, 255);
    octets[1] = clamp_i(b, 0, 255);
    octets[2] = clamp_i(c, 0, 255);
    octets[3] = clamp_i(d, 1, 254);
    *port = clamp_i(parsed_port, 1, 65535);
    return true;
}

static int range_for_octets(const int octets[4]) {
    if (octets[0] == 10) {
        return 0;
    }
    if (octets[0] == 172 && octets[1] >= 16 && octets[1] <= 31) {
        return 1;
    }
    if (octets[0] == 192 && octets[1] == 168) {
        return 2;
    }
    return 2;
}

static void setup_init(H3PConnectionSetupState *state, const H3PClientConfig *config) {
    memset(state, 0, sizeof(*state));
    state->octets[0] = 192;
    state->octets[1] = 168;
    state->octets[2] = 1;
    state->octets[3] = 116;
    state->port = 8766;
    snprintf(state->status, sizeof(state->status), "Choose server and press X");
    if (config) {
        parse_server_url(config->server_url, state->octets, &state->port);
    }
    state->range_index = range_for_octets(state->octets);
    apply_range(state);
}

static void make_server_url(const H3PConnectionSetupState *state, char *out, size_t out_len) {
    if (!out || out_len == 0) {
        return;
    }
    snprintf(
        out,
        out_len,
        "http://%d.%d.%d.%d:%d",
        state->octets[0],
        state->octets[1],
        state->octets[2],
        state->octets[3],
        state->port
    );
}

static const char *selected_field_name(const H3PConnectionSetupState *state) {
    int octet = selected_octet_index(state);
    if (octet == 1) return "octet 2";
    if (octet == 2) return "octet 3";
    if (octet == 3) return "octet 4";
    return "port";
}

static void adjust_selected(H3PConnectionSetupState *state, int delta) {
    int octet = selected_octet_index(state);
    if (octet < 0) {
        state->port = clamp_i(state->port + delta, 1, 65535);
    } else if (octet == 1 && active_range(state)->first == 172) {
        state->octets[1] = clamp_i(state->octets[1] + delta, 16, 31);
    } else if (octet == 3) {
        state->octets[3] = clamp_i(state->octets[3] + delta, 1, 254);
    } else {
        state->octets[octet] = clamp_i(state->octets[octet] + delta, 0, 255);
    }
    apply_range(state);
}

static void draw_setup(const H3PConnectionSetupState *state, PrintConsole *top_console, PrintConsole *bottom_console) {
    char url[H3P_SERVER_URL_BYTES];
    make_server_url(state, url, sizeof(url));

    if (top_console) {
        consoleSelect(top_console);
    }
    consoleClear();
    printf("H3Proxy pre-connection\n\n");
    printf("Range: %s\n", active_range(state)->name);
    printf("Server: %s\n", url);
    printf("Selected: %s\n\n", selected_field_name(state));
    printf("%s\n\n", state->status);
    printf("D-Pad Up/Down: private range\n");
    printf("D-Pad Left/Right: field\n");
    printf("A: +1    B: -1\n");
    printf("X: test and pair\n");
    printf("START: exit\n");

    if (bottom_console) {
        consoleSelect(bottom_console);
    }
    consoleClear();
    printf("Connection setup\n\n");
    printf("10.0.0.0/8\n");
    printf("172.16.0.0/12\n");
    printf("192.168.0.0/16\n\n");
    printf("Current:\n");
    printf("%d.%d.%d.%d:%d\n\n", state->octets[0], state->octets[1], state->octets[2], state->octets[3], state->port);
    printf("If X fails, check server is on\n");
    printf("0.0.0.0:8766 and Windows firewall.\n\n");
    printf("Log: %s\n", h3p_log_path());
    gfxFlushBuffers();
    gfxSwapBuffers();
    gspWaitForVBlank();
}

bool h3p_connection_setup_run(
    H3PClientConfig *config,
    H3PNetClient *net,
    const char *caps_json,
    PrintConsole *top_console,
    PrintConsole *bottom_console
) {
    if (!config || !net) {
        return false;
    }

    H3PConnectionSetupState state;
    setup_init(&state, config);
    h3p_log_printf("SETUP", "preconnect start server=%s", config->server_url);

    bool dirty = true;
    while (aptMainLoop()) {
        if (dirty) {
            draw_setup(&state, top_console, bottom_console);
            dirty = false;
        }
        hidScanInput();
        u32 down = hidKeysDown();

        if (down & KEY_START) {
            h3p_log_printf("SETUP", "preconnect exit");
            return false;
        }
        if (down & KEY_DUP) {
            state.range_index = (state.range_index + 1) % (int)(sizeof(RANGES) / sizeof(RANGES[0]));
            apply_range(&state);
            dirty = true;
        }
        if (down & KEY_DDOWN) {
            state.range_index = (state.range_index + (int)(sizeof(RANGES) / sizeof(RANGES[0])) - 1) % (int)(sizeof(RANGES) / sizeof(RANGES[0]));
            apply_range(&state);
            dirty = true;
        }
        if (down & KEY_DLEFT) {
            int fields = active_range(&state)->field_count;
            state.field_index = (state.field_index + fields - 1) % fields;
            dirty = true;
        }
        if (down & KEY_DRIGHT) {
            int fields = active_range(&state)->field_count;
            state.field_index = (state.field_index + 1) % fields;
            dirty = true;
        }
        if (down & KEY_A) {
            adjust_selected(&state, 1);
            dirty = true;
        }
        if (down & KEY_B) {
            adjust_selected(&state, -1);
            dirty = true;
        }
        if (down & KEY_X) {
            H3PClientConfig trial = *config;
            char start_url[H3P_START_URL_BYTES];
            make_server_url(&state, trial.server_url, sizeof(trial.server_url));
            trial.token[0] = '\0';
            h3p_config_resolve_start_url(&trial, start_url, sizeof(start_url));
            snprintf(state.status, sizeof(state.status), "Testing selected server");
            draw_setup(&state, top_console, bottom_console);
            h3p_log_printf("SETUP", "test server=%s start_url=%s", trial.server_url, start_url);

            if (h3p_net_connect(net, &trial, caps_json, start_url)) {
                *config = trial;
                h3p_config_save(config);
                h3p_log_printf("SETUP", "pair ok server=%s", config->server_url);
                return true;
            }

            h3p_net_close(net);
            snprintf(state.status, sizeof(state.status), "Failed: %s", h3p_net_last_error(net));
            h3p_log_printf("SETUP", "pair failed error=%s", h3p_net_last_error(net));
            dirty = true;
        }
        gspWaitForVBlank();
    }
    return false;
}
