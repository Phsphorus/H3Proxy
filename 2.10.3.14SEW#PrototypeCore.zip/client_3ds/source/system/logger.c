#include <3ds.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "logger.h"

static const char *LOG_PATH = "sdmc:/h3proxy.log";
static FILE *s_log_file = NULL;
static char s_ring[H3P_LOG_RING_LINES][H3P_LOG_LINE_BYTES];
static int s_next_line = 0;
static int s_line_count = 0;
static int s_pending_flush = 0;
static u64 s_last_flush_at = 0;

static void ring_push(const char *line) {
    snprintf(s_ring[s_next_line], H3P_LOG_LINE_BYTES, "%s", line ? line : "");
    s_next_line = (s_next_line + 1) % H3P_LOG_RING_LINES;
    if (s_line_count < H3P_LOG_RING_LINES) {
        s_line_count++;
    }
}

bool h3p_log_init(void) {
    s_log_file = fopen(LOG_PATH, "a");
    s_pending_flush = 0;
    s_last_flush_at = osGetTime();
    h3p_log_printf("INFO", "logger init path=%s file=%s", LOG_PATH, s_log_file ? "ok" : "failed");
    return s_log_file != NULL;
}

void h3p_log_close(void) {
    h3p_log_printf("INFO", "logger close");
    if (s_log_file) {
        fflush(s_log_file);
        fclose(s_log_file);
        s_log_file = NULL;
    }
}

void h3p_log_printf(const char *level, const char *fmt, ...) {
    char level_name[8];
    char message[H3P_LOG_MESSAGE_BYTES];
    char line[H3P_LOG_LINE_BYTES];
    va_list args;

    snprintf(level_name, sizeof(level_name), "%s", level ? level : "INFO");
    va_start(args, fmt);
    vsnprintf(message, sizeof(message), fmt ? fmt : "", args);
    va_end(args);

    snprintf(line, sizeof(line), "%08llu %-5.5s %s", (unsigned long long)osGetTime(), level_name, message);
    ring_push(line);

    if (s_log_file) {
        fprintf(s_log_file, "%s\n", line);
        s_pending_flush++;
        u64 now = osGetTime();
        bool urgent = strcmp(level_name, "ERR") == 0 || strcmp(level_name, "WARN") == 0;
        if (urgent || s_pending_flush >= 64 || now - s_last_flush_at >= 1000) {
            fflush(s_log_file);
            s_pending_flush = 0;
            s_last_flush_at = now;
        }
    }
}

int h3p_log_recent_count(void) {
    return s_line_count;
}

const char *h3p_log_recent_line(int index) {
    if (index < 0 || index >= s_line_count) {
        return "";
    }
    int start = s_next_line - s_line_count;
    while (start < 0) {
        start += H3P_LOG_RING_LINES;
    }
    return s_ring[(start + index) % H3P_LOG_RING_LINES];
}

const char *h3p_log_path(void) {
    return LOG_PATH;
}

bool h3p_log_file_ready(void) {
    return s_log_file != NULL;
}
