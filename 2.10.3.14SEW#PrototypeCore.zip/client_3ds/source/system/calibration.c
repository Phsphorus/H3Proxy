#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "calibration.h"
#include "logger.h"

#define H3P_RAM_STEP_BYTES (1024 * 1024)
#define H3P_RAM_MAX_PROBE_BYTES (160 * 1024 * 1024)
#define H3P_RAM_MAX_BLOCKS (H3P_RAM_MAX_PROBE_BYTES / H3P_RAM_STEP_BYTES)
#define H3P_SD_TEST_BYTES (50 * 1024 * 1024)
#define H3P_SD_CHUNK_BYTES (64 * 1024)

static uint32_t clamp_u32(uint32_t value, uint32_t low, uint32_t high) {
    if (value < low) {
        return low;
    }
    if (value > high) {
        return high;
    }
    return value;
}

static uint32_t probe_ram_bytes(void) {
    void *blocks[H3P_RAM_MAX_BLOCKS];
    uint32_t count = 0;
    memset(blocks, 0, sizeof(blocks));

    h3p_log_printf("CAL", "ram probe start step=%lu max=%lu", (unsigned long)H3P_RAM_STEP_BYTES, (unsigned long)H3P_RAM_MAX_PROBE_BYTES);
    for (uint32_t i = 0; i < H3P_RAM_MAX_BLOCKS; i++) {
        void *block = malloc(H3P_RAM_STEP_BYTES);
        if (!block) {
            h3p_log_printf("CAL", "ram probe malloc stop block=%lu", (unsigned long)i);
            break;
        }
        memset(block, 0, 32);
        blocks[i] = block;
        count++;
    }

    for (uint32_t i = 0; i < count; i++) {
        free(blocks[i]);
    }

    h3p_log_printf("CAL", "ram probe done blocks=%lu bytes=%lu", (unsigned long)count, (unsigned long)(count * H3P_RAM_STEP_BYTES));
    return count * H3P_RAM_STEP_BYTES;
}

static uint32_t benchmark_rgb565_conversion_ms(uint32_t width, uint32_t height, uint32_t loops) {
    const uint32_t pixels = width * height;
    uint8_t *rgb888 = (uint8_t *)malloc(pixels * 3);
    uint16_t *rgb565 = (uint16_t *)malloc(pixels * sizeof(uint16_t));
    if (!rgb888 || !rgb565) {
        h3p_log_printf("CAL", "rgb565 bench alloc failed width=%lu height=%lu", (unsigned long)width, (unsigned long)height);
        free(rgb888);
        free(rgb565);
        return 999;
    }

    for (uint32_t i = 0; i < pixels * 3; i++) {
        rgb888[i] = (uint8_t)(i * 13u);
    }

    u64 started = osGetTime();
    for (uint32_t loop = 0; loop < loops; loop++) {
        for (uint32_t i = 0; i < pixels; i++) {
            uint32_t base = i * 3;
            uint8_t r = rgb888[base];
            uint8_t g = rgb888[base + 1];
            uint8_t b = rgb888[base + 2];
            rgb565[i] = (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
        }
    }
    u64 elapsed = osGetTime() - started;
    free(rgb888);
    free(rgb565);

    uint32_t per_loop = (uint32_t)((elapsed + loops - 1) / loops);
    h3p_log_printf(
        "CAL",
        "rgb565 bench width=%lu height=%lu loops=%lu elapsed_ms=%llu per_loop_ms=%lu",
        (unsigned long)width,
        (unsigned long)height,
        (unsigned long)loops,
        (unsigned long long)elapsed,
        (unsigned long)clamp_u32(per_loop, 1, 999)
    );
    return clamp_u32(per_loop, 1, 999);
}

static uint32_t benchmark_sd_write_kb_s(void) {
    uint8_t *buffer = (uint8_t *)malloc(H3P_SD_CHUNK_BYTES);
    if (!buffer) {
        h3p_log_printf("CAL", "sd probe buffer alloc failed bytes=%lu", (unsigned long)H3P_SD_CHUNK_BYTES);
        return 0;
    }
    memset(buffer, 0xA5, H3P_SD_CHUNK_BYTES);

    FILE *file = fopen("sdmc:/h3proxy_sd_probe.tmp", "wb");
    if (!file) {
        h3p_log_printf("CAL", "sd probe open failed");
        free(buffer);
        return 0;
    }

    h3p_log_printf("CAL", "sd probe start bytes=%lu chunk=%lu", (unsigned long)H3P_SD_TEST_BYTES, (unsigned long)H3P_SD_CHUNK_BYTES);
    u64 started = osGetTime();
    uint32_t written = 0;
    while (written < H3P_SD_TEST_BYTES) {
        size_t wrote = fwrite(buffer, 1, H3P_SD_CHUNK_BYTES, file);
        if (wrote != H3P_SD_CHUNK_BYTES) {
            h3p_log_printf("CAL", "sd probe short write written=%lu wrote=%lu", (unsigned long)written, (unsigned long)wrote);
            break;
        }
        written += H3P_SD_CHUNK_BYTES;
    }
    fflush(file);
    fclose(file);
    remove("sdmc:/h3proxy_sd_probe.tmp");
    free(buffer);

    u64 elapsed_ms = osGetTime() - started;
    if (elapsed_ms == 0 || written == 0) {
        h3p_log_printf("CAL", "sd probe failed elapsed_ms=%llu written=%lu", (unsigned long long)elapsed_ms, (unsigned long)written);
        return 0;
    }
    uint32_t kb_s = (uint32_t)(((u64)written * 1000u) / elapsed_ms / 1024u);
    h3p_log_printf("CAL", "sd probe done written=%lu elapsed_ms=%llu kb_s=%lu", (unsigned long)written, (unsigned long long)elapsed_ms, (unsigned long)kb_s);
    return kb_s;
}

void h3p_calibration_defaults(H3PCalibratedProfile *profile) {
    if (!profile) {
        return;
    }
    memset(profile, 0, sizeof(*profile));
    snprintf(profile->profile, sizeof(profile->profile), "New 3DS LL / XL");
    profile->calibrated = false;
    profile->max_page_fps = 10;
    profile->max_media_fps = 15;
    profile->safe_ram_bytes = 104857600u;
    profile->aggressive_ram_bytes = 130023424u;
    profile->safe_texture_cache_tiles = 96;
    profile->decode_jpeg_400x225_ms_p95 = 20;
    profile->decode_png_tile_ms_p95 = 6;
    profile->sd_write_kb_s = 0;
    profile->network_recv_kb_s = 0;
}

void h3p_calibration_run_safe(H3PCalibratedProfile *profile) {
    if (!profile) {
        return;
    }
    h3p_calibration_defaults(profile);
    h3p_log_printf("CAL", "defaults profile=%s page_fps=%lu media_fps=%lu", profile->profile, (unsigned long)profile->max_page_fps, (unsigned long)profile->max_media_fps);

    uint32_t allocatable = probe_ram_bytes();
    if (allocatable >= 8 * H3P_RAM_STEP_BYTES) {
        profile->safe_ram_bytes = (uint32_t)((u64)allocatable * 80u / 100u);
        profile->aggressive_ram_bytes = (uint32_t)((u64)allocatable * 92u / 100u);
        h3p_log_printf("CAL", "ram budgets adjusted safe=%lu aggressive=%lu", (unsigned long)profile->safe_ram_bytes, (unsigned long)profile->aggressive_ram_bytes);
    } else {
        h3p_log_printf("CAL", "ram probe too low using defaults allocatable=%lu", (unsigned long)allocatable);
    }

    profile->decode_png_tile_ms_p95 = benchmark_rgb565_conversion_ms(100, 60, 60);
    profile->decode_jpeg_400x225_ms_p95 = benchmark_rgb565_conversion_ms(400, 225, 20);
    profile->sd_write_kb_s = benchmark_sd_write_kb_s();

    uint32_t frame_budget_ms = profile->decode_jpeg_400x225_ms_p95 + 6;
    if (frame_budget_ms > 0) {
        profile->max_media_fps = clamp_u32(1000u / frame_budget_ms, 8, 60);
    }

    uint32_t page_budget_ms = profile->decode_png_tile_ms_p95 + 8;
    if (page_budget_ms > 0) {
        profile->max_page_fps = clamp_u32(1000u / page_budget_ms, 6, 60);
    }

    profile->safe_texture_cache_tiles = clamp_u32(profile->safe_ram_bytes / (100u * 60u * 2u), 32, 256);
    profile->calibrated = true;
}

int h3p_calibration_client_caps_json(const H3PCalibratedProfile *profile, char *out, size_t out_len) {
    if (!profile || !out || out_len == 0) {
        return -1;
    }
    int written = snprintf(
        out,
        out_len,
        "{\"type\":\"client_caps\",\"profile\":\"%s\",\"calibrated\":%s,"
        "\"max_page_fps\":%lu,\"max_media_fps\":%lu,"
        "\"safe_ram_bytes\":%lu,\"safe_texture_cache_tiles\":%lu,"
        "\"decode_jpeg_400x225_ms_p95\":%lu,\"decode_png_tile_ms_p95\":%lu,"
        "\"sd_write_mb_s\":%lu,\"network_recv_kb_s\":%lu}",
        profile->profile,
        profile->calibrated ? "true" : "false",
        (unsigned long)profile->max_page_fps,
        (unsigned long)profile->max_media_fps,
        (unsigned long)profile->safe_ram_bytes,
        (unsigned long)profile->safe_texture_cache_tiles,
        (unsigned long)profile->decode_jpeg_400x225_ms_p95,
        (unsigned long)profile->decode_png_tile_ms_p95,
        (unsigned long)(profile->sd_write_kb_s / 1024u),
        (unsigned long)profile->network_recv_kb_s
    );
    if (written < 0 || (size_t)written >= out_len) {
        return -2;
    }
    return written;
}
