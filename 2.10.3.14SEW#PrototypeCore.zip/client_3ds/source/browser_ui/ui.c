#include <3ds.h>
#include <stdio.h>
#include <string.h>

#include "logger.h"
#include "ui.h"

static PrintConsole *s_top_console = NULL;
static PrintConsole *s_bottom_console = NULL;

void h3p_ui_set_consoles(PrintConsole *top, PrintConsole *bottom) {
    s_top_console = top;
    s_bottom_console = bottom;
}

void h3p_ui_init(H3PUIState *ui) {
    if (!ui) {
        return;
    }
    memset(ui, 0, sizeof(*ui));
    ui->mode = H3P_UI_PAGE;
    ui->selected_dom_id = -1;
    snprintf(ui->status, sizeof(ui->status), "Disconnected");
}

void h3p_ui_set_status(H3PUIState *ui, const char *status) {
    if (!ui || !status) {
        return;
    }
    snprintf(ui->status, sizeof(ui->status), "%s", status);
    h3p_log_printf("UI", "status=%s", ui->status);
}

void h3p_ui_set_error(H3PUIState *ui, const char *code, const char *detail, bool fatal) {
    if (!ui) {
        return;
    }
    ui->error_active = true;
    ui->error_fatal = fatal;
    snprintf(ui->error_code, sizeof(ui->error_code), "%s", (code && code[0]) ? code : "unknown");
    snprintf(ui->error_detail, sizeof(ui->error_detail), "%s", (detail && detail[0]) ? detail : "no detail");
    snprintf(ui->status, sizeof(ui->status), "%s error: %s", fatal ? "fatal" : "nonfatal", ui->error_code);
    h3p_log_printf("UI", "error code=%s fatal=%s", ui->error_code, fatal ? "true" : "false");
}

void h3p_ui_clear_nonfatal_error(H3PUIState *ui) {
    if (!ui || !ui->error_active || ui->error_fatal) {
        return;
    }
    ui->error_active = false;
    ui->error_fatal = false;
    ui->error_code[0] = '\0';
    ui->error_detail[0] = '\0';
    snprintf(ui->status, sizeof(ui->status), "Error cleared");
    h3p_log_printf("UI", "error cleared");
}

void h3p_ui_draw_top_debug(const H3PUIState *ui) {
    if (s_top_console) {
        consoleSelect(s_top_console);
    }
    consoleClear();
    printf("H3Proxy status\n\n");
    printf("status: %s\n", ui ? ui->status : "?");
    printf("url: %s\n", ui ? ui->url : "");
    printf("title: %s\n\n", ui ? ui->title : "");
    printf("Detailed log stays on SD:\n");
    printf("sdmc:/h3proxy.log\n");
}

void h3p_ui_draw_bottom(const H3PUIState *ui) {
    if (s_bottom_console) {
        consoleSelect(s_bottom_console);
    }
    consoleClear();
    printf("H3Proxy 3DS\n");
    printf("status: %s\n", ui ? ui->status : "?");
    printf("url: %s\n", ui ? ui->url : "");
    printf("title: %s\n", ui ? ui->title : "");
    printf("dom: %d of %d  bottom view: %s\n", ui ? ui->selected_dom_id : -1, ui ? ui->dom_count : 0, (ui && ui->webview_on_bottom) ? "page" : "tools");
    printf("log: sdmc:/h3proxy.log\n\n");
    printf("L back  R forward  ZL reload\n");
    printf("A enter  B deselect  X top  Y bottom\n");
    printf("Bottom top 180px = page pad, bottom 60px = dock\n");
    printf("Dock: URL/Go | DOM prev next use | quality\n");
    printf("START exit\n");
}
