#include <stdlib.h>

#define STBI_ONLY_JPEG
#define STBI_ONLY_PNG
#define STBI_NO_STDIO
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "image_decode.h"

static uint16_t rgb888_to_rgb565(uint8_t r, uint8_t g, uint8_t b) {
    return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

int h3p_decode_image_rgb565(const uint8_t *payload, size_t payload_len, H3PDecodedImage *out) {
    if (!payload || payload_len == 0 || !out) {
        return -1;
    }

    int width = 0;
    int height = 0;
    int channels = 0;
    unsigned char *decoded = stbi_load_from_memory(payload, (int)payload_len, &width, &height, &channels, 3);
    if (!decoded || width <= 0 || height <= 0) {
        return -2;
    }

    size_t pixel_count = (size_t)width * (size_t)height;
    uint16_t *rgb565 = (uint16_t *)malloc(pixel_count * sizeof(uint16_t));
    if (!rgb565) {
        stbi_image_free(decoded);
        return -3;
    }

    for (size_t i = 0; i < pixel_count; i++) {
        size_t base = i * 3;
        rgb565[i] = rgb888_to_rgb565(decoded[base], decoded[base + 1], decoded[base + 2]);
    }

    stbi_image_free(decoded);
    out->width = width;
    out->height = height;
    out->rgb565 = rgb565;
    return 0;
}

void h3p_free_decoded_image(H3PDecodedImage *image) {
    if (!image) {
        return;
    }
    free(image->rgb565);
    image->width = 0;
    image->height = 0;
    image->rgb565 = NULL;
}
