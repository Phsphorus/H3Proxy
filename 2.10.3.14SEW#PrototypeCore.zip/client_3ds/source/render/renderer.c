#include "renderer.h"

#include <stdio.h>
#include <string.h>

static uint16_t s_canvas[H3P_SCREEN_W * H3P_SCREEN_H];
static bool s_has_content = false;
static bool s_bottom_ui = false;
static bool s_bottom_page_mirror = false;
static char s_bottom_url[48] = "/start";
static char s_bottom_text[38] = "";
static char s_bottom_fps[16] = "FPS --";

static uint8_t rgb565_r(uint16_t color) {
    return (uint8_t)(((color >> 11) & 0x1F) << 3);
}

static uint8_t rgb565_g(uint16_t color) {
    return (uint8_t)(((color >> 5) & 0x3F) << 2);
}

static uint8_t rgb565_b(uint16_t color) {
    return (uint8_t)((color & 0x1F) << 3);
}

void h3p_renderer_init(void) {
    h3p_renderer_clear(0x0000);
}

void h3p_renderer_shutdown(void) {
}

void h3p_renderer_begin_frame(void) {
}

void h3p_renderer_draw_tile(const H3PTileTexture *tile) {
    if (!tile || !tile->valid) {
        return;
    }
    h3p_renderer_draw_image_rgb565(tile->x, tile->y, tile->w, tile->h, tile->pixels, tile->w, tile->h);
}

void h3p_renderer_draw_image_rgb565(int x, int y, int w, int h, const uint16_t *pixels, int source_w, int source_h) {
    if (!pixels || w <= 0 || h <= 0 || source_w <= 0 || source_h <= 0) {
        return;
    }
    for (int dst_y = 0; dst_y < h; dst_y++) {
        int screen_y = y + dst_y;
        if (screen_y < 0 || screen_y >= H3P_SCREEN_H) {
            continue;
        }
        int src_y = dst_y * source_h / h;
        for (int dst_x = 0; dst_x < w; dst_x++) {
            int screen_x = x + dst_x;
            if (screen_x < 0 || screen_x >= H3P_SCREEN_W) {
                continue;
            }
            int src_x = dst_x * source_w / w;
            s_canvas[screen_y * H3P_SCREEN_W + screen_x] = pixels[src_y * source_w + src_x];
        }
    }
    s_has_content = true;
}

void h3p_renderer_clear(uint16_t color) {
    for (int i = 0; i < H3P_SCREEN_W * H3P_SCREEN_H; i++) {
        s_canvas[i] = color;
    }
    s_has_content = false;
}

bool h3p_renderer_has_content(void) {
    return s_has_content;
}

void h3p_renderer_set_bottom_mirror(bool enabled) {
    h3p_renderer_set_bottom_ui(enabled, enabled);
}

void h3p_renderer_set_bottom_ui(bool enabled, bool mirror_page) {
    s_bottom_ui = enabled;
    s_bottom_page_mirror = mirror_page;
}

static void copy_display_text(char *out, size_t out_len, const char *text) {
    if (!out || out_len == 0) {
        return;
    }
    out[0] = '\0';
    if (!text || !text[0]) {
        return;
    }
    size_t in_len = strlen(text);
    const char *start = text;
    if (in_len >= out_len) {
        start = text + (in_len - (out_len - 1));
    }
    snprintf(out, out_len, "%s", start);
}

void h3p_renderer_set_bottom_info(const char *url_text, const char *web_text, unsigned int fps_x10) {
    copy_display_text(s_bottom_url, sizeof(s_bottom_url), url_text && url_text[0] ? url_text : "/start");
    copy_display_text(s_bottom_text, sizeof(s_bottom_text), web_text && web_text[0] ? web_text : "TEXT TO PAGE");
    snprintf(s_bottom_fps, sizeof(s_bottom_fps), "FPS %u.%u", fps_x10 / 10u, fps_x10 % 10u);
}

static void write_bgr8_pixel(u8 *fb, int fb_width, int x, int y, uint16_t color) {
    u32 offset = (u32)((fb_width - 1 - y) + x * fb_width) * 3u;
    fb[offset + 0] = rgb565_b(color);
    fb[offset + 1] = rgb565_g(color);
    fb[offset + 2] = rgb565_r(color);
}

static void write_rgb565_pixel(u16 *fb, int fb_width, int x, int y, uint16_t color) {
    u32 offset = (u32)((fb_width - 1 - y) + x * fb_width);
    fb[offset] = color;
}

static void write_framebuffer_pixel(void *fb, GSPGPU_FramebufferFormat format, int fb_width, int x, int y, uint16_t color) {
    if (!fb) {
        return;
    }
    if (format == GSP_RGB565_OES) {
        write_rgb565_pixel((u16 *)fb, fb_width, x, y, color);
    } else {
        write_bgr8_pixel((u8 *)fb, fb_width, x, y, color);
    }
}

static uint8_t font_row(char c, int row) {
    static const uint8_t digits[10][7] = {
        {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},
        {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},
        {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},
        {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E},
        {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},
        {0x1F,0x10,0x10,0x1E,0x01,0x01,0x1E},
        {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E},
        {0x1F,0x01,0x02,0x04,0x08,0x08,0x08},
        {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},
        {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C},
    };
    if (row < 0 || row >= 7) {
        return 0;
    }
    if (c >= '0' && c <= '9') {
        return digits[c - '0'][row];
    }
    switch (c) {
        case 'A': { static const uint8_t g[7]={0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}; return g[row]; }
        case 'B': { static const uint8_t g[7]={0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}; return g[row]; }
        case 'C': { static const uint8_t g[7]={0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}; return g[row]; }
        case 'D': { static const uint8_t g[7]={0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}; return g[row]; }
        case 'E': { static const uint8_t g[7]={0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}; return g[row]; }
        case 'F': { static const uint8_t g[7]={0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}; return g[row]; }
        case 'G': { static const uint8_t g[7]={0x0E,0x11,0x10,0x17,0x11,0x11,0x0E}; return g[row]; }
        case 'H': { static const uint8_t g[7]={0x11,0x11,0x11,0x1F,0x11,0x11,0x11}; return g[row]; }
        case 'I': { static const uint8_t g[7]={0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}; return g[row]; }
        case 'J': { static const uint8_t g[7]={0x07,0x02,0x02,0x02,0x12,0x12,0x0C}; return g[row]; }
        case 'K': { static const uint8_t g[7]={0x11,0x12,0x14,0x18,0x14,0x12,0x11}; return g[row]; }
        case 'L': { static const uint8_t g[7]={0x10,0x10,0x10,0x10,0x10,0x10,0x1F}; return g[row]; }
        case 'M': { static const uint8_t g[7]={0x11,0x1B,0x15,0x15,0x11,0x11,0x11}; return g[row]; }
        case 'N': { static const uint8_t g[7]={0x11,0x19,0x15,0x13,0x11,0x11,0x11}; return g[row]; }
        case 'O': { static const uint8_t g[7]={0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}; return g[row]; }
        case 'P': { static const uint8_t g[7]={0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}; return g[row]; }
        case 'Q': { static const uint8_t g[7]={0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}; return g[row]; }
        case 'R': { static const uint8_t g[7]={0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}; return g[row]; }
        case 'S': { static const uint8_t g[7]={0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}; return g[row]; }
        case 'T': { static const uint8_t g[7]={0x1F,0x04,0x04,0x04,0x04,0x04,0x04}; return g[row]; }
        case 'U': { static const uint8_t g[7]={0x11,0x11,0x11,0x11,0x11,0x11,0x0E}; return g[row]; }
        case 'V': { static const uint8_t g[7]={0x11,0x11,0x11,0x11,0x11,0x0A,0x04}; return g[row]; }
        case 'W': { static const uint8_t g[7]={0x11,0x11,0x11,0x15,0x15,0x15,0x0A}; return g[row]; }
        case 'X': { static const uint8_t g[7]={0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}; return g[row]; }
        case 'Y': { static const uint8_t g[7]={0x11,0x11,0x0A,0x04,0x04,0x04,0x04}; return g[row]; }
        case 'Z': { static const uint8_t g[7]={0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}; return g[row]; }
        case '<': { static const uint8_t g[7]={0x02,0x04,0x08,0x10,0x08,0x04,0x02}; return g[row]; }
        case '>': { static const uint8_t g[7]={0x08,0x04,0x02,0x01,0x02,0x04,0x08}; return g[row]; }
        case ':': { static const uint8_t g[7]={0x00,0x04,0x04,0x00,0x04,0x04,0x00}; return g[row]; }
        case '.': { static const uint8_t g[7]={0x00,0x00,0x00,0x00,0x00,0x0C,0x0C}; return g[row]; }
        case '/': { static const uint8_t g[7]={0x01,0x02,0x02,0x04,0x08,0x08,0x10}; return g[row]; }
        case '-': { static const uint8_t g[7]={0x00,0x00,0x00,0x1F,0x00,0x00,0x00}; return g[row]; }
        case '_': { static const uint8_t g[7]={0x00,0x00,0x00,0x00,0x00,0x00,0x1F}; return g[row]; }
        case '=': { static const uint8_t g[7]={0x00,0x00,0x1F,0x00,0x1F,0x00,0x00}; return g[row]; }
        case '+': { static const uint8_t g[7]={0x00,0x04,0x04,0x1F,0x04,0x04,0x00}; return g[row]; }
        case '?': { static const uint8_t g[7]={0x0E,0x11,0x01,0x02,0x04,0x00,0x04}; return g[row]; }
        case '&': { static const uint8_t g[7]={0x0C,0x12,0x14,0x08,0x15,0x12,0x0D}; return g[row]; }
        case '#': { static const uint8_t g[7]={0x0A,0x0A,0x1F,0x0A,0x1F,0x0A,0x0A}; return g[row]; }
        case ' ': return 0;
        default: return 0x00;
    }
}

static void draw_text_to_framebuffer(void *fb, GSPGPU_FramebufferFormat format, int fb_width, int x, int y, const char *text, uint16_t color, int scale) {
    if (!fb || !text || scale <= 0) {
        return;
    }
    int cursor_x = x;
    for (const char *p = text; *p; p++) {
        char c = *p;
        if (c >= 'a' && c <= 'z') {
            c = (char)(c - 'a' + 'A');
        }
        for (int row = 0; row < 7; row++) {
            uint8_t bits = font_row(c, row);
            for (int col = 0; col < 5; col++) {
                if (!(bits & (1 << (4 - col)))) {
                    continue;
                }
                for (int sy = 0; sy < scale; sy++) {
                    for (int sx = 0; sx < scale; sx++) {
                        int px = cursor_x + col * scale + sx;
                        int py = y + row * scale + sy;
                        if (px >= 0 && px < 320 && py >= 0 && py < 240) {
                            write_framebuffer_pixel(fb, format, fb_width, px, py, color);
                        }
                    }
                }
            }
        }
        cursor_x += 6 * scale;
    }
}

static void fill_rect(void *fb, GSPGPU_FramebufferFormat format, int fb_width, int x, int y, int w, int h, uint16_t color) {
    for (int py = y; py < y + h; py++) {
        for (int px = x; px < x + w; px++) {
            if (px >= 0 && px < 320 && py >= 0 && py < 240) {
                write_framebuffer_pixel(fb, format, fb_width, px, py, color);
            }
        }
    }
}

static void fill_rect_bounds(void *fb, GSPGPU_FramebufferFormat format, int fb_width, int max_w, int max_h, int x, int y, int w, int h, uint16_t color) {
    for (int py = y; py < y + h; py++) {
        for (int px = x; px < x + w; px++) {
            if (px >= 0 && px < max_w && py >= 0 && py < max_h) {
                write_framebuffer_pixel(fb, format, fb_width, px, py, color);
            }
        }
    }
}

static void draw_bottom_ui(void) {
    u16 fb_width = 0;
    void *fb = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &fb_width, NULL);
    if (!fb) {
        return;
    }
    GSPGPU_FramebufferFormat format = gfxGetScreenFormat(GFX_BOTTOM);

    const int bottom_w = 320;
    const int bottom_h = 240;
    const int pad_h = 180;
    for (int y = 0; y < bottom_h; y++) {
        for (int x = 0; x < bottom_w; x++) {
            uint16_t color = 0x0861;
            if (y < pad_h && s_bottom_page_mirror && s_has_content) {
                int src_x = x * H3P_SCREEN_W / bottom_w;
                int src_y = y * H3P_SCREEN_H / pad_h;
                color = s_canvas[src_y * H3P_SCREEN_W + src_x];
            } else if (y < pad_h) {
                color = 0x0861;
                if (y < 28) {
                    color = 0x1725;
                } else if (y > 136 && y < 178) {
                    color = 0x10A3;
                }
            } else if (y >= pad_h) {
                color = 0x10A3;
                if (y == pad_h || y == pad_h + 30) {
                    color = 0x4A69;
                } else if (x < 70) {
                    color = 0x18E5;
                } else if (x < 240) {
                    color = 0x2127;
                } else {
                    color = 0x1946;
                }
            }
            write_framebuffer_pixel(fb, format, fb_width ? fb_width : bottom_h, x, y, color);
        }
    }
    int pitch = fb_width ? fb_width : bottom_h;
    fill_rect(fb, format, pitch, 244, 4, 72, 20, 0x0000);
    draw_text_to_framebuffer(fb, format, pitch, 250, 9, s_bottom_fps, 0xFFFF, 1);

    if (!s_bottom_page_mirror) {
        draw_text_to_framebuffer(fb, format, pitch, 10, 10, "H3PROXY", 0xFFFF, 2);
        draw_text_to_framebuffer(fb, format, pitch, 10, 52, "Y BOTTOM TOUCH VIEW", 0xFFFF, 1);
        draw_text_to_framebuffer(fb, format, pitch, 10, 74, "X TOP VIEW", 0xFFFF, 1);
        draw_text_to_framebuffer(fb, format, pitch, 10, 96, "L BACK R FORWARD ZL RELOAD", 0xFFFF, 1);
        draw_text_to_framebuffer(fb, format, pitch, 10, 118, "A ENTER B ESC", 0xFFFF, 1);
        draw_text_to_framebuffer(fb, format, pitch, 10, 150, "FULL LOG ON SD", 0xBDF7, 1);
    }

    fill_rect(fb, format, pitch, 4, 184, 270, 23, 0xFFFF);
    fill_rect(fb, format, pitch, 276, 184, 40, 23, 0x2B5F);
    draw_text_to_framebuffer(fb, format, pitch, 8, 188, "URL", 0x0000, 1);
    draw_text_to_framebuffer(fb, format, pitch, 286, 188, "GO", 0xFFFF, 1);
    draw_text_to_framebuffer(fb, format, pitch, 36, 188, s_bottom_url, 0x0000, 1);

    fill_rect(fb, format, pitch, 4, 212, 254, 23, 0xFFFF);
    fill_rect(fb, format, pitch, 262, 212, 54, 23, 0x3C86);
    draw_text_to_framebuffer(fb, format, pitch, 10, 216, s_bottom_text, 0x0000, 1);
    draw_text_to_framebuffer(fb, format, pitch, 270, 216, "ENTER", 0xFFFF, 1);
}

void h3p_renderer_present_error(const char *code, const char *detail, const char *url, const char *title, bool fatal) {
    char code_line[44];
    char detail_line[48];
    copy_display_text(code_line, sizeof(code_line), code && code[0] ? code : "unknown");
    snprintf(detail_line, sizeof(detail_line), "%s", detail && detail[0] ? detail : "no detail");

    u16 top_width = 0;
    void *top = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &top_width, NULL);
    if (top) {
        GSPGPU_FramebufferFormat format = gfxGetScreenFormat(GFX_TOP);
        int pitch = top_width ? top_width : H3P_SCREEN_H;
        fill_rect_bounds(top, format, pitch, H3P_SCREEN_W, H3P_SCREEN_H, 0, 0, H3P_SCREEN_W, H3P_SCREEN_H, 0x0000);
        fill_rect_bounds(top, format, pitch, H3P_SCREEN_W, H3P_SCREEN_H, 0, 0, H3P_SCREEN_W, 30, fatal ? 0x8800 : 0xCBE0);
        draw_text_to_framebuffer(top, format, pitch, 10, 9, fatal ? "H3PROXY FATAL" : "H3PROXY NONFATAL", 0xFFFF, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 44, "WEBVIEW PAUSED", 0xFFE0, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 66, "CODE", 0xFFE0, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 80, code_line, 0xFFFF, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 108, "DETAIL", 0xFFE0, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 122, detail_line, 0xFFFF, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 154, "URL", 0xFFE0, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 168, url && url[0] ? url : "-", 0xFFFF, 1);
        draw_text_to_framebuffer(top, format, pitch, 10, 206, fatal ? "START HOLD EXIT" : "SELECT CLEAR LOG ON SD", 0xBDF7, 1);
    }

    u16 bottom_width = 0;
    void *bottom = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, &bottom_width, NULL);
    if (bottom) {
        GSPGPU_FramebufferFormat format = gfxGetScreenFormat(GFX_BOTTOM);
        int pitch = bottom_width ? bottom_width : H3P_SCREEN_H;
        fill_rect_bounds(bottom, format, pitch, 320, 240, 0, 0, 320, 240, 0x0000);
        fill_rect_bounds(bottom, format, pitch, 320, 240, 0, 0, 320, 28, fatal ? 0x8800 : 0xCBE0);
        draw_text_to_framebuffer(bottom, format, pitch, 10, 8, fatal ? "FATAL ERROR" : "NONFATAL ERROR", 0xFFFF, 1);
        draw_text_to_framebuffer(bottom, format, pitch, 10, 48, code_line, 0xFFFF, 1);
        draw_text_to_framebuffer(bottom, format, pitch, 10, 92, "WEBVIEW PAUSED", 0xFFE0, 1);
        draw_text_to_framebuffer(bottom, format, pitch, 10, 118, fatal ? "START HOLD TO QUIT" : "SELECT TO CLEAR", 0xBDF7, 1);
        draw_text_to_framebuffer(bottom, format, pitch, 10, 142, "SDMC:/H3PROXY.LOG", 0xBDF7, 1);
        if (title && title[0]) {
            draw_text_to_framebuffer(bottom, format, pitch, 10, 174, title, 0x7BEF, 1);
        }
    }

    gfxFlushBuffers();
    gfxSwapBuffers();
}

void h3p_renderer_end_frame(void) {
    if (s_has_content) {
        u16 fb_width = 0;
        void *fb = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &fb_width, NULL);
        if (fb) {
            GSPGPU_FramebufferFormat format = gfxGetScreenFormat(GFX_TOP);
            for (int y = 0; y < H3P_SCREEN_H; y++) {
                for (int x = 0; x < H3P_SCREEN_W; x++) {
                    uint16_t color = s_canvas[y * H3P_SCREEN_W + x];
                    int pitch = fb_width ? fb_width : H3P_SCREEN_H;
                    write_framebuffer_pixel(fb, format, pitch, x, y, color);
                }
            }
        }
    }
    if (s_bottom_ui) {
        draw_bottom_ui();
    }
    gfxFlushBuffers();
    gfxSwapBuffers();
}
