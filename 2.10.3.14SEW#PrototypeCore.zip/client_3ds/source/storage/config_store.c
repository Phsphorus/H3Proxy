#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config_store.h"
#include "logger.h"

static const char *CONFIG_PATH = "sdmc:/h3proxy.cfg";

static char *trim(char *value) {
    if (!value) {
        return value;
    }
    while (*value == ' ' || *value == '\t' || *value == '\r' || *value == '\n') {
        value++;
    }
    char *end = value + strlen(value);
    while (end > value && (end[-1] == ' ' || end[-1] == '\t' || end[-1] == '\r' || end[-1] == '\n')) {
        end--;
    }
    *end = '\0';
    return value;
}

static void copy_value(char *out, size_t out_len, const char *value) {
    if (!out || out_len == 0) {
        return;
    }
    snprintf(out, out_len, "%s", value ? value : "");
}

void h3p_config_defaults(H3PClientConfig *config) {
    if (!config) {
        return;
    }
    snprintf(config->server_url, sizeof(config->server_url), "http://192.168.1.100:8766");
    config->token[0] = '\0';
    snprintf(config->start_url, sizeof(config->start_url), "/start");
    snprintf(config->quality, sizeof(config->quality), "normal");
}

bool h3p_config_load(H3PClientConfig *config) {
    h3p_config_defaults(config);
    FILE *file = fopen(CONFIG_PATH, "r");
    if (!file) {
        h3p_config_save(config);
        h3p_log_printf("WARN", "config missing; wrote defaults path=%s", CONFIG_PATH);
        return false;
    }

    char line[384];
    while (fgets(line, sizeof(line), file)) {
        char *clean = trim(line);
        if (!clean[0] || clean[0] == '#') {
            continue;
        }
        char *equals = strchr(clean, '=');
        if (!equals) {
            continue;
        }
        *equals = '\0';
        char *key = trim(clean);
        char *value = trim(equals + 1);
        if (strcmp(key, "server") == 0 || strcmp(key, "server_url") == 0) {
            copy_value(config->server_url, sizeof(config->server_url), value);
        } else if (strcmp(key, "token") == 0) {
            copy_value(config->token, sizeof(config->token), value);
        } else if (strcmp(key, "start_url") == 0 || strcmp(key, "url") == 0) {
            copy_value(config->start_url, sizeof(config->start_url), value);
        } else if (strcmp(key, "quality") == 0) {
            copy_value(config->quality, sizeof(config->quality), value);
        }
    }
    fclose(file);
    if (strcmp(config->start_url, "/debug/animation") == 0) {
        snprintf(config->start_url, sizeof(config->start_url), "/start");
        h3p_config_save(config);
        h3p_log_printf("INFO", "config migrated start_url=/start");
    }
    h3p_log_printf("INFO", "config loaded server=%s start_url=%s quality=%s", config->server_url, config->start_url, config->quality);
    return true;
}

bool h3p_config_save(const H3PClientConfig *config) {
    if (!config) {
        return false;
    }
    FILE *file = fopen(CONFIG_PATH, "w");
    if (!file) {
        h3p_log_printf("WARN", "config save failed path=%s", CONFIG_PATH);
        return false;
    }
    fprintf(file, "# H3Proxy 3DS client config\n");
    fprintf(file, "# Edit server to your PC/server LAN IP before hardware testing.\n");
    fprintf(file, "server=%s\n", config->server_url);
    fprintf(file, "start_url=%s\n", config->start_url);
    fprintf(file, "quality=%s\n", config->quality);
    fprintf(file, "token=%s\n", config->token);
    fclose(file);
    h3p_log_printf("INFO", "config saved path=%s", CONFIG_PATH);
    return true;
}

const char *h3p_config_path(void) {
    return CONFIG_PATH;
}

void h3p_config_resolve_start_url(const H3PClientConfig *config, char *out, size_t out_len) {
    if (!out || out_len == 0) {
        return;
    }
    out[0] = '\0';
    if (!config) {
        return;
    }
    if (
        strncmp(config->start_url, "http://", 7) == 0 ||
        strncmp(config->start_url, "https://", 8) == 0 ||
        strncmp(config->start_url, "about:", 6) == 0
    ) {
        snprintf(out, out_len, "%s", config->start_url);
        return;
    }
    if (config->start_url[0] != '/') {
        snprintf(out, out_len, "%s", config->start_url);
        return;
    }

    const char *server = config->server_url;
    const char *scheme = "http://";
    if (strncmp(server, "http://", 7) == 0) {
        server += 7;
        scheme = "http://";
    } else if (strncmp(server, "https://", 8) == 0) {
        server += 8;
        scheme = "https://";
    } else if (strncmp(server, "ws://", 5) == 0) {
        server += 5;
        scheme = "http://";
    } else if (strncmp(server, "wss://", 6) == 0) {
        server += 6;
        scheme = "https://";
    }

    char host[160];
    size_t i = 0;
    while (server[i] && server[i] != '/' && i + 1 < sizeof(host)) {
        host[i] = server[i];
        i++;
    }
    host[i] = '\0';
    snprintf(out, out_len, "%s%s%s", scheme, host, config->start_url);
}
