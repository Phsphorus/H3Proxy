#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "calibration.h"
#include "connection_setup.h"
#include "config_store.h"
#include "image_decode.h"
#include "input.h"
#include "logger.h"
#include "net_client.h"
#include "protocol.h"
#include "renderer.h"
#include "ui.h"

typedef struct {
    uint32_t tiles;
    uint32_t media_frames;
    uint32_t dropped_frames;
    uint32_t last_decode_ms;
    uint32_t max_tile_decode_ms;
    uint32_t max_media_decode_ms;
    int active_media_dom_id;
    int dom_ids[64];
    char dom_kinds[64][12];
    int dom_count;
    int selected_dom_index;
    char text_input[256];
    uint32_t last_tile_frame_id;
    uint32_t fps_frame_count;
    uint32_t observed_fps_x10;
    u64 fps_window_started_at;
    uint32_t dom_map_messages;
    int last_logged_dom_count;
    int last_logged_selected_dom_id;
} H3PRuntimeStats;

static const char *input_kind_name(H3PInputKind kind) {
    switch (kind) {
        case H3P_INPUT_BACK: return "back";
        case H3P_INPUT_FORWARD: return "forward";
        case H3P_INPUT_RELOAD: return "reload";
        case H3P_INPUT_ENTER: return "enter";
        case H3P_INPUT_DESELECT: return "deselect";
        case H3P_INPUT_DOCK_WEBVIEW_TOP: return "dock_webview_top";
        case H3P_INPUT_DOCK_WEBVIEW_BOTTOM: return "dock_webview_bottom";
        case H3P_INPUT_SCROLL: return "scroll";
        case H3P_INPUT_TOUCH_DOWN: return "touch_down";
        case H3P_INPUT_TOUCH_MOVE: return "touch_move";
        case H3P_INPUT_TOUCH_UP: return "touch_up";
        case H3P_INPUT_DOCK_TOUCH: return "dock_touch";
        case H3P_INPUT_SELECT: return "select";
        case H3P_INPUT_NONE: return "none";
        default: return "unknown";
    }
}

static void log_input_event(const H3PInputEvent *event) {
    if (!event) {
        return;
    }
    static uint32_t scroll_logs = 0;
    static uint32_t touch_move_logs = 0;
    if (event->kind == H3P_INPUT_SCROLL) {
        scroll_logs++;
        if ((scroll_logs % 8u) != 1u) {
            return;
        }
    } else if (event->kind == H3P_INPUT_TOUCH_MOVE) {
        touch_move_logs++;
        if ((touch_move_logs % 8u) != 1u) {
            return;
        }
    }
    h3p_log_printf(
        "INPUT",
        "kind=%s x=%d y=%d dx=%d dy=%d",
        input_kind_name(event->kind),
        event->x,
        event->y,
        event->dx,
        event->dy
    );
}

static void draw_debug_frame(const H3PUIState *ui, const H3PClientConfig *config, const H3PRuntimeStats *stats) {
    if (ui && ui->error_active) {
        h3p_renderer_present_error(
            ui->error_code,
            ui->error_detail,
            ui->url,
            ui->title,
            ui->error_fatal
        );
        return;
    }
    bool show_page_on_bottom = ui && ui->webview_on_bottom && !ui->debug_overlay;
    h3p_renderer_set_bottom_info(
        config ? config->start_url : "/start",
        stats ? stats->text_input : "",
        stats ? stats->observed_fps_x10 : 0
    );
    h3p_renderer_set_bottom_ui(ui && !ui->debug_overlay, show_page_on_bottom);
    h3p_renderer_begin_frame();
    if (!h3p_renderer_has_content()) {
        h3p_ui_draw_top_debug(ui);
    }
    h3p_renderer_end_frame();
}

static void note_content_frame(H3PRuntimeStats *stats) {
    if (!stats) {
        return;
    }
    u64 now = osGetTime();
    if (stats->fps_window_started_at == 0) {
        stats->fps_window_started_at = now;
    }
    stats->fps_frame_count++;
    u64 elapsed = now - stats->fps_window_started_at;
    if (elapsed >= 1000) {
        stats->observed_fps_x10 = (uint32_t)((stats->fps_frame_count * 10000ULL) / elapsed);
        stats->fps_frame_count = 0;
        stats->fps_window_started_at = now;
    }
}

static void send_input_event_to_server(H3PNetClient *net, const H3PInputEvent *event) {
    if (!net || !event || !h3p_net_is_connected(net)) {
        return;
    }
    switch (event->kind) {
        case H3P_INPUT_BACK:
            h3p_net_send_text(net, "{\"type\":\"back\"}");
            break;
        case H3P_INPUT_FORWARD:
            h3p_net_send_text(net, "{\"type\":\"forward\"}");
            break;
        case H3P_INPUT_RELOAD:
            h3p_net_send_text(net, "{\"type\":\"reload\"}");
            break;
        case H3P_INPUT_ENTER:
            h3p_net_send_text(net, "{\"type\":\"key\",\"key\":\"Enter\"}");
            break;
        case H3P_INPUT_DESELECT:
            h3p_net_send_text(net, "{\"type\":\"key\",\"key\":\"Escape\"}");
            break;
        case H3P_INPUT_SCROLL:
            h3p_net_send_textf(net, "{\"type\":\"scroll\",\"dx\":%d,\"dy\":%d}", event->dx, event->dy);
            break;
        case H3P_INPUT_TOUCH_DOWN:
            h3p_net_send_textf(net, "{\"type\":\"touch_down\",\"x\":%d,\"y\":%d}", event->x, event->y);
            break;
        case H3P_INPUT_TOUCH_MOVE:
            h3p_net_send_textf(net, "{\"type\":\"touch_move\",\"x\":%d,\"y\":%d}", event->x, event->y);
            break;
        case H3P_INPUT_TOUCH_UP:
            h3p_net_send_textf(net, "{\"type\":\"touch_up\",\"x\":%d,\"y\":%d}", event->x, event->y);
            break;
        default:
            break;
    }
}

static void update_tile_decode_stats(H3PRuntimeStats *stats, uint32_t decode_ms) {
    if (!stats) {
        return;
    }
    stats->last_decode_ms = decode_ms;
    if (decode_ms > stats->max_tile_decode_ms) {
        stats->max_tile_decode_ms = decode_ms;
    }
}

static void update_media_decode_stats(H3PRuntimeStats *stats, uint32_t decode_ms) {
    if (!stats) {
        return;
    }
    stats->last_decode_ms = decode_ms;
    if (decode_ms > stats->max_media_decode_ms) {
        stats->max_media_decode_ms = decode_ms;
    }
}

static void update_dom_map_from_json(const char *text, H3PUIState *ui, H3PRuntimeStats *stats);

static bool is_noisy_status_state(const char *state) {
    return strcmp(state, "client_stats") == 0 ||
        strcmp(state, "scrolled") == 0 ||
        strcmp(state, "key") == 0 ||
        strcmp(state, "text") == 0 ||
        strcmp(state, "media_started") == 0 ||
        strcmp(state, "media_stopped") == 0 ||
        strcmp(state, "browser_busy") == 0 ||
        strcmp(state, "touch_down") == 0 ||
        strcmp(state, "touch_move") == 0 ||
        strcmp(state, "touch_up") == 0;
}

static void process_binary_message(const H3PNetMessage *message, H3PUIState *ui, H3PRuntimeStats *stats) {
    if (!message || !message->data || !ui || !stats) {
        return;
    }
    H3PBinaryFrame frame;
    if (!h3p_parse_binary_frame(message->data, message->len, &frame)) {
        stats->dropped_frames++;
        h3p_log_printf("BIN", "bad binary packet len=%lu", (unsigned long)message->len);
        return;
    }

    H3PTilePacket tile;
    if (h3p_parse_tile_packet(&frame, &tile)) {
        H3PDecodedImage image;
        u64 started = osGetTime();
        int rc = h3p_decode_image_rgb565(tile.payload, tile.payload_len, &image);
        uint32_t decode_ms = (uint32_t)(osGetTime() - started);
        if (rc == 0) {
            h3p_renderer_draw_image_rgb565(tile.x, tile.y, tile.w, tile.h, image.rgb565, image.width, image.height);
            stats->tiles++;
            if (tile.frame_id != stats->last_tile_frame_id) {
                stats->last_tile_frame_id = tile.frame_id;
                note_content_frame(stats);
            }
            update_tile_decode_stats(stats, decode_ms);
            if ((stats->tiles % 64u) == 0u) {
                h3p_log_printf("TILE", "sample frame=%lu id=%s xy=%d,%d wh=%d,%d fmt=%s bytes=%lu decode_ms=%lu",
                    (unsigned long)tile.frame_id, tile.tile_id, tile.x, tile.y, tile.w, tile.h, tile.format,
                    (unsigned long)tile.payload_len, (unsigned long)decode_ms);
            }
            h3p_free_decoded_image(&image);
        } else {
            stats->dropped_frames++;
            h3p_log_printf("TILE", "decode failed rc=%d bytes=%lu fmt=%s", rc, (unsigned long)tile.payload_len, tile.format);
        }
        return;
    }

    H3PMediaFramePacket media;
    if (h3p_parse_media_frame_packet(&frame, &media)) {
        H3PDecodedImage image;
        u64 started = osGetTime();
        int rc = h3p_decode_image_rgb565(media.payload, media.payload_len, &image);
        uint32_t decode_ms = (uint32_t)(osGetTime() - started);
        if (rc == 0) {
            h3p_renderer_draw_image_rgb565(media.x, media.y, media.w, media.h, image.rgb565, image.width, image.height);
            stats->media_frames++;
            note_content_frame(stats);
            update_media_decode_stats(stats, decode_ms);
            if ((stats->media_frames % 30u) == 0u) {
                h3p_log_printf("MEDIA", "sample frame=%lu dom=%d xy=%d,%d wh=%d,%d bytes=%lu decode_ms=%lu",
                    (unsigned long)media.frame_id, media.dom_id, media.x, media.y, media.w, media.h,
                    (unsigned long)media.payload_len, (unsigned long)decode_ms);
            }
            h3p_free_decoded_image(&image);
        } else {
            stats->dropped_frames++;
            h3p_log_printf("MEDIA", "decode failed rc=%d bytes=%lu fmt=%s", rc, (unsigned long)media.payload_len, media.format);
        }
        return;
    }

    h3p_log_printf("BIN", "unknown binary header_len=%lu payload_len=%lu", (unsigned long)frame.header_len, (unsigned long)frame.payload_len);
}

static void process_text_message(const char *text, H3PNetClient *net, H3PUIState *ui, H3PRuntimeStats *stats) {
    if (!text || !ui || !stats) {
        return;
    }
    char type[32];
    if (!h3p_json_get_type(text, type, sizeof(type))) {
        h3p_log_printf("TEXT", "untyped len=%lu", (unsigned long)strlen(text));
        return;
    }
    if (ui->error_active && strcmp(type, "error") != 0) {
        return;
    }

    if (strcmp(type, "hello") == 0) {
        ui->connected = true;
        h3p_ui_set_status(ui, "Connected to H3Proxy");
        h3p_log_printf("TEXT", "hello %s", text);
    } else if (strcmp(type, "status") == 0) {
        char state[48];
        if (h3p_json_get_string(text, "state", state, sizeof(state))) {
            if (!is_noisy_status_state(state)) {
                char status[H3P_UI_STATUS_BYTES];
                snprintf(status, sizeof(status), "server status: %s", state);
                h3p_ui_set_status(ui, status);
                h3p_log_printf("TEXT", "%s", text);
            }
        }
    } else if (strcmp(type, "error") == 0) {
        char code[48];
        char detail[H3P_UI_ERROR_DETAIL_BYTES];
        h3p_json_get_string(text, "code", code, sizeof(code));
        h3p_json_get_string(text, "detail", detail, sizeof(detail));
        bool fatal = strstr(text, "\"fatal\":true") != NULL;
        h3p_ui_set_error(ui, code, detail, fatal);
        h3p_log_printf("ERR", "%s", text);
    } else if (strcmp(type, "page_meta") == 0) {
        char old_url[H3P_UI_URL_BYTES];
        char old_title[H3P_UI_TITLE_BYTES];
        strncpy(old_url, ui->url, sizeof(old_url));
        old_url[sizeof(old_url) - 1] = '\0';
        strncpy(old_title, ui->title, sizeof(old_title));
        old_title[sizeof(old_title) - 1] = '\0';
        h3p_json_get_string(text, "url", ui->url, sizeof(ui->url));
        h3p_json_get_string(text, "title", ui->title, sizeof(ui->title));
        if (strcmp(old_url, ui->url) != 0 || strcmp(old_title, ui->title) != 0) {
            h3p_log_printf("META", "url=%s title=%s", ui->url, ui->title);
        }
    } else if (strcmp(type, "frame_done") == 0) {
        int frame_id = 0;
        int changed = 0;
        int capture_ms = 0;
        h3p_json_get_int(text, "frame_id", &frame_id);
        h3p_json_get_int(text, "changed_tiles", &changed);
        h3p_json_get_int(text, "capture_ms", &capture_ms);
        if (capture_ms >= 200 || (frame_id > 0 && (frame_id % 60) == 0)) {
            h3p_log_printf("FRAME", "sample %s", text);
        }
    } else if (strcmp(type, "dom_map") == 0) {
        update_dom_map_from_json(text, ui, stats);
    } else if (strcmp(type, "media_offer") == 0) {
        int dom_id = 0;
        int fps = 30;
        h3p_json_get_int(text, "dom_id", &dom_id);
        h3p_json_get_int(text, "target_fps", &fps);
        bool started = false;
        if (dom_id > 0 && stats->active_media_dom_id != dom_id && h3p_net_is_connected(net)) {
            if (fps <= 0) {
                fps = 30;
            }
            if (fps > 60) {
                fps = 60;
            }
            h3p_net_send_textf(net, "{\"type\":\"start_media\",\"dom_id\":%d,\"fps\":%d,\"jpeg_quality\":55}", dom_id, fps);
            stats->active_media_dom_id = dom_id;
            h3p_log_printf("MEDIA", "auto start dom=%d fps=%d", dom_id, fps);
            started = true;
        }
        static uint32_t media_offer_logs = 0;
        media_offer_logs++;
        if (started || (media_offer_logs % 30u) == 1u) {
            h3p_log_printf("TEXT", "sample %s", text);
        }
    } else if (strcmp(type, "media_stop") == 0) {
        stats->active_media_dom_id = -1;
        h3p_log_printf("MEDIA", "stop %s", text);
    } else if (strcmp(type, "client_policy") == 0 || strcmp(type, "server_policy") == 0 || strcmp(type, "media_start") == 0) {
        h3p_log_printf("TEXT", "%s", text);
    }
}

static void send_client_stats(H3PNetClient *net, const H3PRuntimeStats *stats) {
    if (!net || !stats || !h3p_net_is_connected(net)) {
        return;
    }
    uint32_t max_decode_ms = stats->max_tile_decode_ms > stats->max_media_decode_ms ? stats->max_tile_decode_ms : stats->max_media_decode_ms;
    h3p_log_printf(
        "PERF",
        "fps=%lu.%lu tile_decode_max=%lu media_decode_max=%lu dropped=%lu tiles=%lu media=%lu",
        (unsigned long)(stats->observed_fps_x10 / 10u),
        (unsigned long)(stats->observed_fps_x10 % 10u),
        (unsigned long)stats->max_tile_decode_ms,
        (unsigned long)stats->max_media_decode_ms,
        (unsigned long)stats->dropped_frames,
        (unsigned long)stats->tiles,
        (unsigned long)stats->media_frames
    );
    h3p_net_send_textf(
        net,
        "{\"type\":\"client_stats\",\"decode_ms_p95\":%lu,\"queue_bytes\":0,\"dropped_frames\":%lu,"
        "\"vram_used_bytes\":192000,\"ram_used_bytes\":2097152,\"media_decode_ms_p95\":%lu,\"tile_decode_ms_p95\":%lu}",
        (unsigned long)max_decode_ms,
        (unsigned long)stats->dropped_frames,
        (unsigned long)stats->max_media_decode_ms,
        (unsigned long)stats->max_tile_decode_ms
    );
}

static void json_escape(const char *in, char *out, size_t out_len) {
    if (!out || out_len == 0) {
        return;
    }
    out[0] = '\0';
    if (!in) {
        return;
    }
    size_t used = 0;
    for (const char *p = in; *p && used + 1 < out_len; p++) {
        if ((*p == '"' || *p == '\\') && used + 2 < out_len) {
            out[used++] = '\\';
            out[used++] = *p;
        } else if ((unsigned char)*p >= 0x20) {
            out[used++] = *p;
        }
    }
    out[used] = '\0';
}

static bool keyboard_input(const char *hint, const char *initial, char *out, size_t out_len) {
    if (!out || out_len == 0) {
        return false;
    }
    SwkbdState swkbd;
    swkbdInit(&swkbd, SWKBD_TYPE_WESTERN, 2, (int)out_len - 1);
    swkbdSetInitialText(&swkbd, initial ? initial : "");
    swkbdSetHintText(&swkbd, hint ? hint : "");
    swkbdSetButton(&swkbd, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&swkbd, SWKBD_BUTTON_RIGHT, "OK", true);
    swkbdSetValidation(&swkbd, SWKBD_NOTEMPTY_NOTBLANK, 0, 0);
    SwkbdButton button = swkbdInputText(&swkbd, out, out_len);
    return button == SWKBD_BUTTON_RIGHT;
}

static void send_open_url(H3PNetClient *net, H3PClientConfig *config, H3PUIState *ui) {
    if (!net || !config || !h3p_net_is_connected(net)) {
        return;
    }
    char resolved[H3P_START_URL_BYTES];
    char escaped[H3P_START_URL_BYTES * 2];
    h3p_config_resolve_start_url(config, resolved, sizeof(resolved));
    json_escape(resolved, escaped, sizeof(escaped));
    h3p_net_send_textf(net, "{\"type\":\"open_url\",\"url\":\"%s\"}", escaped);
    h3p_log_printf("DOCK", "open_url %s", resolved);
    if (ui) {
        h3p_ui_set_status(ui, "Dock Go");
    }
}

static void update_dom_map_from_json(const char *text, H3PUIState *ui, H3PRuntimeStats *stats) {
    if (!text || !stats) {
        return;
    }
    stats->dom_count = 0;
    const char *cursor = text;
    while (stats->dom_count < (int)(sizeof(stats->dom_ids) / sizeof(stats->dom_ids[0]))) {
        const char *found = strstr(cursor, "{\"id\":");
        if (!found) {
            break;
        }
        const char *object_end = strchr(found, '}');
        found += 6;
        int id = atoi(found);
        if (id > 0) {
            int index = stats->dom_count++;
            stats->dom_ids[index] = id;
            snprintf(stats->dom_kinds[index], sizeof(stats->dom_kinds[index]), "item");
            const char *kind = strstr(found, "\"kind\":\"");
            if (kind && (!object_end || kind < object_end)) {
                kind += 8;
                size_t len = 0;
                while (kind[len] && kind[len] != '"' && len + 1 < sizeof(stats->dom_kinds[index])) {
                    len++;
                }
                memcpy(stats->dom_kinds[index], kind, len);
                stats->dom_kinds[index][len] = '\0';
            }
        }
        cursor = object_end ? object_end + 1 : found;
    }
    if (stats->dom_count <= 0) {
        stats->selected_dom_index = -1;
    } else if (stats->selected_dom_index < 0 || stats->selected_dom_index >= stats->dom_count) {
        stats->selected_dom_index = 0;
    }
    if (ui) {
        ui->dom_count = stats->dom_count;
        ui->selected_dom_id = stats->selected_dom_index >= 0 ? stats->dom_ids[stats->selected_dom_index] : -1;
    }
    stats->dom_map_messages++;
    int selected_id = ui ? ui->selected_dom_id : -1;
    if (stats->dom_count != stats->last_logged_dom_count ||
        selected_id != stats->last_logged_selected_dom_id ||
        (stats->dom_map_messages % 30u) == 1u) {
        h3p_log_printf("DOM", "items=%d selected=%d", stats->dom_count, selected_id);
        stats->last_logged_dom_count = stats->dom_count;
        stats->last_logged_selected_dom_id = selected_id;
    }
}

static void handle_dock_touch(H3PNetClient *net, H3PClientConfig *config, H3PUIState *ui, H3PRuntimeStats *stats, int x, int y) {
    if (y < H3P_PAGE_PAD_H) {
        return;
    }
    int dock_y = y - H3P_PAGE_PAD_H;
    if (dock_y < 30) {
        if (x >= 280) {
            send_open_url(net, config, ui);
            return;
        }
        char typed[H3P_START_URL_BYTES];
        if (keyboard_input("URL or server path", config ? config->start_url : "", typed, sizeof(typed))) {
            snprintf(config->start_url, sizeof(config->start_url), "%s", typed);
            h3p_config_save(config);
            if (ui) {
                h3p_ui_set_status(ui, "URL updated");
            }
            h3p_log_printf("DOCK", "url updated %s", config->start_url);
        }
        return;
    }

    if (x >= 262) {
        if (net && h3p_net_is_connected(net)) {
            h3p_net_send_text(net, "{\"type\":\"key\",\"key\":\"Enter\"}");
        }
        if (ui) {
            h3p_ui_set_status(ui, "Text Enter");
        }
    } else {
        char typed[sizeof(stats->text_input)];
        const char *initial = stats ? stats->text_input : "";
        if (keyboard_input("Text to website", initial, typed, sizeof(typed))) {
            if (stats) {
                snprintf(stats->text_input, sizeof(stats->text_input), "%s", typed);
            }
            if (net && h3p_net_is_connected(net)) {
                char escaped[512];
                json_escape(typed, escaped, sizeof(escaped));
                h3p_net_send_textf(net, "{\"type\":\"text\",\"text\":\"%s\"}", escaped);
            }
            if (ui) {
                h3p_ui_set_status(ui, "Text sent");
            }
            h3p_log_printf("DOCK", "text sent len=%lu", (unsigned long)strlen(typed));
        }
    }
}

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    gfxInit(GSP_RGB565_OES, GSP_BGR8_OES, false);
    PrintConsole top_console;
    PrintConsole bottom_console;
    consoleInit(GFX_TOP, &top_console);
    consoleInit(GFX_BOTTOM, &bottom_console);
    h3p_ui_set_consoles(&top_console, &bottom_console);
    h3p_log_init();
    h3p_log_printf("INFO", "boot start");
    osSetSpeedupEnable(true);
    h3p_log_printf("INFO", "new3ds speedup requested high_clock=true l2=true");
    h3p_log_printf("INFO", "gfx formats top=%d bottom=%d", (int)gfxGetScreenFormat(GFX_TOP), (int)gfxGetScreenFormat(GFX_BOTTOM));
    h3p_renderer_init();
    h3p_log_printf("INFO", "framebuffer renderer init ok");

    H3PInputState input;
    H3PUIState ui;
    H3PCalibratedProfile profile;
    H3PClientConfig config;
    H3PNetClient net;
    H3PRuntimeStats stats;
    memset(&net, 0, sizeof(net));
    memset(&stats, 0, sizeof(stats));
    stats.active_media_dom_id = -1;
    stats.selected_dom_index = -1;
    stats.last_logged_dom_count = -1;
    stats.last_logged_selected_dom_id = -2;
    h3p_input_init(&input);
    h3p_ui_init(&ui);
    h3p_ui_set_status(&ui, "Calibrating hardware");
    draw_debug_frame(&ui, NULL, &stats);
    gspWaitForVBlank();
    h3p_log_printf("INFO", "calibration start");
    h3p_calibration_run_safe(&profile);
    char caps_json[1024];
    int caps_len = h3p_calibration_client_caps_json(&profile, caps_json, sizeof(caps_json));
    if (caps_len > 0) {
        h3p_log_printf("CAPS", "%s", caps_json);
    } else {
        h3p_log_printf("WARN", "client caps json failed code=%d", caps_len);
    }
    h3p_log_printf(
        "INFO",
        "calibration done page_fps=%lu media_fps=%lu safe_ram=%lu cache_tiles=%lu sd_kb_s=%lu",
        (unsigned long)profile.max_page_fps,
        (unsigned long)profile.max_media_fps,
        (unsigned long)profile.safe_ram_bytes,
        (unsigned long)profile.safe_texture_cache_tiles,
        (unsigned long)profile.sd_write_kb_s
    );
    char status[H3P_UI_STATUS_BYTES];
    snprintf(status, sizeof(status), "Caps page %lu media %lu fps", (unsigned long)profile.max_page_fps, (unsigned long)profile.max_media_fps);
    h3p_ui_set_status(&ui, status);

    bool config_loaded = h3p_config_load(&config);
    char start_url[H3P_START_URL_BYTES];
    h3p_config_resolve_start_url(&config, start_url, sizeof(start_url));
    if (!config_loaded) {
        snprintf(status, sizeof(status), "Default config made");
        h3p_ui_set_status(&ui, status);
        draw_debug_frame(&ui, &config, &stats);
        gspWaitForVBlank();
    }

    bool net_ready = h3p_net_init(&net);
    u64 next_connect_at = 0;
    u64 next_stats_at = 0;
    bool run_app = true;
    if (net_ready) {
        snprintf(status, sizeof(status), "Pre-connection setup");
        h3p_ui_set_status(&ui, status);
        draw_debug_frame(&ui, &config, &stats);
        gspWaitForVBlank();
        if (h3p_connection_setup_run(&config, &net, caps_json, &top_console, &bottom_console)) {
            h3p_config_resolve_start_url(&config, start_url, sizeof(start_url));
            h3p_ui_set_status(&ui, "Network connected");
            ui.connected = true;
        } else {
            snprintf(status, sizeof(status), "Connection setup stopped");
            h3p_ui_set_status(&ui, status);
            ui.connected = false;
            run_app = false;
        }
    } else {
        snprintf(status, sizeof(status), "socInit failed: %s", h3p_net_last_error(&net));
        h3p_ui_set_status(&ui, status);
    }

    u64 start_hold_started_at = 0;
    while (run_app && aptMainLoop()) {
        hidScanInput();
        u32 held = hidKeysHeld();
        if (held & KEY_START) {
            u64 now = osGetTime();
            if (start_hold_started_at == 0) {
                start_hold_started_at = now;
                h3p_log_printf("INPUT", "kind=start_exit_hold_begin");
                h3p_ui_set_status(&ui, "Hold START 3s to quit");
            } else if (now - start_hold_started_at >= 3000) {
                h3p_log_printf("INPUT", "kind=start_exit held_ms=%lu", (unsigned long)(now - start_hold_started_at));
                break;
            }
        } else if (start_hold_started_at != 0) {
            h3p_log_printf("INPUT", "kind=start_exit_hold_cancel held_ms=%lu", (unsigned long)(osGetTime() - start_hold_started_at));
            start_hold_started_at = 0;
        }

        H3PInputEvent events[12];
        int event_count = h3p_input_poll(&input, events, 12);
        for (int i = 0; i < event_count; i++) {
            log_input_event(&events[i]);
            if (ui.error_active) {
                if (events[i].kind == H3P_INPUT_SELECT) {
                    if (ui.error_fatal) {
                        h3p_log_printf("INPUT", "kind=select fatal_error_active");
                    } else {
                        h3p_log_printf("INPUT", "kind=select clear_nonfatal_error code=%s", ui.error_code);
                        h3p_ui_clear_nonfatal_error(&ui);
                    }
                }
                continue;
            }
            send_input_event_to_server(&net, &events[i]);
            switch (events[i].kind) {
                case H3P_INPUT_BACK:
                    h3p_ui_set_status(&ui, "L back event");
                    break;
                case H3P_INPUT_FORWARD:
                    h3p_ui_set_status(&ui, "R forward event");
                    break;
                case H3P_INPUT_RELOAD:
                    h3p_ui_set_status(&ui, "ZL reload event");
                    break;
                case H3P_INPUT_ENTER:
                    h3p_ui_set_status(&ui, "A enter event");
                    break;
                case H3P_INPUT_DESELECT:
                    stats.selected_dom_index = -1;
                    ui.selected_dom_id = -1;
                    h3p_ui_set_status(&ui, "B deselect event");
                    break;
                case H3P_INPUT_DOCK_WEBVIEW_TOP:
                    ui.mode = H3P_UI_PAGE;
                    ui.webview_on_bottom = false;
                    h3p_ui_set_status(&ui, "X top webview event");
                    break;
                case H3P_INPUT_DOCK_WEBVIEW_BOTTOM:
                    ui.mode = H3P_UI_PAGE;
                    ui.webview_on_bottom = true;
                    h3p_ui_set_status(&ui, "Y bottom webview event");
                    break;
                case H3P_INPUT_SCROLL:
                    break;
                case H3P_INPUT_TOUCH_DOWN:
                    break;
                case H3P_INPUT_TOUCH_MOVE:
                    break;
                case H3P_INPUT_TOUCH_UP:
                    break;
                case H3P_INPUT_DOCK_TOUCH:
                    handle_dock_touch(&net, &config, &ui, &stats, events[i].x, events[i].y);
                    break;
                case H3P_INPUT_SELECT:
                    ui.debug_overlay = !ui.debug_overlay;
                    ui.mode = ui.debug_overlay ? H3P_UI_DEBUG : H3P_UI_PAGE;
                    h3p_ui_set_status(&ui, ui.debug_overlay ? "Debug/log view" : "Debug/log view off");
                    break;
                default:
                    break;
            }
        }

        u64 now = osGetTime();
        if (net_ready && !h3p_net_is_connected(&net) && now >= next_connect_at) {
            h3p_ui_set_status(&ui, "Reconnecting H3Proxy");
            h3p_config_resolve_start_url(&config, start_url, sizeof(start_url));
            if (h3p_net_connect(&net, &config, caps_json, start_url)) {
                h3p_ui_set_status(&ui, "Network connected");
                ui.connected = true;
                stats.active_media_dom_id = -1;
            } else {
                snprintf(status, sizeof(status), "Net failed: %s", h3p_net_last_error(&net));
                h3p_ui_set_status(&ui, status);
                ui.connected = false;
                next_connect_at = osGetTime() + 5000;
            }
        }

        if (h3p_net_is_connected(&net)) {
            for (int i = 0; i < 8; i++) {
                H3PNetMessage message;
                int polled = h3p_net_poll(&net, &message);
                if (polled == 1) {
                    if (message.kind == H3P_NET_MESSAGE_TEXT) {
                        process_text_message(message.text, &net, &ui, &stats);
                    } else if (message.kind == H3P_NET_MESSAGE_BINARY && !ui.error_active) {
                        process_binary_message(&message, &ui, &stats);
                    }
                    continue;
                }
                if (message.kind == H3P_NET_MESSAGE_CLOSED || message.kind == H3P_NET_MESSAGE_ERROR) {
                    ui.connected = false;
                    stats.active_media_dom_id = -1;
                    h3p_ui_set_status(&ui, "Network closed; retrying");
                    next_connect_at = osGetTime() + 3000;
                }
                break;
            }

            if (osGetTime() >= next_stats_at) {
                send_client_stats(&net, &stats);
                next_stats_at = osGetTime() + 2000;
            }
        }

        draw_debug_frame(&ui, &config, &stats);
        gspWaitForVBlank();
    }

    h3p_log_printf("INFO", "shutdown start");
    h3p_net_shutdown(&net);
    h3p_renderer_shutdown();
    h3p_log_printf("INFO", "renderer shutdown ok");
    h3p_log_close();
    gfxExit();
    return 0;
}
