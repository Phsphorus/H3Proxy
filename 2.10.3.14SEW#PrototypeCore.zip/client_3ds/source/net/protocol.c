#include "protocol.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool h3p_parse_binary_frame(const uint8_t *data, size_t len, H3PBinaryFrame *out) {
    if (!data || !out || len < H3P_HEADER_PREFIX_BYTES) {
        return false;
    }

    uint32_t header_len =
        ((uint32_t)data[0] << 24) |
        ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) |
        (uint32_t)data[3];

    if (header_len == 0 || header_len > H3P_MAX_HEADER_BYTES) {
        return false;
    }

    size_t payload_offset = H3P_HEADER_PREFIX_BYTES + (size_t)header_len;
    if (payload_offset > len) {
        return false;
    }

    out->header_len = header_len;
    out->header_json = data + H3P_HEADER_PREFIX_BYTES;
    out->payload_offset = payload_offset;
    out->payload_len = len - payload_offset;
    return true;
}

static bool copy_header_json(const H3PBinaryFrame *frame, char *out, size_t out_len) {
    if (!frame || !out || out_len == 0 || frame->header_len + 1 > out_len) {
        return false;
    }
    memcpy(out, frame->header_json, frame->header_len);
    out[frame->header_len] = '\0';
    return true;
}

bool h3p_json_get_string(const char *json, const char *key, char *out, size_t out_len) {
    if (!json || !key || !out || out_len == 0) {
        return false;
    }
    out[0] = '\0';

    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\":\"", key);
    const char *start = strstr(json, pattern);
    if (!start) {
        return false;
    }
    start += strlen(pattern);

    size_t used = 0;
    while (*start && *start != '"' && used + 1 < out_len) {
        if (*start == '\\' && start[1]) {
            start++;
        }
        out[used++] = *start++;
    }
    out[used] = '\0';
    return true;
}

bool h3p_json_get_int(const char *json, const char *key, int *out) {
    if (!json || !key || !out) {
        return false;
    }
    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\":", key);
    const char *start = strstr(json, pattern);
    if (!start) {
        return false;
    }
    start += strlen(pattern);
    while (*start == ' ' || *start == '\t') {
        start++;
    }
    *out = atoi(start);
    return true;
}

bool h3p_json_get_type(const char *json, char *out, size_t out_len) {
    return h3p_json_get_string(json, "type", out, out_len);
}

bool h3p_parse_tile_packet(const H3PBinaryFrame *frame, H3PTilePacket *out) {
    if (!frame || !out) {
        return false;
    }
    char header[H3P_MAX_HEADER_BYTES + 1];
    if (!copy_header_json(frame, header, sizeof(header))) {
        return false;
    }
    char type[24];
    if (!h3p_json_get_type(header, type, sizeof(type)) || strcmp(type, "tile") != 0) {
        return false;
    }

    memset(out, 0, sizeof(*out));
    int value = 0;
    if (h3p_json_get_int(header, "frame_id", &value)) out->frame_id = (uint32_t)value;
    h3p_json_get_string(header, "tile_id", out->tile_id, sizeof(out->tile_id));
    h3p_json_get_int(header, "x", &out->x);
    h3p_json_get_int(header, "y", &out->y);
    h3p_json_get_int(header, "w", &out->w);
    h3p_json_get_int(header, "h", &out->h);
    h3p_json_get_string(header, "format", out->format, sizeof(out->format));
    out->payload = frame->header_json + frame->header_len;
    out->payload_len = frame->payload_len;
    return out->w > 0 && out->h > 0 && out->payload_len > 0;
}

bool h3p_parse_media_frame_packet(const H3PBinaryFrame *frame, H3PMediaFramePacket *out) {
    if (!frame || !out) {
        return false;
    }
    char header[H3P_MAX_HEADER_BYTES + 1];
    if (!copy_header_json(frame, header, sizeof(header))) {
        return false;
    }
    char type[24];
    if (!h3p_json_get_type(header, type, sizeof(type)) || strcmp(type, "media_frame") != 0) {
        return false;
    }

    memset(out, 0, sizeof(*out));
    int value = 0;
    if (h3p_json_get_int(header, "frame_id", &value)) out->frame_id = (uint32_t)value;
    if (h3p_json_get_int(header, "page_frame_id", &value)) out->page_frame_id = (uint32_t)value;
    h3p_json_get_string(header, "media_id", out->media_id, sizeof(out->media_id));
    h3p_json_get_int(header, "dom_id", &out->dom_id);
    h3p_json_get_int(header, "x", &out->x);
    h3p_json_get_int(header, "y", &out->y);
    h3p_json_get_int(header, "w", &out->w);
    h3p_json_get_int(header, "h", &out->h);
    h3p_json_get_string(header, "format", out->format, sizeof(out->format));
    out->payload = frame->header_json + frame->header_len;
    out->payload_len = frame->payload_len;
    return out->w > 0 && out->h > 0 && out->payload_len > 0;
}
