#include "net_client.h"

#include <3ds.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <netdb.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "logger.h"

#define SOC_ALIGN 0x1000
#define SOC_BUFFERSIZE 0x100000
#define H3P_NET_TIMEOUT_MS 6000

typedef struct {
    char scheme[8];
    char host[128];
    char path[256];
    int port;
} H3PParsedUrl;

static u32 *s_soc_buffer = NULL;

static void set_last_error(H3PNetClient *client, const char *fmt, ...) {
    if (!client) {
        return;
    }
    va_list args;
    va_start(args, fmt);
    vsnprintf(client->last_error, sizeof(client->last_error), fmt ? fmt : "", args);
    va_end(args);
    h3p_log_printf("NET", "error=%s", client->last_error);
}

static bool parse_url(const char *url, H3PParsedUrl *out) {
    if (!url || !out) {
        return false;
    }
    memset(out, 0, sizeof(*out));

    const char *cursor = url;
    const char *scheme_end = strstr(cursor, "://");
    if (scheme_end) {
        size_t scheme_len = (size_t)(scheme_end - cursor);
        if (scheme_len >= sizeof(out->scheme)) {
            return false;
        }
        memcpy(out->scheme, cursor, scheme_len);
        out->scheme[scheme_len] = '\0';
        cursor = scheme_end + 3;
    } else {
        snprintf(out->scheme, sizeof(out->scheme), "http");
    }

    const char *path = strchr(cursor, '/');
    size_t host_len = path ? (size_t)(path - cursor) : strlen(cursor);
    if (host_len == 0 || host_len >= sizeof(out->host)) {
        return false;
    }
    memcpy(out->host, cursor, host_len);
    out->host[host_len] = '\0';
    snprintf(out->path, sizeof(out->path), "%s", path ? path : "/");

    char *colon = strchr(out->host, ':');
    if (colon) {
        *colon = '\0';
        out->port = atoi(colon + 1);
    }
    if (out->port <= 0) {
        if (strcmp(out->scheme, "https") == 0 || strcmp(out->scheme, "wss") == 0) {
            out->port = 443;
        } else {
            out->port = 80;
        }
    }
    return out->host[0] != '\0';
}

static bool is_secure_scheme(const char *scheme) {
    return strcmp(scheme, "https") == 0 || strcmp(scheme, "wss") == 0;
}

static void socket_set_nonblocking(int sock, bool nonblocking) {
    int flags = fcntl(sock, F_GETFL, 0);
    if (flags < 0) {
        return;
    }
    if (nonblocking) {
        flags |= O_NONBLOCK;
    } else {
        flags &= ~O_NONBLOCK;
    }
    fcntl(sock, F_SETFL, flags);
}

static int connect_tcp(H3PNetClient *client, const char *host, int port) {
    char port_text[16];
    snprintf(port_text, sizeof(port_text), "%d", port);

    struct addrinfo hints;
    struct addrinfo *resaddr = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    h3p_log_printf("NET", "resolve host=%s port=%d", host, port);
    int gai = getaddrinfo(host, port_text, &hints, &resaddr);
    if (gai != 0 || !resaddr) {
        set_last_error(client, "getaddrinfo failed host=%s code=%d", host, gai);
        return -1;
    }

    int sock = -1;
    for (struct addrinfo *cur = resaddr; cur; cur = cur->ai_next) {
        sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
            continue;
        }
        h3p_log_printf("NET", "connect attempt host=%s port=%d", host, port);
        if (connect(sock, cur->ai_addr, cur->ai_addrlen) == 0) {
            break;
        }
        close(sock);
        sock = -1;
    }
    freeaddrinfo(resaddr);

    if (sock < 0) {
        set_last_error(client, "connect failed host=%s port=%d errno=%d", host, port, errno);
        return -1;
    }
    return sock;
}

static bool send_all(H3PNetClient *client, int sock, const uint8_t *data, size_t len) {
    size_t sent = 0;
    u64 started = osGetTime();
    while (sent < len) {
        ssize_t wrote = send(sock, data + sent, len - sent, 0);
        if (wrote > 0) {
            sent += (size_t)wrote;
            continue;
        }
        if (wrote < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            if (osGetTime() - started > H3P_NET_TIMEOUT_MS) {
                set_last_error(client, "send timeout bytes=%lu/%lu", (unsigned long)sent, (unsigned long)len);
                return false;
            }
            svcSleepThread(1000000);
            continue;
        }
        set_last_error(client, "send failed errno=%d", errno);
        return false;
    }
    return true;
}

static int recv_until(H3PNetClient *client, int sock, char *out, size_t out_len, const char *marker, bool allow_close) {
    if (!out || out_len == 0) {
        return -1;
    }
    out[0] = '\0';
    size_t used = 0;
    u64 started = osGetTime();
    socket_set_nonblocking(sock, true);

    while (used + 1 < out_len) {
        ssize_t got = recv(sock, out + used, out_len - used - 1, 0);
        if (got > 0) {
            used += (size_t)got;
            out[used] = '\0';
            if (marker && strstr(out, marker)) {
                return (int)used;
            }
            continue;
        }
        if (got == 0) {
            return allow_close ? (int)used : -1;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            if (osGetTime() - started > H3P_NET_TIMEOUT_MS) {
                set_last_error(client, "recv timeout");
                return -1;
            }
            svcSleepThread(1000000);
            continue;
        }
        set_last_error(client, "recv failed errno=%d", errno);
        return -1;
    }
    set_last_error(client, "recv buffer full");
    return -1;
}

static bool extract_json_string(const char *json, const char *key, char *out, size_t out_len) {
    if (!json || !key || !out || out_len == 0) {
        return false;
    }
    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\":\"", key);
    const char *start = strstr(json, pattern);
    if (!start) {
        return false;
    }
    start += strlen(pattern);
    size_t used = 0;
    while (*start && *start != '"' && used + 1 < out_len) {
        out[used++] = *start++;
    }
    out[used] = '\0';
    return true;
}

static bool create_session_path(H3PNetClient *client, const H3PClientConfig *config, const H3PParsedUrl *base, char *path_out, size_t path_out_len) {
    if (config->token[0]) {
        snprintf(path_out, path_out_len, "/ws/%s", config->token);
        return true;
    }

    int sock = connect_tcp(client, base->host, base->port);
    if (sock < 0) {
        return false;
    }

    char request[512];
    snprintf(
        request,
        sizeof(request),
        "POST /sessions HTTP/1.1\r\n"
        "Host: %s:%d\r\n"
        "User-Agent: H3Proxy-3DS\r\n"
        "Connection: close\r\n"
        "Content-Length: 0\r\n\r\n",
        base->host,
        base->port
    );
    if (!send_all(client, sock, (const uint8_t *)request, strlen(request))) {
        close(sock);
        return false;
    }

    char response[8192];
    int got = recv_until(client, sock, response, sizeof(response), NULL, true);
    close(sock);
    if (got <= 0) {
        set_last_error(client, "session create empty response");
        return false;
    }
    if (!strstr(response, " 200 ")) {
        set_last_error(client, "session create bad status");
        h3p_log_printf("NET", "session response=%s", response);
        return false;
    }

    const char *body = strstr(response, "\r\n\r\n");
    body = body ? body + 4 : response;
    if (!extract_json_string(body, "websocket_path", path_out, path_out_len)) {
        set_last_error(client, "session create missing websocket_path");
        h3p_log_printf("NET", "session body=%s", body);
        return false;
    }
    h3p_log_printf("NET", "session websocket_path=%s", path_out);
    return true;
}

static bool websocket_handshake(H3PNetClient *client, const H3PParsedUrl *url) {
    int sock = connect_tcp(client, url->host, url->port);
    if (sock < 0) {
        return false;
    }

    char request[1024];
    snprintf(
        request,
        sizeof(request),
        "GET %s HTTP/1.1\r\n"
        "Host: %s:%d\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
        "Sec-WebSocket-Version: 13\r\n"
        "User-Agent: H3Proxy-3DS\r\n\r\n",
        url->path,
        url->host,
        url->port
    );

    if (!send_all(client, sock, (const uint8_t *)request, strlen(request))) {
        close(sock);
        return false;
    }

    char response[4096];
    int got = recv_until(client, sock, response, sizeof(response), "\r\n\r\n", false);
    if (got <= 0) {
        close(sock);
        set_last_error(client, "websocket handshake empty response");
        return false;
    }
    if (!strstr(response, " 101 ")) {
        close(sock);
        set_last_error(client, "websocket handshake bad status");
        h3p_log_printf("NET", "handshake response=%s", response);
        return false;
    }

    socket_set_nonblocking(sock, true);
    client->sock = sock;
    client->connected = true;
    snprintf(client->websocket_url, sizeof(client->websocket_url), "ws://%s:%d%s", url->host, url->port, url->path);
    h3p_log_printf("NET", "websocket connected url=%s", client->websocket_url);
    return true;
}

static bool send_ws_frame(H3PNetClient *client, uint8_t opcode, const uint8_t *payload, size_t len) {
    if (!client || !client->connected || client->sock < 0) {
        return false;
    }
    uint8_t header[14];
    size_t header_len = 0;
    header[header_len++] = 0x80 | (opcode & 0x0F);
    if (len <= 125) {
        header[header_len++] = 0x80 | (uint8_t)len;
    } else if (len <= 0xFFFF) {
        header[header_len++] = 0x80 | 126;
        header[header_len++] = (uint8_t)((len >> 8) & 0xFF);
        header[header_len++] = (uint8_t)(len & 0xFF);
    } else {
        header[header_len++] = 0x80 | 127;
        for (int i = 7; i >= 0; i--) {
            header[header_len++] = (uint8_t)(((uint64_t)len >> (i * 8)) & 0xFF);
        }
    }

    uint32_t seed = (uint32_t)osGetTime();
    uint8_t mask[4] = {
        (uint8_t)(seed & 0xFF),
        (uint8_t)((seed >> 8) & 0xFF),
        (uint8_t)((seed >> 16) & 0xFF),
        (uint8_t)((seed >> 24) & 0xFF),
    };
    memcpy(header + header_len, mask, sizeof(mask));
    header_len += sizeof(mask);

    if (!send_all(client, client->sock, header, header_len)) {
        return false;
    }

    uint8_t temp[1024];
    size_t sent = 0;
    while (sent < len) {
        size_t chunk = len - sent;
        if (chunk > sizeof(temp)) {
            chunk = sizeof(temp);
        }
        for (size_t i = 0; i < chunk; i++) {
            temp[i] = payload[sent + i] ^ mask[(sent + i) & 3];
        }
        if (!send_all(client, client->sock, temp, chunk)) {
            return false;
        }
        sent += chunk;
    }
    return true;
}

bool h3p_net_init(H3PNetClient *client) {
    if (!client) {
        return false;
    }
    memset(client, 0, sizeof(*client));
    client->sock = -1;
    client->rx_cap = H3P_NET_RX_BYTES;
    client->message_cap = H3P_NET_MESSAGE_BYTES;
    client->rx = (uint8_t *)malloc(client->rx_cap);
    client->message = (uint8_t *)malloc(client->message_cap + 1);
    if (!client->rx || !client->message) {
        set_last_error(client, "net buffers alloc failed");
        return false;
    }

    if (!s_soc_buffer) {
        s_soc_buffer = (u32 *)memalign(SOC_ALIGN, SOC_BUFFERSIZE);
    }
    if (!s_soc_buffer) {
        set_last_error(client, "soc buffer alloc failed");
        return false;
    }
    Result ret = socInit(s_soc_buffer, SOC_BUFFERSIZE);
    if (R_FAILED(ret)) {
        set_last_error(client, "socInit failed result=0x%08lx", (unsigned long)ret);
        return false;
    }
    client->soc_ready = true;
    h3p_log_printf("NET", "socInit ok");
    return true;
}

void h3p_net_close(H3PNetClient *client) {
    if (!client) {
        return;
    }
    if (client->connected && client->sock >= 0) {
        send_ws_frame(client, 0x8, NULL, 0);
    }
    if (client->sock >= 0) {
        close(client->sock);
    }
    client->sock = -1;
    client->connected = false;
    client->rx_len = 0;
}

void h3p_net_shutdown(H3PNetClient *client) {
    if (!client) {
        return;
    }
    h3p_net_close(client);
    free(client->rx);
    free(client->message);
    client->rx = NULL;
    client->message = NULL;
    client->rx_cap = 0;
    client->message_cap = 0;
    if (client->soc_ready) {
        h3p_log_printf("NET", "socExit start");
        socExit();
        client->soc_ready = false;
    }
    free(s_soc_buffer);
    s_soc_buffer = NULL;
}

bool h3p_net_connect(H3PNetClient *client, const H3PClientConfig *config, const char *caps_json, const char *start_url) {
    if (!client || !config) {
        return false;
    }

    H3PParsedUrl base;
    if (!parse_url(config->server_url, &base)) {
        set_last_error(client, "bad server url=%s", config->server_url);
        return false;
    }
    if (is_secure_scheme(base.scheme)) {
        set_last_error(client, "secure scheme unsupported on first 3DS path scheme=%s", base.scheme);
        return false;
    }

    H3PParsedUrl ws_url = base;
    if (strcmp(base.scheme, "ws") != 0) {
        snprintf(ws_url.scheme, sizeof(ws_url.scheme), "ws");
        if (!create_session_path(client, config, &base, ws_url.path, sizeof(ws_url.path))) {
            return false;
        }
    }

    if (!websocket_handshake(client, &ws_url)) {
        return false;
    }

    if (caps_json && caps_json[0]) {
        h3p_net_send_text(client, caps_json);
    }
    h3p_net_send_textf(
        client,
        "{\"type\":\"hello\",\"viewport\":{\"width\":400,\"height\":240},\"quality\":\"%s\"}",
        config->quality[0] ? config->quality : "normal"
    );
    if (start_url && start_url[0]) {
        h3p_net_send_textf(client, "{\"type\":\"open_url\",\"url\":\"%s\"}", start_url);
    }
    return true;
}

int h3p_net_poll(H3PNetClient *client, H3PNetMessage *message) {
    if (!client || !message) {
        return -1;
    }
    memset(message, 0, sizeof(*message));
    message->kind = H3P_NET_MESSAGE_NONE;
    if (!client->connected || client->sock < 0) {
        message->kind = H3P_NET_MESSAGE_CLOSED;
        return 0;
    }

    while (client->rx_len < client->rx_cap) {
        ssize_t got = recv(client->sock, client->rx + client->rx_len, client->rx_cap - client->rx_len, 0);
        if (got > 0) {
            client->rx_len += (size_t)got;
            continue;
        }
        if (got == 0) {
            h3p_log_printf("NET", "websocket closed by peer");
            h3p_net_close(client);
            message->kind = H3P_NET_MESSAGE_CLOSED;
            return 0;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            break;
        }
        set_last_error(client, "recv poll failed errno=%d", errno);
        h3p_net_close(client);
        message->kind = H3P_NET_MESSAGE_ERROR;
        return -1;
    }

    if (client->rx_len < 2) {
        return 0;
    }

    uint8_t b0 = client->rx[0];
    uint8_t b1 = client->rx[1];
    uint8_t opcode = b0 & 0x0F;
    bool masked = (b1 & 0x80) != 0;
    uint64_t payload_len = b1 & 0x7F;
    size_t header_len = 2;
    if (payload_len == 126) {
        if (client->rx_len < 4) return 0;
        payload_len = ((uint64_t)client->rx[2] << 8) | client->rx[3];
        header_len = 4;
    } else if (payload_len == 127) {
        if (client->rx_len < 10) return 0;
        payload_len = 0;
        for (int i = 0; i < 8; i++) {
            payload_len = (payload_len << 8) | client->rx[2 + i];
        }
        header_len = 10;
    }

    uint8_t mask[4] = {0, 0, 0, 0};
    if (masked) {
        if (client->rx_len < header_len + 4) return 0;
        memcpy(mask, client->rx + header_len, 4);
        header_len += 4;
    }
    if (payload_len > client->message_cap) {
        set_last_error(client, "websocket payload too large len=%lu", (unsigned long)payload_len);
        h3p_net_close(client);
        message->kind = H3P_NET_MESSAGE_ERROR;
        return -1;
    }
    if (client->rx_len < header_len + (size_t)payload_len) {
        return 0;
    }

    for (size_t i = 0; i < (size_t)payload_len; i++) {
        uint8_t byte = client->rx[header_len + i];
        client->message[i] = masked ? (byte ^ mask[i & 3]) : byte;
    }
    client->message[payload_len] = '\0';
    client->message_len = (size_t)payload_len;

    size_t consumed = header_len + (size_t)payload_len;
    memmove(client->rx, client->rx + consumed, client->rx_len - consumed);
    client->rx_len -= consumed;

    if (opcode == 0x8) {
        h3p_log_printf("NET", "websocket close frame");
        h3p_net_close(client);
        message->kind = H3P_NET_MESSAGE_CLOSED;
        return 0;
    }
    if (opcode == 0x9) {
        send_ws_frame(client, 0xA, client->message, client->message_len);
        return h3p_net_poll(client, message);
    }
    if (opcode == 0x1) {
        message->kind = H3P_NET_MESSAGE_TEXT;
        message->data = client->message;
        message->len = client->message_len;
        message->text = (const char *)client->message;
        return 1;
    }
    if (opcode == 0x2) {
        message->kind = H3P_NET_MESSAGE_BINARY;
        message->data = client->message;
        message->len = client->message_len;
        message->text = NULL;
        return 1;
    }

    h3p_log_printf("NET", "ignored websocket opcode=%u len=%lu", (unsigned int)opcode, (unsigned long)payload_len);
    return 0;
}

bool h3p_net_send_text(H3PNetClient *client, const char *text) {
    if (!text) {
        return false;
    }
    bool ok = send_ws_frame(client, 0x1, (const uint8_t *)text, strlen(text));
    h3p_log_printf("NET", "send text ok=%s len=%lu text=%s", ok ? "true" : "false", (unsigned long)strlen(text), text);
    return ok;
}

bool h3p_net_send_textf(H3PNetClient *client, const char *fmt, ...) {
    char text[H3P_NET_TEXT_BYTES];
    va_list args;
    va_start(args, fmt);
    vsnprintf(text, sizeof(text), fmt ? fmt : "", args);
    va_end(args);
    return h3p_net_send_text(client, text);
}

bool h3p_net_is_connected(const H3PNetClient *client) {
    return client && client->connected;
}

const char *h3p_net_last_error(const H3PNetClient *client) {
    return client ? client->last_error : "";
}
