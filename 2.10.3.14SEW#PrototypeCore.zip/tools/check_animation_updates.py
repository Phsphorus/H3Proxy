from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def create_session() -> dict:
    request = urllib.request.Request(BASE_URL + "/sessions", method="POST")
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


async def main() -> int:
    session = create_session()
    frames: list[dict] = []
    binary_tiles = 0

    async with websockets.connect(ws_base_url() + session["websocket_path"], max_size=None) as websocket:
        await websocket.recv()
        await websocket.send(json.dumps({
            "type": "open_url",
            "url": BASE_URL + "/debug/animation",
        }))

        deadline = asyncio.get_running_loop().time() + 6.0
        while asyncio.get_running_loop().time() < deadline and len(frames) < 6:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                binary_tiles += 1
                continue

            payload = json.loads(message)
            if payload.get("type") == "frame_done":
                frames.append(payload)

    auto_changed = [
        frame for frame in frames
        if not frame.get("immediate") and int(frame.get("changed_tiles", 0)) > 0
    ]
    if not auto_changed:
        print("[ERROR] no automatic changed frames observed", file=sys.stderr)
        print("frames:", frames, file=sys.stderr)
        return 1

    print("[OK] frames:", frames)
    print("[OK] binary tiles:", binary_tiles)
    print("[OK] automatic changed frames:", len(auto_changed))
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
