from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def read_json(url: str, *, method: str = "GET") -> dict:
    request = urllib.request.Request(url, method=method)
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


async def smoke_websocket(path: str) -> tuple[list[str], int, dict]:
    async with websockets.connect(ws_base_url() + path, max_size=None) as websocket:
        hello = json.loads(await websocket.recv())
        if hello.get("type") != "hello":
            raise RuntimeError(f"unexpected websocket greeting: {hello}")

        await websocket.send(json.dumps({
            "type": "hello",
            "viewport": {"width": 400, "height": 240},
            "quality": "normal",
        }))

        text_types: list[str] = []
        binary_tiles = 0
        frame_done: dict | None = None

        for _ in range(96):
            message = await asyncio.wait_for(websocket.recv(), timeout=30)
            if isinstance(message, bytes):
                binary_tiles += 1
                continue

            payload = json.loads(message)
            text_types.append(str(payload.get("type")))
            if payload.get("type") == "frame_done":
                frame_done = payload
                break

        if frame_done is None:
            raise RuntimeError("websocket did not produce frame_done")
        if binary_tiles != 16:
            raise RuntimeError(f"expected 16 changed tiles, got {binary_tiles}")

        return text_types, binary_tiles, frame_done


async def main() -> int:
    try:
        health = read_json(BASE_URL + "/health")
        session = read_json(BASE_URL + "/sessions", method="POST")
        text_types, binary_tiles, frame_done = await smoke_websocket(session["websocket_path"])
    except urllib.error.URLError as exc:
        print(f"[ERROR] server is not reachable at {BASE_URL}: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"[ERROR] smoke test failed: {exc}", file=sys.stderr)
        return 1

    print("[OK] health:", health["status"])
    print("[OK] session:", session["websocket_path"])
    print("[OK] websocket text:", ",".join(text_types))
    print("[OK] binary tiles:", binary_tiles)
    print("[OK] frame:", frame_done)
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
