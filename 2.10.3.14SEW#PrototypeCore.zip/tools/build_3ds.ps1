$ErrorActionPreference = "Stop"

$projectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$devkitProWin = Join-Path $projectRoot "Deps\devkitPro"
$makeExe = Join-Path $devkitProWin "msys2\usr\bin\make.exe"

if (-not (Test-Path $makeExe)) {
    throw "devkitPro make.exe not found at $makeExe"
}

$drive = ([System.IO.Path]::GetPathRoot($projectRoot.Path)).TrimEnd("\").TrimEnd(":").ToLowerInvariant()
$rest = $projectRoot.Path.Substring(3).Replace("\", "/")
$projectRootMsys = "/$drive/$rest"

$env:DEVKITPRO = "$projectRootMsys/Deps/devkitPro"
$env:DEVKITARM = "$env:DEVKITPRO/devkitARM"
$env:PATH = "$devkitProWin\tools\bin;$devkitProWin\devkitARM\bin;$devkitProWin\msys2\usr\bin;$env:PATH"

Push-Location (Join-Path $projectRoot "client_3ds")
try {
    & $makeExe @args
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }
}
finally {
    Pop-Location
}
