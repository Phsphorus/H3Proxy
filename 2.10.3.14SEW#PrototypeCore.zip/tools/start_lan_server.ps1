$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$env:H3PROXY_HOST = "0.0.0.0"
$env:H3PROXY_PORT = "8766"
$env:H3PROXY_HEADLESS = "true"
Set-Location $root
& ".\venv\Scripts\python.exe" -m h3proxy
