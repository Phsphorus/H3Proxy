@echo off
setlocal
powershell -ExecutionPolicy Bypass -File "%~dp0build_3ds.ps1" %*
exit /b %ERRORLEVEL%
