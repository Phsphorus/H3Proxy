from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def create_session() -> dict:
    request = urllib.request.Request(BASE_URL + "/sessions", method="POST")
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


async def recv_until_frame(websocket) -> tuple[list[str], list[dict], dict]:
    statuses: list[str] = []
    dom_items: list[dict] = []
    while True:
        message = await asyncio.wait_for(websocket.recv(), timeout=20)
        if isinstance(message, bytes):
            continue

        payload = json.loads(message)
        if payload.get("type") == "status":
            statuses.append(str(payload.get("state")))
        elif payload.get("type") == "dom_map":
            dom_items = payload.get("items", [])
        elif payload.get("type") == "frame_done":
            return statuses, dom_items, payload


def find_input(dom_items: list[dict]) -> dict:
    for item in dom_items:
        if item.get("kind") == "input" and item.get("placeholder") == "type here":
            return item
    raise RuntimeError("input debug target was not found in dom_map")


async def main() -> int:
    session = create_session()
    async with websockets.connect(ws_base_url() + session["websocket_path"], max_size=None) as websocket:
        await websocket.recv()
        await websocket.send(json.dumps({"type": "open_url", "url": BASE_URL + "/debug/input"}))
        _statuses, dom_items, _frame = await recv_until_frame(websocket)
        target = find_input(dom_items)

        await websocket.send(json.dumps({"type": "focus_dom_id", "id": target["id"]}))
        await recv_until_frame(websocket)

        await websocket.send(json.dumps({"type": "text", "text": "abc"}))
        _statuses, dom_items, _frame = await recv_until_frame(websocket)
        after_text = find_input(dom_items).get("value_preview")

        await websocket.send(json.dumps({"type": "key", "key": "Backspace"}))
        _statuses, dom_items, _frame = await recv_until_frame(websocket)
        after_backspace = find_input(dom_items).get("value_preview")

    if after_text != "abc" or after_backspace != "ab":
        print(f"[ERROR] unexpected values: after_text={after_text!r} after_backspace={after_backspace!r}", file=sys.stderr)
        return 1

    print("[OK] focus_dom_id/text/key:", {"after_text": after_text, "after_backspace": after_backspace})
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
