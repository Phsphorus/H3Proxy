from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def create_session() -> dict:
    request = urllib.request.Request(BASE_URL + "/sessions", method="POST")
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


async def main() -> int:
    session = create_session()
    policy = None
    throttled = None
    media_offer = None
    media_start = None

    caps = {
        "profile": "New 3DS LL / XL calibrated test",
        "calibrated": True,
        "max_page_fps": 22,
        "max_media_fps": 48,
        "safe_ram_bytes": 104857600,
        "safe_texture_cache_tiles": 180,
        "decode_jpeg_400x225_ms_p95": 9,
        "decode_png_tile_ms_p95": 3,
        "sd_write_mb_s": 8,
        "network_recv_kb_s": 620,
    }

    async with websockets.connect(ws_base_url() + session["websocket_path"], max_size=None) as websocket:
        await websocket.recv()
        await websocket.send(json.dumps({"type": "client_caps", **caps}))

        deadline = asyncio.get_running_loop().time() + 4.0
        while asyncio.get_running_loop().time() < deadline and policy is None:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                continue
            payload = json.loads(message)
            if payload.get("type") == "client_policy":
                policy = payload

        await websocket.send(json.dumps({
            "type": "client_stats",
            "decode_ms_p95": 95,
            "media_decode_ms_p95": 95,
            "queue_bytes": 5 * 1024 * 1024,
            "dropped_frames": 3,
        }))

        deadline = asyncio.get_running_loop().time() + 4.0
        while asyncio.get_running_loop().time() < deadline and throttled is None:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                continue
            payload = json.loads(message)
            if payload.get("type") == "server_policy":
                throttled = payload

        await websocket.send(json.dumps({"type": "open_url", "url": BASE_URL + "/debug/media"}))
        deadline = asyncio.get_running_loop().time() + 6.0
        while asyncio.get_running_loop().time() < deadline and media_offer is None:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                continue
            payload = json.loads(message)
            if payload.get("type") == "media_offer":
                media_offer = payload

        if media_offer and media_offer.get("regions"):
            region = media_offer["regions"][0]
            await websocket.send(json.dumps({
                "type": "client_stats",
                "decode_ms_p95": 8,
                "media_decode_ms_p95": 8,
                "queue_bytes": 0,
                "dropped_frames": 0,
            }))
            await websocket.recv()
            await websocket.recv()
            await websocket.send(json.dumps({
                "type": "start_media",
                "media_id": region["media_id"],
                "dom_id": region["dom_id"],
                "fps": 60,
            }))
            deadline = asyncio.get_running_loop().time() + 4.0
            while asyncio.get_running_loop().time() < deadline and media_start is None:
                message = await asyncio.wait_for(websocket.recv(), timeout=10)
                if isinstance(message, bytes):
                    continue
                payload = json.loads(message)
                if payload.get("type") == "media_start":
                    media_start = payload

    if policy is None:
        print("[ERROR] no client_policy event", file=sys.stderr)
        return 1
    if int(policy.get("max_media_fps", 0)) != 48:
        print("[ERROR] client_policy did not preserve max_media_fps", policy, file=sys.stderr)
        return 1
    if throttled is None or float(throttled.get("effective_media_fps", 60)) > 8:
        print("[ERROR] server_policy did not throttle under pressure", throttled, file=sys.stderr)
        return 1
    if media_offer is None or float(media_offer.get("target_fps", 0)) <= 0:
        print("[ERROR] no media_offer with target_fps", media_offer, file=sys.stderr)
        return 1
    if media_start is None or float(media_start.get("target_fps", 0)) > 48:
        print("[ERROR] media_start exceeded client cap", media_start, file=sys.stderr)
        return 1

    print("[OK] policy:", policy)
    print("[OK] throttled:", throttled)
    print("[OK] media_offer target:", media_offer.get("target_fps"))
    print("[OK] media_start:", media_start)
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
