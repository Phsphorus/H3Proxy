@echo off
setlocal
set "ROOT=%~dp0.."
set "H3PROXY_HOST=0.0.0.0"
set "H3PROXY_PORT=8766"
set "H3PROXY_HEADLESS=true"
cd /d "%ROOT%"
".\venv\Scripts\python.exe" -m h3proxy
