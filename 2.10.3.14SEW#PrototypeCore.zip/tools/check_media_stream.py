from __future__ import annotations

import asyncio
import json
import os
import struct
import sys
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")
HEADER_PREFIX = struct.Struct(">I")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def create_session() -> dict:
    request = urllib.request.Request(BASE_URL + "/sessions", method="POST")
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


def unpack_binary(message: bytes) -> tuple[dict, bytes]:
    header_len = HEADER_PREFIX.unpack(message[:4])[0]
    header = json.loads(message[4 : 4 + header_len].decode("utf-8"))
    payload = message[4 + header_len :]
    return header, payload


async def main() -> int:
    session = create_session()
    media_offer: dict | None = None
    media_start: dict | None = None
    media_frames: list[dict] = []
    tile_frames = 0

    async with websockets.connect(ws_base_url() + session["websocket_path"], max_size=None) as websocket:
        await websocket.recv()
        await websocket.send(json.dumps({"type": "open_url", "url": BASE_URL + "/debug/media"}))

        deadline = asyncio.get_running_loop().time() + 6.0
        while asyncio.get_running_loop().time() < deadline and media_offer is None:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                continue
            payload = json.loads(message)
            if payload.get("type") == "media_offer":
                media_offer = payload

        if not media_offer or not media_offer.get("regions"):
            print("[ERROR] no media_offer for debug media page", file=sys.stderr)
            return 1

        region = media_offer["regions"][0]
        await websocket.send(
            json.dumps(
                {
                    "type": "start_media",
                    "media_id": region["media_id"],
                    "dom_id": region["dom_id"],
                    "fps": 15,
                    "jpeg_quality": 58,
                }
            )
        )

        deadline = asyncio.get_running_loop().time() + 6.0
        while asyncio.get_running_loop().time() < deadline and len(media_frames) < 4:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                header, payload = unpack_binary(message)
                if header.get("type") == "media_frame":
                    header["actual_payload_len"] = len(payload)
                    media_frames.append(header)
                elif header.get("type") == "tile":
                    tile_frames += 1
                continue

            payload = json.loads(message)
            if payload.get("type") == "media_start":
                media_start = payload

        await websocket.send(json.dumps({"type": "stop_media"}))

    if media_start is None:
        print("[ERROR] no media_start event observed", file=sys.stderr)
        return 1
    if len(media_frames) < 2:
        print("[ERROR] too few media_frame packets observed", file=sys.stderr)
        print("media_frames:", media_frames, file=sys.stderr)
        print("tile_frames:", tile_frames, file=sys.stderr)
        return 1
    if any(frame.get("format") != "jpeg" for frame in media_frames):
        print("[ERROR] media frames were not JPEG", file=sys.stderr)
        print("media_frames:", media_frames, file=sys.stderr)
        return 1

    print("[OK] media_offer:", media_offer)
    print("[OK] media_start:", media_start)
    print("[OK] media_frames:", media_frames)
    print("[OK] tile packets seen while media active:", tile_frames)
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
