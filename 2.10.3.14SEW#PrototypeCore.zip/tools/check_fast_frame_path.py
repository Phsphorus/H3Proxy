from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.request
from urllib.parse import urlparse, urlunparse

import websockets


BASE_URL = os.getenv("H3PROXY_TEST_BASE_URL", "http://127.0.0.1:8765").rstrip("/")


def ws_base_url() -> str:
    parsed = urlparse(BASE_URL)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "", "", "", ""))


def create_session() -> dict:
    request = urllib.request.Request(BASE_URL + "/sessions", method="POST")
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


async def main() -> int:
    session = create_session()
    frames: list[dict] = []
    text_counts: dict[str, int] = {}
    binary_tiles = 0

    async with websockets.connect(ws_base_url() + session["websocket_path"], max_size=None) as websocket:
        await websocket.recv()
        await websocket.send(json.dumps({"type": "open_url", "url": BASE_URL + "/debug/animation"}))

        deadline = asyncio.get_running_loop().time() + 5.0
        while asyncio.get_running_loop().time() < deadline and len(frames) < 8:
            message = await asyncio.wait_for(websocket.recv(), timeout=10)
            if isinstance(message, bytes):
                binary_tiles += 1
                continue

            payload = json.loads(message)
            message_type = str(payload.get("type", ""))
            text_counts[message_type] = text_counts.get(message_type, 0) + 1
            if message_type == "frame_done":
                frames.append(payload)

    auto_tile_frames = [
        frame
        for frame in frames
        if frame.get("mode") == "auto_tile"
        and not frame.get("metadata_sent")
        and not frame.get("dom_sent")
    ]
    if not auto_tile_frames:
        print("[ERROR] no tile-only auto frames observed", file=sys.stderr)
        print("frames:", frames, file=sys.stderr)
        print("text_counts:", text_counts, file=sys.stderr)
        return 1

    if text_counts.get("dom_map", 0) >= len(frames):
        print("[ERROR] dom_map is still being sent on almost every frame", file=sys.stderr)
        print("frames:", frames, file=sys.stderr)
        print("text_counts:", text_counts, file=sys.stderr)
        return 1

    print("[OK] fast path frames:", frames)
    print("[OK] text counts:", text_counts)
    print("[OK] binary tiles:", binary_tiles)
    print("[OK] tile-only auto frames:", len(auto_tile_frames))
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
