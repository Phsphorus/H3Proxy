from __future__ import annotations

import asyncio
import io
import json
import queue
import threading
import tkinter as tk
import urllib.request
from dataclasses import dataclass, field
from tkinter import ttk
from urllib.parse import urlparse, urlunparse

import websockets
from PIL import Image, ImageTk

from h3proxy.hardware_profile import DEFAULT_HARDWARE_PROFILES, load_hardware_profiles


DEFAULT_BASE_URL = "http://127.0.0.1:8765"
BROWSER_W = 400
BROWSER_H = 240
BOTTOM_W = 320
PAGE_PAD_H = 180


@dataclass
class BinaryMessage:
    header: dict
    payload: bytes


@dataclass
class HardwareBudget:
    profile: dict
    tile_ids: set[str] = field(default_factory=set)
    dom_map_bytes: int = 0
    metadata_bytes: int = 0
    decode_staging_bytes: int = 0
    compressed_tile_queue_bytes: int = 0
    mjpeg_queue_bytes: int = 0
    input_queue_bytes: int = 0
    active_media_texture_bytes: int = 0

    def observe_binary(self, message: BinaryMessage) -> None:
        header = message.header
        payload_len = len(message.payload)
        self.decode_staging_bytes = max(self.decode_staging_bytes, self._decoded_bytes(header), payload_len)
        if header.get("type") == "tile":
            self.tile_ids.add(str(header.get("tile_id", f"{header.get('x')}:{header.get('y')}")))
        elif header.get("type") == "media_frame":
            self.active_media_texture_bytes = int(header.get("w", 0)) * int(header.get("h", 0)) * 2

    def observe_json(self, payload: dict) -> None:
        encoded_len = len(json.dumps(payload, separators=(",", ":")))
        if payload.get("type") == "dom_map":
            self.dom_map_bytes = encoded_len
        else:
            self.metadata_bytes = max(self.metadata_bytes, encoded_len)
        if payload.get("type") == "media_stop":
            self.active_media_texture_bytes = 0

    def observe_input(self, payload: dict) -> None:
        encoded_len = len(json.dumps(payload, separators=(",", ":")))
        self.input_queue_bytes = min(self.ram["input_queue_cap_bytes"], self.input_queue_bytes + encoded_len)

    def settle_input_queue(self) -> None:
        self.input_queue_bytes = max(0, self.input_queue_bytes - 256)

    @property
    def ram(self) -> dict:
        return self.profile["ram"]

    @property
    def vram(self) -> dict:
        return self.profile["vram"]

    @property
    def sd(self) -> dict:
        return self.profile["sd"]

    def ram_used(self) -> int:
        return (
            self.dom_map_bytes
            + self.metadata_bytes
            + self.decode_staging_bytes
            + self.compressed_tile_queue_bytes
            + self.mjpeg_queue_bytes
            + self.input_queue_bytes
        )

    def vram_used(self) -> int:
        return (
            len(self.tile_ids) * int(self.vram["tile_rgb565_bytes"])
            + int(self.vram.get("bottom_ui_rgba8_bytes", 0))
            + int(self.vram.get("cursor_overlay_bytes", 0))
            + self.active_media_texture_bytes
        )

    def sd_used(self) -> int:
        return (
            int(self.sd.get("profile_config_bytes", 0))
            + int(self.sd.get("bookmark_store_bytes", 0))
            + int(self.sd.get("history_store_bytes", 0))
        )

    def warnings(self) -> list[str]:
        warnings: list[str] = []
        if len(self.tile_ids) > int(self.vram["soft_page_tile_limit"]):
            warnings.append(f"tile cache soft limit {len(self.tile_ids)}/{self.vram['soft_page_tile_limit']}")
        if len(self.tile_ids) > int(self.vram["hard_page_tile_limit"]):
            warnings.append(f"tile cache hard limit {len(self.tile_ids)}/{self.vram['hard_page_tile_limit']}")
        if self.decode_staging_bytes > int(self.ram["decode_staging_cap_bytes"]):
            warnings.append("decode staging cap exceeded")
        if self.compressed_tile_queue_bytes > int(self.ram["compressed_tile_queue_cap_bytes"]):
            warnings.append("compressed tile queue cap exceeded")
        if self.mjpeg_queue_bytes > int(self.ram["mjpeg_queue_cap_bytes"]):
            warnings.append("MJPEG queue cap exceeded")
        return warnings

    def _decoded_bytes(self, header: dict) -> int:
        return int(header.get("w", 0)) * int(header.get("h", 0)) * 4


class SimulatorClient:
    def __init__(self, base_url: str, inbox: queue.Queue, budget: HardwareBudget) -> None:
        self.base_url = base_url.rstrip("/")
        self.inbox = inbox
        self.budget = budget
        self.loop: asyncio.AbstractEventLoop | None = None
        self.outgoing: asyncio.Queue[dict] | None = None
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._thread_main, daemon=True)
        self.thread.start()

    def send(self, message: dict) -> None:
        if self.loop is None or self.outgoing is None:
            self.inbox.put(("log", "client is not connected yet"))
            return
        self.budget.observe_input(message)
        self.loop.call_soon_threadsafe(self.outgoing.put_nowait, message)

    def _thread_main(self) -> None:
        asyncio.run(self._run())

    async def _run(self) -> None:
        self.loop = asyncio.get_running_loop()
        self.outgoing = asyncio.Queue()
        try:
            session = await asyncio.to_thread(self._create_session)
            websocket_url = self._websocket_base() + session["websocket_path"]
            self.inbox.put(("log", f"session {session['websocket_path']}"))

            async with websockets.connect(websocket_url, max_size=None) as websocket:
                await websocket.send(json.dumps({
                    "type": "hello",
                    "viewport": {"width": BROWSER_W, "height": BROWSER_H},
                    "quality": "normal",
                    "client_caps": client_caps_from_profile(self.budget.profile),
                }))
                await asyncio.gather(self._recv_loop(websocket), self._send_loop(websocket))
        except Exception as exc:
            self.inbox.put(("log", f"client error: {exc}"))

    def _create_session(self) -> dict:
        request = urllib.request.Request(self.base_url + "/sessions", method="POST")
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))

    def _websocket_base(self) -> str:
        parsed = urlparse(self.base_url)
        scheme = "wss" if parsed.scheme == "https" else "ws"
        return urlunparse((scheme, parsed.netloc, "", "", "", ""))

    async def _recv_loop(self, websocket) -> None:
        while True:
            message = await websocket.recv()
            if isinstance(message, bytes):
                decoded = self._decode_binary_header(message)
                self.inbox.put(("binary", decoded))
            else:
                self.inbox.put(("json", json.loads(message)))

    async def _send_loop(self, websocket) -> None:
        assert self.outgoing is not None
        while True:
            message = await self.outgoing.get()
            await websocket.send(json.dumps(message))

    def _decode_binary_header(self, packet: bytes) -> BinaryMessage:
        header_len = int.from_bytes(packet[:4], "big")
        header = json.loads(packet[4:4 + header_len].decode("utf-8"))
        payload = packet[4 + header_len:]
        return BinaryMessage(header=header, payload=payload)


class SimulatorApp(tk.Tk):
    def __init__(self, base_url: str) -> None:
        super().__init__()
        self.title("H3Proxy New 3DS LL Simulator")
        self.geometry("1220x760")
        profiles = load_hardware_profiles().get("profiles") or DEFAULT_HARDWARE_PROFILES["profiles"]
        self.budget = HardwareBudget(profile=profiles[0])
        self.inbox: queue.Queue = queue.Queue()
        self.client = SimulatorClient(base_url, self.inbox, self.budget)
        self.framebuffer = Image.new("RGB", (BROWSER_W, BROWSER_H), "black")
        self.top_photo = ImageTk.PhotoImage(self.framebuffer)
        self.bottom_photo = ImageTk.PhotoImage(self.framebuffer.resize((BOTTOM_W, PAGE_PAD_H)))
        self.dom_items: list[dict] = []
        self.media_regions: list[dict] = []
        self.selected_dom_index = -1
        self.touching = False
        self.view_mode = "top"
        self.active_media_id = ""
        self.selection_rect: int | None = None
        self.bottom_image_item: int | None = None

        self._build_ui(base_url)
        self.client.start()
        self.after(30, self._poll_inbox)
        self.after(250, self._settle_budget)

    def _build_ui(self, base_url: str) -> None:
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True, padx=8, pady=8)
        body = ttk.PanedWindow(root, orient="horizontal")
        body.pack(fill="both", expand=True)

        device = ttk.Frame(body)
        body.add(device, weight=0)
        ttk.Label(device, text=f"Server: {base_url}").pack(anchor="w")
        ttk.Label(device, textvariable=tk.StringVar(value="Top display 400x240")).pack(anchor="w")
        self.top_canvas = tk.Canvas(device, width=BROWSER_W, height=BROWSER_H, background="black", highlightthickness=1, highlightbackground="#444")
        self.top_canvas.pack(pady=(4, 12))
        self.top_image_item = self.top_canvas.create_image(0, 0, anchor="nw", image=self.top_photo)

        bottom_row = ttk.Frame(device)
        bottom_row.pack()
        controls_left = ttk.Frame(bottom_row)
        controls_left.pack(side="left", padx=(0, 8))
        self._build_left_controls(controls_left)

        bottom_screen = ttk.Frame(bottom_row, width=BOTTOM_W, height=240)
        bottom_screen.pack(side="left")
        bottom_screen.pack_propagate(False)
        self.bottom_canvas = tk.Canvas(bottom_screen, width=BOTTOM_W, height=PAGE_PAD_H, background="#090d13", highlightthickness=1, highlightbackground="#333")
        self.bottom_canvas.pack()
        self.bottom_image_item = self.bottom_canvas.create_image(0, 0, anchor="nw", image=self.bottom_photo)
        self.bottom_canvas.bind("<ButtonPress-1>", self.on_touch_down)
        self.bottom_canvas.bind("<B1-Motion>", self.on_touch_move)
        self.bottom_canvas.bind("<ButtonRelease-1>", self.on_touch_up)
        self.bottom_canvas.bind("<MouseWheel>", self.on_mousewheel)
        self._build_dock(bottom_screen)

        controls_right = ttk.Frame(bottom_row)
        controls_right.pack(side="left", padx=(8, 0))
        self._build_right_controls(controls_right)

        right = ttk.Frame(body)
        body.add(right, weight=1)
        self.meta_var = tk.StringVar(value="Connecting")
        self.mode_var = tk.StringVar(value="X top display mode")
        self.selected_var = tk.StringVar(value="No DOM selection")
        self.hardware_var = tk.StringVar(value="")
        self.warning_var = tk.StringVar(value="")
        ttk.Label(right, textvariable=self.meta_var, wraplength=580).pack(anchor="w")
        ttk.Label(right, textvariable=self.mode_var).pack(anchor="w")
        ttk.Label(right, textvariable=self.selected_var, wraplength=580).pack(anchor="w")
        ttk.Label(right, textvariable=self.hardware_var, wraplength=580).pack(anchor="w", pady=(8, 0))
        ttk.Label(right, textvariable=self.warning_var, wraplength=580, foreground="#b8860b").pack(anchor="w")

        tools = ttk.Frame(right)
        tools.pack(fill="x", pady=(8, 6))
        self.keyboard_var = tk.StringVar()
        ttk.Entry(tools, textvariable=self.keyboard_var, width=28).pack(side="left", fill="x", expand=True)
        ttk.Button(tools, text="Text", command=self.send_text).pack(side="left", padx=(4, 8))
        self.auto_media_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(tools, text="auto MJPEG", variable=self.auto_media_var).pack(side="left")
        ttk.Button(tools, text="Clear", command=lambda: self.log.delete("1.0", "end")).pack(side="right")

        self.log = tk.Text(right, wrap="word", height=34)
        self.log.pack(fill="both", expand=True)

    def _build_left_controls(self, parent: ttk.Frame) -> None:
        ttk.Button(parent, text="U", command=lambda: self.client.send({"type": "scroll", "dx": 0, "dy": -120})).grid(row=0, column=1)
        ttk.Button(parent, text="L", command=lambda: self.client.send({"type": "scroll", "dx": -120, "dy": 0})).grid(row=1, column=0)
        ttk.Button(parent, text="C", command=lambda: self.client.send({"type": "capture_frame"})).grid(row=1, column=1)
        ttk.Button(parent, text="R", command=lambda: self.client.send({"type": "scroll", "dx": 120, "dy": 0})).grid(row=1, column=2)
        ttk.Button(parent, text="D", command=lambda: self.client.send({"type": "scroll", "dx": 0, "dy": 120})).grid(row=2, column=1)
        ttk.Button(parent, text="L back", command=lambda: self.client.send({"type": "back"})).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(parent, text="ZL reload", command=lambda: self.client.send({"type": "reload"})).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(4, 0))

    def _build_right_controls(self, parent: ttk.Frame) -> None:
        ttk.Button(parent, text="X top", command=lambda: self.set_view_mode("top")).grid(row=0, column=1)
        ttk.Button(parent, text="Y bot", command=lambda: self.set_view_mode("bottom")).grid(row=1, column=0)
        ttk.Button(parent, text="A enter", command=lambda: self.client.send({"type": "key", "key": "Enter"})).grid(row=1, column=1)
        ttk.Button(parent, text="B clear", command=self.deselect_dom).grid(row=1, column=2)
        ttk.Button(parent, text="Start", command=lambda: self.client.send({"type": "capture_frame"})).grid(row=2, column=1)
        ttk.Button(parent, text="R fwd", command=lambda: self.client.send({"type": "forward"})).grid(row=3, column=1, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(parent, text="ZR spare", command=lambda: self._append_log("ZR reserved")).grid(row=4, column=1, columnspan=2, sticky="ew", pady=(4, 0))

    def _build_dock(self, parent: ttk.Frame) -> None:
        dock = ttk.Frame(parent)
        dock.pack(fill="x")
        self.url_var = tk.StringVar(value="https://example.com")
        ttk.Entry(dock, textvariable=self.url_var, width=32).grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Button(dock, text="Go", command=self.open_url).grid(row=0, column=4, sticky="ew")
        ttk.Button(dock, text="Up", command=lambda: self.select_dom(self.selected_dom_index - 1)).grid(row=1, column=0, sticky="ew")
        self.dom_var = tk.StringVar()
        self.dom_combo = ttk.Combobox(dock, textvariable=self.dom_var, values=[], state="readonly", width=18)
        self.dom_combo.grid(row=1, column=1, sticky="ew")
        self.dom_combo.bind("<<ComboboxSelected>>", self.on_dom_combo_select)
        ttk.Button(dock, text="Dn", command=lambda: self.select_dom(self.selected_dom_index + 1)).grid(row=1, column=2, sticky="ew")
        ttk.Button(dock, text="Use", command=self.activate_selected_dom).grid(row=1, column=3, sticky="ew")
        self.quality_var = tk.StringVar(value="normal")
        quality = ttk.Combobox(dock, textvariable=self.quality_var, values=["normal", "sharp", "low", "video"], width=8, state="readonly")
        quality.grid(row=1, column=4, sticky="ew")
        quality.bind("<<ComboboxSelected>>", lambda _event: self.client.send({"type": "set_quality", "quality": self.quality_var.get()}))
        dock.columnconfigure(1, weight=1)

    def open_url(self) -> None:
        self.client.send({"type": "open_url", "url": self.url_var.get()})

    def set_view_mode(self, mode: str) -> None:
        self.view_mode = mode
        self.mode_var.set("Y bottom webview mode" if mode == "bottom" else "X top display mode")
        self.update_bottom_canvas()

    def on_touch_down(self, event) -> None:
        self.touching = True
        x, y = self.bottom_to_browser(event.x, event.y)
        self.client.send({"type": "touch_down", "x": x, "y": y})

    def on_touch_move(self, event) -> None:
        if not self.touching:
            return
        x, y = self.bottom_to_browser(event.x, event.y)
        self.client.send({"type": "touch_move", "x": x, "y": y})

    def on_touch_up(self, event) -> None:
        self.touching = False
        x, y = self.bottom_to_browser(event.x, event.y)
        self.client.send({"type": "touch_up", "x": x, "y": y})

    def on_mousewheel(self, event) -> None:
        self.client.send({"type": "scroll", "dx": 0, "dy": int(event.delta)})

    def bottom_to_browser(self, x: int, y: int) -> tuple[int, int]:
        return (
            max(0, min(BROWSER_W - 1, int(x * BROWSER_W / BOTTOM_W))),
            max(0, min(BROWSER_H - 1, int(y * BROWSER_H / PAGE_PAD_H))),
        )

    def send_text(self) -> None:
        text = self.keyboard_var.get()
        if text:
            self.client.send({"type": "text", "text": text})
            self.keyboard_var.set("")

    def activate_selected_dom(self) -> None:
        item = self.selected_dom()
        if item:
            self.client.send({"type": "activate_dom_id", "id": int(item["id"])})

    def selected_dom(self) -> dict | None:
        if self.selected_dom_index < 0 or self.selected_dom_index >= len(self.dom_items):
            return None
        return self.dom_items[self.selected_dom_index]

    def deselect_dom(self) -> None:
        self.selected_dom_index = -1
        self.selected_var.set("No DOM selection")
        self.dom_combo.set("")
        self.draw_selection()

    def select_dom(self, index: int) -> None:
        if not self.dom_items:
            self.deselect_dom()
            return
        self.selected_dom_index = index % len(self.dom_items)
        item = self.selected_dom()
        label = self.dom_label(item)
        self.dom_combo.set(label)
        self.selected_var.set(label)
        self.draw_selection()

    def on_dom_combo_select(self, _event) -> None:
        value = self.dom_combo.get()
        for index, item in enumerate(self.dom_items):
            if self.dom_label(item) == value:
                self.select_dom(index)
                return

    def _poll_inbox(self) -> None:
        while True:
            try:
                kind, payload = self.inbox.get_nowait()
            except queue.Empty:
                break
            if kind == "binary":
                self._apply_binary(payload)
            elif kind == "json":
                self._handle_json(payload)
            else:
                self._append_log(str(payload))
        self.update_hardware_status()
        self.after(30, self._poll_inbox)

    def _settle_budget(self) -> None:
        self.budget.settle_input_queue()
        self.update_hardware_status()
        self.after(250, self._settle_budget)

    def _apply_binary(self, message: BinaryMessage) -> None:
        self.budget.observe_binary(message)
        image = Image.open(io.BytesIO(message.payload)).convert("RGB")
        self.framebuffer.paste(image, (int(message.header["x"]), int(message.header["y"])))
        self.top_photo = ImageTk.PhotoImage(self.framebuffer)
        self.top_canvas.itemconfigure(self.top_image_item, image=self.top_photo)
        self.update_bottom_canvas()

    def update_bottom_canvas(self) -> None:
        if self.view_mode == "bottom":
            bottom = self.framebuffer.resize((BOTTOM_W, PAGE_PAD_H))
        else:
            bottom = Image.new("RGB", (BOTTOM_W, PAGE_PAD_H), "#090d13")
        self.bottom_photo = ImageTk.PhotoImage(bottom)
        assert self.bottom_image_item is not None
        self.bottom_canvas.itemconfigure(self.bottom_image_item, image=self.bottom_photo)

    def _handle_json(self, payload: dict) -> None:
        self.budget.observe_json(payload)
        if payload.get("type") == "page_meta":
            self.meta_var.set(f"{payload.get('title') or '(untitled)'} - {payload.get('url')}")
        elif payload.get("type") == "dom_map":
            self.update_dom_map(payload.get("items", []))
        elif payload.get("type") == "media_offer":
            self.media_regions = payload.get("regions", [])
            if self.auto_media_var.get() and self.media_regions and not self.active_media_id:
                region = self.media_regions[0]
                self.client.send({
                    "type": "start_media",
                    "media_id": region["media_id"],
                    "dom_id": region["dom_id"],
                    "fps": client_caps_from_profile(self.budget.profile)["max_media_fps"],
                })
        elif payload.get("type") == "media_start":
            self.active_media_id = str(payload.get("media_id", ""))
        elif payload.get("type") == "media_stop":
            self.active_media_id = ""
        if payload.get("type") not in {"status"}:
            self._append_log(json.dumps(payload, separators=(",", ":")))

    def update_dom_map(self, items: list[dict]) -> None:
        self.dom_items = items
        values = [self.dom_label(item) for item in self.dom_items]
        self.dom_combo["values"] = values
        if self.dom_items and self.selected_dom_index < 0:
            self.select_dom(0)
        elif not self.dom_items:
            self.deselect_dom()

    def dom_label(self, item: dict | None) -> str:
        if not item:
            return ""
        label = f"{item.get('id')} {item.get('kind')} {item.get('text') or item.get('placeholder') or item.get('href') or ''}"
        return label[:90]

    def draw_selection(self) -> None:
        if self.selection_rect is not None:
            self.top_canvas.delete(self.selection_rect)
            self.selection_rect = None
        item = self.selected_dom()
        if not item:
            return
        x = int(item.get("x", 0))
        y = int(item.get("y", 0))
        w = int(item.get("w", 0))
        h = int(item.get("h", 0))
        self.selection_rect = self.top_canvas.create_rectangle(x + 1, y + 1, x + w - 1, y + h - 1, outline="#44d9ff", width=2)

    def update_hardware_status(self) -> None:
        ram_used = self.budget.ram_used()
        ram_budget = int(self.budget.ram["safe_budget_bytes"])
        vram_used = self.budget.vram_used()
        vram_budget = int(self.budget.vram["budget_bytes"])
        sd_used = self.budget.sd_used()
        sd_budget = int(self.budget.sd.get("optional_tile_cache_bytes", max(sd_used, 1)))
        self.hardware_var.set(
            f"{self.budget.profile['profile']} | "
            f"RAM {fmt_bytes(ram_used)} / {fmt_bytes(ram_budget)} | "
            f"VRAM {fmt_bytes(vram_used)} / {fmt_bytes(vram_budget)} | "
            f"SD {fmt_bytes(sd_used)} / {fmt_bytes(sd_budget)} | "
            f"tiles {len(self.budget.tile_ids)}/{self.budget.vram['soft_page_tile_limit']} soft | "
            f"decode {fmt_bytes(self.budget.decode_staging_bytes)}"
        )
        self.warning_var.set(" | ".join(self.budget.warnings()))

    def _append_log(self, text: str) -> None:
        self.log.insert("end", text + "\n")
        self.log.see("end")


def fmt_bytes(value: int) -> str:
    if value >= 1024 * 1024:
        return f"{value / 1024 / 1024:.1f} MB"
    if value >= 1024:
        return f"{value / 1024:.0f} KB"
    return f"{value} B"


def client_caps_from_profile(profile: dict) -> dict:
    return {
        "profile": profile.get("profile", "New 3DS LL / XL"),
        "calibrated": False,
        "max_page_fps": 30,
        "max_media_fps": 60,
        "safe_ram_bytes": int(profile.get("ram", {}).get("safe_budget_bytes", 0)),
        "safe_texture_cache_tiles": int(profile.get("vram", {}).get("soft_page_tile_limit", 96)),
        "decode_jpeg_400x225_ms_p95": 0,
        "decode_png_tile_ms_p95": 0,
        "sd_write_mb_s": 0,
        "network_recv_kb_s": 0,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="PC-side H3Proxy New 3DS LL protocol and hardware simulator.")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    args = parser.parse_args()
    app = SimulatorApp(args.base_url)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
