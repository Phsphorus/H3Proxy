from __future__ import annotations

import os
from dataclasses import dataclass


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


@dataclass(frozen=True)
class ServerConfig:
    host: str = "127.0.0.1"
    port: int = 8765
    headless: bool = True
    viewport_width: int = 400
    viewport_height: int = 240
    tile_width: int = 100
    tile_height: int = 60
    jpeg_quality: int = 64
    browser_timeout_ms: int = 30_000
    max_sessions: int = 4
    session_ttl_seconds: int = 30 * 60
    auto_update_enabled: bool = True
    idle_fps: float = 2.0
    active_fps: float = 6.0
    animation_fps: float = 10.0
    media_fps: float = 15.0
    protocol_max_fps: float = 60.0
    recent_input_seconds: float = 2.0
    auto_meta_interval_seconds: float = 2.0
    auto_empty_frame_interval_seconds: float = 1.0
    unchanged_backoff_after: int = 12
    unchanged_deep_backoff_after: int = 40

    @classmethod
    def from_env(cls) -> "ServerConfig":
        return cls(
            host=os.getenv("H3PROXY_HOST", cls.host),
            port=_env_int("H3PROXY_PORT", cls.port),
            headless=_env_bool("H3PROXY_HEADLESS", cls.headless),
            viewport_width=_env_int("H3PROXY_VIEWPORT_WIDTH", cls.viewport_width),
            viewport_height=_env_int("H3PROXY_VIEWPORT_HEIGHT", cls.viewport_height),
            tile_width=_env_int("H3PROXY_TILE_WIDTH", cls.tile_width),
            tile_height=_env_int("H3PROXY_TILE_HEIGHT", cls.tile_height),
            jpeg_quality=_env_int("H3PROXY_JPEG_QUALITY", cls.jpeg_quality),
            browser_timeout_ms=_env_int("H3PROXY_BROWSER_TIMEOUT_MS", cls.browser_timeout_ms),
            max_sessions=_env_int("H3PROXY_MAX_SESSIONS", cls.max_sessions),
            session_ttl_seconds=_env_int("H3PROXY_SESSION_TTL_SECONDS", cls.session_ttl_seconds),
            auto_update_enabled=_env_bool("H3PROXY_AUTO_UPDATE", cls.auto_update_enabled),
            idle_fps=_env_float("H3PROXY_IDLE_FPS", cls.idle_fps),
            active_fps=_env_float("H3PROXY_ACTIVE_FPS", cls.active_fps),
            animation_fps=_env_float("H3PROXY_ANIMATION_FPS", cls.animation_fps),
            media_fps=_env_float("H3PROXY_MEDIA_FPS", cls.media_fps),
            protocol_max_fps=_env_float("H3PROXY_PROTOCOL_MAX_FPS", cls.protocol_max_fps),
            recent_input_seconds=_env_float("H3PROXY_RECENT_INPUT_SECONDS", cls.recent_input_seconds),
            auto_meta_interval_seconds=_env_float("H3PROXY_AUTO_META_INTERVAL_SECONDS", cls.auto_meta_interval_seconds),
            auto_empty_frame_interval_seconds=_env_float(
                "H3PROXY_AUTO_EMPTY_FRAME_INTERVAL_SECONDS",
                cls.auto_empty_frame_interval_seconds,
            ),
            unchanged_backoff_after=_env_int("H3PROXY_UNCHANGED_BACKOFF_AFTER", cls.unchanged_backoff_after),
            unchanged_deep_backoff_after=_env_int("H3PROXY_UNCHANGED_DEEP_BACKOFF_AFTER", cls.unchanged_deep_backoff_after),
        )

    @property
    def viewport(self) -> dict[str, int]:
        return {"width": self.viewport_width, "height": self.viewport_height}
