from __future__ import annotations

from .config import ServerConfig


def main() -> int:
    config = ServerConfig.from_env()
    try:
        import uvicorn
    except Exception as exc:
        raise SystemExit("uvicorn is not installed. Install requirements in the active venv first.") from exc

    uvicorn.run("h3proxy.app:app", host=config.host, port=config.port, reload=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
