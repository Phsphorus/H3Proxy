from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .browser_session import BrowserSession


@dataclass
class RouteResult:
    needs_frame: bool = False
    status: str = "ok"
    extra: dict[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)


class InputRouter:
    async def route(self, session: BrowserSession, message: dict[str, Any]) -> RouteResult:
        msg_type = str(message.get("type", ""))

        if msg_type == "hello":
            if "viewport" in message:
                viewport = message["viewport"]
                await session.set_viewport(int(viewport["width"]), int(viewport["height"]))
            if "quality" in message:
                session.set_quality(str(message["quality"]))
            if "client_caps" in message and isinstance(message["client_caps"], dict):
                policy = session.update_client_caps(message["client_caps"])
                return RouteResult(
                    needs_frame=True,
                    status="hello",
                    extra={"effective_page_fps": policy["effective_page_fps"], "effective_media_fps": policy["effective_media_fps"]},
                    events=[{"type": "client_policy", **policy}],
                )
            return RouteResult(needs_frame=True, status="hello")

        if msg_type == "client_caps":
            policy = session.update_client_caps(message)
            return RouteResult(
                needs_frame=False,
                status="client_caps",
                extra={"effective_page_fps": policy["effective_page_fps"], "effective_media_fps": policy["effective_media_fps"]},
                events=[{"type": "client_policy", **policy}],
            )

        if msg_type == "client_stats":
            stats = session.update_client_stats(message)
            return RouteResult(
                needs_frame=False,
                status="client_stats",
                extra={"effective_page_fps": stats["effective_page_fps"], "effective_media_fps": stats["effective_media_fps"]},
                events=[{"type": "server_policy", **stats}],
            )

        if msg_type == "open_url":
            await session.open_url(str(message.get("url", "")))
            return RouteResult(needs_frame=True, status="opened")

        if msg_type == "capture_frame":
            return RouteResult(needs_frame=True, status="capturing")

        if msg_type == "click":
            await session.click(int(message.get("x", 0)), int(message.get("y", 0)))
            return RouteResult(needs_frame=True, status="clicked")

        if msg_type == "touch_down":
            await session.touch_down(int(message.get("x", 0)), int(message.get("y", 0)))
            return RouteResult(needs_frame=not session.media_stream_active, status="touch_down")

        if msg_type == "touch_move":
            await session.touch_move(int(message.get("x", 0)), int(message.get("y", 0)))
            return RouteResult(needs_frame=False, status="touch_move")

        if msg_type == "touch_up":
            await session.touch_up(int(message.get("x", 0)), int(message.get("y", 0)))
            return RouteResult(needs_frame=not session.media_stream_active, status="touch_up")

        if msg_type == "scroll":
            await session.scroll(int(message.get("dx", 0)), int(message.get("dy", 0)))
            return RouteResult(needs_frame=not session.media_stream_active, status="scrolled")

        if msg_type == "key":
            await session.press_key(str(message.get("key", "")))
            return RouteResult(needs_frame=True, status="key")

        if msg_type == "key_down":
            await session.key_down(str(message.get("key", "")))
            return RouteResult(needs_frame=True, status="key_down")

        if msg_type == "key_up":
            await session.key_up(str(message.get("key", "")))
            return RouteResult(needs_frame=True, status="key_up")

        if msg_type == "text":
            await session.type_text(str(message.get("text", "")))
            return RouteResult(needs_frame=True, status="text")

        if msg_type == "back":
            await session.back()
            return RouteResult(needs_frame=True, status="back")

        if msg_type == "forward":
            await session.forward()
            return RouteResult(needs_frame=True, status="forward")

        if msg_type == "reload":
            await session.reload()
            return RouteResult(needs_frame=True, status="reload")

        if msg_type == "stop":
            await session.stop()
            return RouteResult(needs_frame=True, status="stop")

        if msg_type == "set_viewport":
            await session.set_viewport(int(message.get("width", 400)), int(message.get("height", 240)))
            return RouteResult(needs_frame=True, status="viewport")

        if msg_type == "set_quality":
            session.set_quality(str(message.get("quality", "normal")))
            return RouteResult(needs_frame=True, status="quality")

        if msg_type == "activate_dom_id":
            activated = await session.activate_dom_id(int(message.get("id", -1)))
            return RouteResult(needs_frame=activated, status="activated" if activated else "missing_dom_id")

        if msg_type == "focus_dom_id":
            focused = await session.focus_dom_id(int(message.get("id", -1)))
            return RouteResult(needs_frame=focused, status="focused" if focused else "missing_dom_id")

        if msg_type == "start_media":
            media = await session.start_media(
                media_id=str(message.get("media_id", "") or "") or None,
                dom_id=int(message["dom_id"]) if "dom_id" in message else None,
                fps=float(message["fps"]) if "fps" in message else None,
                jpeg_quality=int(message["jpeg_quality"]) if "jpeg_quality" in message else None,
            )
            if media is None:
                return RouteResult(needs_frame=True, status="missing_media")
            return RouteResult(
                needs_frame=False,
                status="media_started",
                extra={"media_id": media["media_id"], "dom_id": media["dom_id"]},
                events=[{"type": "media_start", **media}],
            )

        if msg_type == "stop_media":
            media = session.stop_media()
            event = {"type": "media_stop", **media} if media is not None else {"type": "media_stop"}
            return RouteResult(
                needs_frame=False,
                status="media_stopped",
                extra={"media_id": media["media_id"]} if media is not None else {},
                events=[event],
            )

        if msg_type == "media_control":
            control = str(message.get("control", "toggle"))
            if control in {"toggle", "play_pause"}:
                await session.press_key("Space")
                return RouteResult(needs_frame=False, status="media_control", extra={"control": control})
            return RouteResult(needs_frame=False, status="unknown_media_control", extra={"control": control})

        return RouteResult(needs_frame=False, status="unknown_message", extra={"message_type": msg_type})
