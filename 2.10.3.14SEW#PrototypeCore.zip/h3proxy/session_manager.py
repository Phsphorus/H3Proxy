from __future__ import annotations

import asyncio
import secrets

from .browser_session import BrowserSession
from .config import ServerConfig


class SessionManager:
    def __init__(self, config: ServerConfig) -> None:
        self.config = config
        self._sessions: dict[str, BrowserSession] = {}
        self._lock = asyncio.Lock()

    async def create(self) -> BrowserSession:
        async with self._lock:
            await self._cleanup_locked()
            if len(self._sessions) >= self.config.max_sessions:
                raise RuntimeError("maximum session count reached")
            token = secrets.token_urlsafe(24)
            session = BrowserSession(token, self.config)
            self._sessions[token] = session
            return session

    async def get(self, token: str) -> BrowserSession | None:
        async with self._lock:
            session = self._sessions.get(token)
            if session is None:
                return None
            if session.expired:
                await session.close()
                self._sessions.pop(token, None)
                return None
            session.touch()
            return session

    async def close(self, token: str) -> None:
        async with self._lock:
            session = self._sessions.pop(token, None)
        if session is not None:
            await session.close()

    async def close_all(self) -> None:
        async with self._lock:
            sessions = list(self._sessions.values())
            self._sessions.clear()
        for session in sessions:
            await session.close()

    async def cleanup(self) -> None:
        async with self._lock:
            await self._cleanup_locked()

    async def _cleanup_locked(self) -> None:
        expired = [token for token, session in self._sessions.items() if session.expired]
        for token in expired:
            session = self._sessions.pop(token)
            await session.close()

    def stats(self) -> dict[str, object]:
        return {
            "sessions": len(self._sessions),
            "max_sessions": self.config.max_sessions,
            "tokens": list(self._sessions.keys()),
        }

    async def snapshots(self) -> list[dict[str, object]]:
        async with self._lock:
            await self._cleanup_locked()
            return [session.snapshot() for session in self._sessions.values()]
