from __future__ import annotations

from typing import Any


MEDIA_KINDS = {"video", "canvas"}


class MediaBridge:
    """Media-region offer helper for MJPEG promotion."""

    def build_offer(self, frame_id: int, dom_items: list[dict[str, Any]]) -> dict[str, Any] | None:
        regions = [self.region_from_item(item) for item in dom_items if item.get("kind") in MEDIA_KINDS]
        if not regions:
            return None
        return {
            "type": "media_offer",
            "frame_id": frame_id,
            "mode": "mjpeg",
            "format": "jpeg",
            "target_fps": 15,
            "regions": regions,
        }

    def region_from_item(self, item: dict[str, Any]) -> dict[str, Any]:
        dom_id = int(item["id"])
        return {
            "media_id": self.media_id(dom_id),
            "dom_id": dom_id,
            "kind": item["kind"],
            "x": int(item["x"]),
            "y": int(item["y"]),
            "w": int(item["w"]),
            "h": int(item["h"]),
            "format": "jpeg",
        }

    def media_id(self, dom_id: int) -> str:
        return f"m{int(dom_id)}"
