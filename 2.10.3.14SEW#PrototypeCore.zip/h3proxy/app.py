from __future__ import annotations

import json
import asyncio
import time
from collections import deque
from contextlib import asynccontextmanager, suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from .config import ServerConfig
from .frame_scheduler import AdaptiveFrameScheduler, FrameSendResult
from .hardware_profile import load_hardware_profiles
from .input_router import InputRouter
from .media_bridge import MediaBridge
from .protocol import error_message, send_binary_packet, send_json, status_message
from .session_manager import SessionManager


config = ServerConfig.from_env()
session_manager = SessionManager(config)
input_router = InputRouter()
media_bridge = MediaBridge()


TRANSIENT_BROWSER_ERROR_MARKERS = (
    "Execution context was destroyed",
    "browsingContext.topChromeWindow is null",
    "can't access property",
    "Frame was detached",
    "Page.screenshot: Protocol error",
)


def _is_transient_browser_error(exc: Exception) -> bool:
    detail = str(exc)
    return any(marker in detail for marker in TRANSIENT_BROWSER_ERROR_MARKERS)


def _short_error_detail(exc: Exception, limit: int = 220) -> str:
    detail = " ".join(str(exc).split())
    if len(detail) <= limit:
        return detail
    return f"{detail[:limit - 3]}..."


class ServerEventLog:
    def __init__(self, limit: int = 500) -> None:
        self._events: deque[dict[str, Any]] = deque(maxlen=limit)

    def add(self, event: str, **data: Any) -> None:
        self._events.append(
            {
                "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "event": event,
                **data,
            }
        )

    def latest(self, limit: int = 200) -> list[dict[str, Any]]:
        if limit <= 0:
            return []
        return list(self._events)[-limit:]


server_events = ServerEventLog()

ACTIVE_MESSAGE_TYPES = {
    "hello",
    "open_url",
    "capture_frame",
    "click",
    "touch_down",
    "touch_move",
    "touch_up",
    "scroll",
    "key",
    "key_down",
    "key_up",
    "text",
    "back",
    "forward",
    "reload",
    "stop",
    "set_viewport",
    "set_quality",
    "activate_dom_id",
    "focus_dom_id",
    "start_media",
    "media_control",
    "stop_media",
    "request_frame",
    "request_resync",
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await session_manager.close_all()


app = FastAPI(title="H3Proxy Server", version="0.1.0", lifespan=lifespan)


@app.get("/", response_class=HTMLResponse)
async def server_dashboard() -> str:
    html_path = Path(__file__).with_name("static") / "server_dashboard.html"
    return html_path.read_text(encoding="utf-8")


@app.get("/debug/client", response_class=HTMLResponse)
async def debug_client() -> str:
    html_path = Path(__file__).with_name("static") / "debug_client.html"
    return html_path.read_text(encoding="utf-8")


@app.get("/start", response_class=HTMLResponse)
async def start_page() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>H3Proxy Start</title>
  <style>
    html, body { margin: 0; width: 400px; height: 240px; overflow: hidden; background: #eef1f4; color: #101419; font: 15px system-ui, sans-serif; }
    header { height: 38px; display: flex; align-items: center; padding: 0 14px; background: #17202a; color: white; font-weight: 700; }
    main { padding: 12px 14px; }
    form { display: grid; grid-template-columns: 1fr 54px; gap: 8px; margin-bottom: 12px; }
    input { height: 34px; border: 1px solid #8793a0; padding: 0 9px; border-radius: 4px; font-size: 15px; background: white; color: #111; }
    button, a { min-height: 32px; border: 1px solid #768392; border-radius: 4px; background: #ffffff; color: #111; text-decoration: none; display: flex; align-items: center; justify-content: center; font: 14px system-ui, sans-serif; }
    button { background: #2e6fbd; color: white; border-color: #2e6fbd; font-weight: 700; }
    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .hint { margin-top: 12px; color: #46515e; font-size: 12px; line-height: 1.35; }
  </style>
</head>
<body>
  <header>H3Proxy Browser</header>
  <main>
    <form id="goForm">
      <input id="target" autocomplete="off" placeholder="URL or search" autofocus>
      <button>Go</button>
    </form>
    <div class="grid">
      <a href="https://lite.duckduckgo.com/lite/">DuckDuckGo Lite</a>
      <a href="https://en.m.wikipedia.org/wiki/Main_Page">Wikipedia</a>
      <a href="/debug/input">Input Test</a>
      <a href="/debug/media">Media Test</a>
    </div>
    <div class="hint">Use the bottom dock for URL entry, DOM selection, quality, and page touch.</div>
  </main>
  <script>
    document.getElementById("goForm").addEventListener("submit", (event) => {
      event.preventDefault();
      const raw = document.getElementById("target").value.trim();
      if (!raw) return;
      if (raw.startsWith("/") || raw.startsWith("about:")) {
        location.href = raw;
      } else if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) {
        location.href = raw;
      } else if (raw.includes(".") && !raw.includes(" ")) {
        location.href = "https://" + raw;
      } else {
        location.href = "https://lite.duckduckgo.com/lite/?q=" + encodeURIComponent(raw);
      }
    });
  </script>
</body>
</html>
"""


@app.get("/debug/animation", response_class=HTMLResponse)
async def debug_animation() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>H3Proxy Animation Debug</title>
  <style>
    html, body { margin: 0; width: 400px; height: 240px; overflow: hidden; background: #111318; color: white; }
    .bar { position: absolute; left: 0; top: 102px; width: 78px; height: 36px; background: #35d07f; animation: slide 1.2s linear infinite alternate; }
    .label { position: absolute; left: 14px; top: 14px; font: 18px sans-serif; }
    @keyframes slide { from { transform: translateX(0); } to { transform: translateX(300px); } }
  </style>
</head>
<body>
  <div class="label">CSS motion test</div>
  <div class="bar"></div>
</body>
</html>
"""


@app.get("/debug/input", response_class=HTMLResponse)
async def debug_input() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>H3Proxy Input Debug</title>
  <style>
    body { margin: 0; width: 400px; height: 240px; font: 16px sans-serif; background: #f4f4f4; color: #111; }
    input { position: absolute; left: 30px; top: 52px; width: 280px; height: 32px; font: 18px sans-serif; }
    button { position: absolute; left: 30px; top: 104px; width: 160px; height: 36px; }
    #out { position: absolute; left: 30px; top: 160px; width: 330px; height: 50px; }
  </style>
</head>
<body>
  <label style="position:absolute; left:30px; top:24px;">Input target</label>
  <input id="target" placeholder="type here">
  <button onclick="document.getElementById('out').textContent = document.getElementById('target').value">Copy value</button>
  <div id="out">Waiting</div>
</body>
</html>
"""


@app.get("/debug/media", response_class=HTMLResponse)
async def debug_media() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>H3Proxy Media Debug</title>
  <style>
    html, body { margin: 0; width: 400px; height: 240px; overflow: hidden; background: #080a0f; color: white; }
    canvas { position: absolute; left: 0; top: 0; width: 400px; height: 225px; background: #111; }
    .strip { position: absolute; left: 0; bottom: 0; width: 400px; height: 15px; background: #202631; font: 11px sans-serif; color: #ccd6e8; }
  </style>
</head>
<body>
  <canvas id="videoLike" width="400" height="225"></canvas>
  <div class="strip">local MJPEG promotion target</div>
  <script>
    const canvas = document.getElementById("videoLike");
    const ctx = canvas.getContext("2d");
    let t = 0;
    function frame() {
      t += 0.045;
      const grad = ctx.createLinearGradient(0, 0, 400, 225);
      grad.addColorStop(0, `hsl(${(t * 120) % 360}, 70%, 22%)`);
      grad.addColorStop(1, `hsl(${(t * 120 + 100) % 360}, 70%, 12%)`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 400, 225);
      for (let i = 0; i < 8; i++) {
        const x = 200 + Math.cos(t * (1 + i * 0.08) + i) * (35 + i * 18);
        const y = 112 + Math.sin(t * (1.4 + i * 0.05) + i * 0.7) * (24 + i * 8);
        ctx.fillStyle = `hsla(${(i * 43 + t * 180) % 360}, 85%, 62%, 0.82)`;
        ctx.beginPath();
        ctx.arc(x, y, 10 + i * 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = "rgba(0,0,0,0.32)";
      ctx.fillRect(12, 14, 150, 30);
      ctx.fillStyle = "#f3f6ff";
      ctx.font = "18px sans-serif";
      ctx.fillText("MJPEG test", 24, 36);
      requestAnimationFrame(frame);
    }
    frame();
  </script>
</body>
</html>
"""


@app.get("/health")
async def health() -> dict[str, Any]:
    await session_manager.cleanup()
    return {
        "status": "ok",
        "server": "h3proxy",
        "viewport": config.viewport,
        "tile": {"width": config.tile_width, "height": config.tile_height},
        "auto_update": {
            "enabled": config.auto_update_enabled,
            "idle_fps": config.idle_fps,
            "active_fps": config.active_fps,
            "animation_fps": config.animation_fps,
            "media_fps": config.media_fps,
            "protocol_max_fps": config.protocol_max_fps,
            "meta_interval_seconds": config.auto_meta_interval_seconds,
            "empty_frame_interval_seconds": config.auto_empty_frame_interval_seconds,
        },
        "sessions": session_manager.stats(),
    }


@app.get("/server/state")
async def server_state() -> dict[str, Any]:
    await session_manager.cleanup()
    return {
        "status": "ok",
        "server": "h3proxy",
        "config": {
            "host": config.host,
            "port": config.port,
            "headless": config.headless,
            "viewport": config.viewport,
            "tile": {"width": config.tile_width, "height": config.tile_height},
            "jpeg_quality": config.jpeg_quality,
            "max_sessions": config.max_sessions,
            "session_ttl_seconds": config.session_ttl_seconds,
            "auto_update": {
                "enabled": config.auto_update_enabled,
                "idle_fps": config.idle_fps,
                "active_fps": config.active_fps,
                "animation_fps": config.animation_fps,
                "media_fps": config.media_fps,
                "protocol_max_fps": config.protocol_max_fps,
            },
        },
        "sessions": await session_manager.snapshots(),
        "events": server_events.latest(80),
    }


@app.get("/server/events")
async def server_event_stream(limit: int = 200) -> dict[str, Any]:
    return {"events": server_events.latest(max(1, min(500, int(limit))))}


@app.get("/hardware_profiles")
async def hardware_profiles() -> dict[str, Any]:
    return load_hardware_profiles()


@app.post("/sessions")
async def create_session() -> dict[str, Any]:
    try:
        session = await session_manager.create()
    except RuntimeError as exc:
        raise HTTPException(status_code=429, detail=str(exc)) from exc
    server_events.add("session_created", token=session.token)
    return {
        "token": session.token,
        "websocket_path": f"/ws/{session.token}",
        "viewport": session.viewport,
        "tile": {"width": config.tile_width, "height": config.tile_height},
        "auto_update": config.auto_update_enabled,
        "protocol_max_fps": config.protocol_max_fps,
    }


@app.delete("/sessions/{token}")
async def close_session(token: str) -> dict[str, Any]:
    await session_manager.close(token)
    server_events.add("session_closed_by_api", token=token)
    return {"status": "closed", "token": token}


@app.websocket("/ws/{token}")
async def websocket_session(websocket: WebSocket, token: str) -> None:
    await websocket.accept()
    send_lock = asyncio.Lock()
    frame_lock = asyncio.Lock()
    scheduler = AdaptiveFrameScheduler(config)
    session = await session_manager.get(token)
    if session is None:
        server_events.add("websocket_invalid_session", token=token)
        async with send_lock:
            await send_json(websocket, error_message("invalid_session", "Create a session with POST /sessions first.", fatal=True))
        await websocket.close(code=1008)
        return

    server_events.add("websocket_connected", token=token)

    async with send_lock:
        await send_json(
            websocket,
            {
                "type": "hello",
                "server": "h3proxy",
                "token": token,
                "viewport": session.viewport,
                "tile": {"width": config.tile_width, "height": config.tile_height},
                "auto_update": config.auto_update_enabled,
                "protocol_max_fps": config.protocol_max_fps,
            },
        )

    auto_task = None
    media_task = None
    try:
        while True:
            raw = await websocket.receive_text()
            message_type = ""
            try:
                message = json.loads(raw)
                message_type = str(message.get("type", ""))
            except json.JSONDecodeError as exc:
                async with send_lock:
                    await send_json(websocket, error_message("bad_json", str(exc)))
                continue

            try:
                if message_type in ACTIVE_MESSAGE_TYPES:
                    scheduler.mark_input()
                result = await input_router.route(session, message)
                if message_type not in {"touch_move", "client_stats"}:
                    server_events.add("client_message", token=token, message_type=message_type, status=result.status)
                scheduler.set_client_max_page_fps(session.effective_page_fps())
                async with send_lock:
                    await send_json(websocket, status_message(result.status, **result.extra))
                    for event in result.events:
                        await send_json(websocket, event)
                if result.needs_frame:
                    frame_result = await send_frame(
                        websocket,
                        session,
                        send_lock,
                        frame_lock,
                        immediate=True,
                        include_metadata=True,
                        send_empty_frame_done=True,
                    )
                    scheduler.record_frame(frame_result)
                    server_events.add(
                        "frame_sent",
                        token=token,
                        changed_tiles=frame_result.changed_tiles,
                        capture_ms=frame_result.capture_ms,
                        tiles_bytes=frame_result.tiles_bytes,
                    )
                if auto_task is None and config.auto_update_enabled:
                    auto_task = asyncio.create_task(auto_frame_loop(websocket, session, scheduler, send_lock, frame_lock))
                if session.media_stream_active:
                    if media_task is None or media_task.done():
                        media_task = asyncio.create_task(media_frame_loop(websocket, session, send_lock, frame_lock))
                elif media_task is not None:
                    media_task.cancel()
                    with suppress(asyncio.CancelledError, WebSocketDisconnect):
                        await media_task
                    media_task = None
            except Exception as exc:
                detail = _short_error_detail(exc)
                if _is_transient_browser_error(exc):
                    server_events.add("route_transient", token=token, message_type=message_type, detail=detail)
                    async with send_lock:
                        await send_json(websocket, status_message("browser_busy", reason="navigation"))
                    continue
                server_events.add("route_failed", token=token, message_type=message_type, detail=detail)
                async with send_lock:
                    await send_json(websocket, error_message("route_failed", detail))
    except WebSocketDisconnect:
        server_events.add("websocket_disconnected", token=token)
        return
    finally:
        if auto_task is not None:
            auto_task.cancel()
            with suppress(asyncio.CancelledError):
                await auto_task
        if media_task is not None:
            media_task.cancel()
            with suppress(asyncio.CancelledError, WebSocketDisconnect):
                await media_task
        await session_manager.close(token)
        server_events.add("session_closed", token=token)


async def auto_frame_loop(
    websocket: WebSocket,
    session: Any,
    scheduler: AdaptiveFrameScheduler,
    send_lock: asyncio.Lock,
    frame_lock: asyncio.Lock,
) -> None:
    last_metadata_at = 0.0
    last_empty_frame_at = 0.0
    while True:
        await asyncio.sleep(scheduler.current_interval_seconds())
        try:
            now = time.monotonic()
            include_metadata = (now - last_metadata_at) >= config.auto_meta_interval_seconds
            send_empty_frame_done = include_metadata or (
                now - last_empty_frame_at
            ) >= config.auto_empty_frame_interval_seconds
            result = await send_frame(
                websocket,
                session,
                send_lock,
                frame_lock,
                immediate=False,
                include_metadata=include_metadata,
                send_empty_frame_done=send_empty_frame_done,
            )
            scheduler.record_frame(result)
            sent_at = time.monotonic()
            if result.metadata_sent:
                last_metadata_at = sent_at
            if result.frame_done_sent:
                last_empty_frame_at = sent_at
        except WebSocketDisconnect:
            return
        except Exception as exc:
            if _is_transient_browser_error(exc):
                server_events.add("auto_frame_skipped", token=session.token, detail=_short_error_detail(exc))
                await asyncio.sleep(0.2)
                continue
            async with send_lock:
                await send_json(websocket, error_message("auto_frame_failed", _short_error_detail(exc)))
            await asyncio.sleep(1.0)


async def send_frame(
    websocket: WebSocket,
    session: Any,
    send_lock: asyncio.Lock,
    frame_lock: asyncio.Lock,
    *,
    immediate: bool = False,
    include_metadata: bool = True,
    send_empty_frame_done: bool = True,
) -> FrameSendResult:
    async with frame_lock:
        bundle = await session.capture_frame(
            include_page_meta=include_metadata,
            include_dom=include_metadata,
            suppress_tile_rects=session.active_media_rects(),
        )
        tiles_bytes = sum(len(tile.payload) for tile in bundle.tiles)
        metadata_sent = bundle.page_meta is not None
        dom_sent = bundle.dom_items is not None
        frame_done_needed = immediate or bool(bundle.tiles) or metadata_sent or send_empty_frame_done
        send_ms = 0

        if frame_done_needed or bundle.tiles or metadata_sent or dom_sent:
            async with send_lock:
                send_started_at = time.monotonic()
                if bundle.page_meta is not None:
                    await send_json(websocket, bundle.page_meta)
                if bundle.dom_items is not None:
                    await send_json(websocket, {"type": "dom_map", "frame_id": bundle.frame_id, "items": bundle.dom_items})

                    offer = media_bridge.build_offer(bundle.frame_id, bundle.dom_items)
                    if offer is not None:
                        offer["target_fps"] = session.effective_media_fps()
                        await send_json(websocket, offer)

                for tile in bundle.tiles:
                    await send_binary_packet(websocket, tile.header(), tile.payload)

                send_ms = int((time.monotonic() - send_started_at) * 1000)
                if frame_done_needed:
                    await send_json(
                        websocket,
                        {
                            "type": "frame_done",
                            "frame_id": bundle.frame_id,
                            "changed_tiles": len(bundle.tiles),
                            "loading": bundle.loading,
                            "dom_changed": bundle.dom_changed,
                            "capture_ms": bundle.capture_ms,
                            "send_ms": send_ms,
                            "tiles_bytes": tiles_bytes,
                            "metadata_sent": metadata_sent,
                            "dom_sent": dom_sent,
                            "mode": _frame_mode(immediate, include_metadata),
                            "immediate": immediate,
                        },
                    )

    return FrameSendResult(
        changed_tiles=len(bundle.tiles),
        loading=bundle.loading,
        dom_changed=bundle.dom_changed,
        capture_ms=bundle.capture_ms,
        immediate=immediate,
        frame_done_sent=frame_done_needed,
        metadata_sent=metadata_sent,
        tiles_bytes=tiles_bytes,
        send_ms=send_ms,
    )


def _frame_mode(immediate: bool, include_metadata: bool) -> str:
    if immediate:
        return "immediate_full"
    if include_metadata:
        return "auto_meta"
    return "auto_tile"


async def media_frame_loop(
    websocket: WebSocket,
    session: Any,
    send_lock: asyncio.Lock,
    frame_lock: asyncio.Lock,
) -> None:
    while session.media_stream_active:
        active = session.active_media
        fps = min(session.effective_media_fps(), active.fps if active is not None else session.effective_media_fps())
        await asyncio.sleep(1.0 / max(1.0, fps))
        try:
            async with frame_lock:
                bundle = await session.capture_media_frame()
            if bundle is None:
                break
            async with send_lock:
                await send_binary_packet(websocket, bundle.header, bundle.payload)
        except WebSocketDisconnect:
            return
        except Exception as exc:
            if _is_transient_browser_error(exc):
                server_events.add("media_frame_skipped", token=session.token, detail=_short_error_detail(exc))
                await asyncio.sleep(0.2)
                continue
            async with send_lock:
                await send_json(websocket, error_message("media_frame_failed", _short_error_detail(exc)))
            await asyncio.sleep(0.5)

    stopped = session.stop_media()
    if stopped is not None:
        async with send_lock:
            await send_json(websocket, {"type": "media_stop", **stopped})
