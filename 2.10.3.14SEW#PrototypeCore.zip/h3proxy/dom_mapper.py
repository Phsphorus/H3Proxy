from __future__ import annotations

from typing import Any


DOM_MAP_SCRIPT = """
() => {
  const selectors = [
    ["a[href]", "link"],
    ["button", "button"],
    ["input", "input"],
    ["textarea", "input"],
    ["select", "input"],
    ["[contenteditable='true']", "input"],
    ["[role='button']", "button"],
    ["[onclick]", "button"],
    ["canvas", "canvas"],
    ["video", "video"],
    ["audio", "audio"]
  ];
  const seen = new Set();
  const items = [];
  let nextId = 1;

  function visible(el, rect) {
    const style = window.getComputedStyle(el);
    return rect.width >= 2 &&
      rect.height >= 2 &&
      style.visibility !== "hidden" &&
      style.display !== "none" &&
      Number(style.opacity || "1") > 0.05;
  }

  function textFor(el) {
    const value =
      el.innerText ||
      el.getAttribute("aria-label") ||
      el.getAttribute("title") ||
      el.getAttribute("alt") ||
      el.getAttribute("placeholder") ||
      "";
    return String(value).replace(/\\s+/g, " ").trim().slice(0, 120);
  }

  for (const [selector, kind] of selectors) {
    for (const el of Array.from(document.querySelectorAll(selector))) {
      if (seen.has(el)) {
        continue;
      }
      seen.add(el);
      const rect = el.getBoundingClientRect();
      if (!visible(el, rect)) {
        continue;
      }
      const item = {
        id: nextId++,
        kind,
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.width),
        h: Math.round(rect.height),
        visible: true,
        enabled: !Boolean(el.disabled),
        focused: document.activeElement === el,
        text: textFor(el),
        title: el.getAttribute("title") || "",
        aria_label: el.getAttribute("aria-label") || ""
      };
      if (el.href) {
        item.href = el.href;
      }
      if (el.placeholder) {
        item.placeholder = el.placeholder;
      }
      if (el.tagName === "INPUT") {
        item.input_type = el.getAttribute("type") || "text";
        if (["checkbox", "radio"].includes(item.input_type)) {
          item.checked = Boolean(el.checked);
        }
      }
      if (kind === "input") {
        item.value_preview = String(el.value || "").slice(0, 64);
      }
      if (kind === "video" || kind === "audio") {
        item.media_hint = kind + "_element";
      }
      if (kind === "canvas") {
        item.media_hint = "canvas_region";
      }
      items.push(item);
    }
  }
  return items;
}
"""


class DomMapper:
    async def extract(self, page: Any, viewport: dict[str, int]) -> list[dict[str, Any]]:
        raw_items = await page.evaluate(DOM_MAP_SCRIPT)
        width = int(viewport["width"])
        height = int(viewport["height"])
        clean_items: list[dict[str, Any]] = []

        for raw in raw_items:
            item = dict(raw)
            x = max(0, min(width, int(item.get("x", 0))))
            y = max(0, min(height, int(item.get("y", 0))))
            w = max(0, min(width - x, int(item.get("w", 0))))
            h = max(0, min(height - y, int(item.get("h", 0))))
            if w <= 0 or h <= 0:
                continue
            item["x"] = x
            item["y"] = y
            item["w"] = w
            item["h"] = h
            clean_items.append(item)

        return clean_items
