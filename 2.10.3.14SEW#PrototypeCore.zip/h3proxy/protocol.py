from __future__ import annotations

import json
import struct
from dataclasses import dataclass
from typing import Any


JSON_SEPARATORS = (",", ":")
HEADER_LENGTH_STRUCT = struct.Struct(">I")


def compact_json(data: dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=True, separators=JSON_SEPARATORS)


@dataclass(frozen=True)
class BinaryPacket:
    header: dict[str, Any]
    payload: bytes

    def pack(self) -> bytes:
        header_bytes = compact_json(self.header).encode("utf-8")
        return HEADER_LENGTH_STRUCT.pack(len(header_bytes)) + header_bytes + self.payload


def pack_binary_message(header: dict[str, Any], payload: bytes) -> bytes:
    return BinaryPacket(header=header, payload=payload).pack()


async def send_json(websocket: Any, message: dict[str, Any]) -> None:
    await websocket.send_text(compact_json(message))


async def send_binary_packet(websocket: Any, header: dict[str, Any], payload: bytes) -> None:
    await websocket.send_bytes(pack_binary_message(header, payload))


def error_message(code: str, detail: str, *, fatal: bool = False) -> dict[str, Any]:
    return {"type": "error", "code": code, "detail": detail, "fatal": fatal}


def status_message(state: str, **extra: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"type": "status", "state": state}
    payload.update(extra)
    return payload
