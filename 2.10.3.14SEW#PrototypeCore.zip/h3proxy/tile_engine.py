from __future__ import annotations

import hashlib
import io
import math
from dataclasses import dataclass
from PIL import Image, ImageFilter, ImageStat


@dataclass(frozen=True)
class TilePacket:
    frame_id: int
    tile_id: str
    x: int
    y: int
    width: int
    height: int
    image_format: str
    tile_hash: str
    payload: bytes

    def header(self) -> dict[str, object]:
        return {
            "type": "tile",
            "frame_id": self.frame_id,
            "tile_id": self.tile_id,
            "x": self.x,
            "y": self.y,
            "w": self.width,
            "h": self.height,
            "format": self.image_format,
            "hash": self.tile_hash,
            "payload_len": len(self.payload),
        }


class TileEngine:
    def __init__(self, tile_width: int = 100, tile_height: int = 60, jpeg_quality: int = 64) -> None:
        self.tile_width = tile_width
        self.tile_height = tile_height
        self.jpeg_quality = jpeg_quality

    def build_changed_tiles(
        self,
        screenshot_png: bytes,
        previous_hashes: dict[str, str],
        frame_id: int,
        quality: str = "normal",
        suppress_rects: list[dict[str, int]] | None = None,
    ) -> list[TilePacket]:
        image = Image.open(io.BytesIO(screenshot_png)).convert("RGB")
        width, height = image.size
        columns = math.ceil(width / self.tile_width)
        rows = math.ceil(height / self.tile_height)
        changed: list[TilePacket] = []

        for row in range(rows):
            for column in range(columns):
                x = column * self.tile_width
                y = row * self.tile_height
                w = min(self.tile_width, width - x)
                h = min(self.tile_height, height - y)
                if w <= 0 or h <= 0:
                    continue
                if self._tile_suppressed(x, y, w, h, suppress_rects or []):
                    continue

                tile_id = f"{column}:{row}"
                crop = image.crop((x, y, x + w, y + h))
                tile_hash = self._hash_tile(crop)
                if previous_hashes.get(tile_id) == tile_hash:
                    continue

                image_format = self._choose_format(crop, quality)
                payload = self._encode(crop, image_format)
                previous_hashes[tile_id] = tile_hash
                changed.append(
                    TilePacket(
                        frame_id=frame_id,
                        tile_id=tile_id,
                        x=x,
                        y=y,
                        width=w,
                        height=h,
                        image_format=image_format,
                        tile_hash=tile_hash,
                        payload=payload,
                    )
                )

        return changed

    def _hash_tile(self, image: Image.Image) -> str:
        digest = hashlib.blake2s(image.tobytes(), digest_size=6).hexdigest()
        return f"b2s_{digest}"

    def _tile_suppressed(self, x: int, y: int, w: int, h: int, rects: list[dict[str, int]]) -> bool:
        if not rects:
            return False

        tile_area = max(1, w * h)
        center_x = x + w / 2
        center_y = y + h / 2
        for rect in rects:
            rx = int(rect.get("x", 0))
            ry = int(rect.get("y", 0))
            rw = int(rect.get("w", 0))
            rh = int(rect.get("h", 0))
            if rw <= 0 or rh <= 0:
                continue
            if rx <= center_x < rx + rw and ry <= center_y < ry + rh:
                return True

            ix = max(0, min(x + w, rx + rw) - max(x, rx))
            iy = max(0, min(y + h, ry + rh) - max(y, ry))
            if (ix * iy) / tile_area >= 0.8:
                return True
        return False

    def _choose_format(self, image: Image.Image, quality: str) -> str:
        mode = quality.strip().lower()
        if mode in {"force_jpeg", "jpeg", "jpg", "low", "video"}:
            return "jpeg"
        if mode in {"sharp", "text", "sharp/text"}:
            return "png"
        return "png" if self._looks_like_ui_or_text(image) else "jpeg"

    def _looks_like_ui_or_text(self, image: Image.Image) -> bool:
        small = image.resize((max(1, image.width // 2), max(1, image.height // 2)))
        colors = small.getcolors(maxcolors=4096)
        unique_colors = len(colors) if colors is not None else 4096
        if unique_colors <= 192:
            return True

        gray = small.convert("L")
        edges = gray.filter(ImageFilter.FIND_EDGES)
        edge_mean = ImageStat.Stat(edges).mean[0]
        return edge_mean >= 18

    def _encode(self, image: Image.Image, image_format: str) -> bytes:
        output = io.BytesIO()
        if image_format == "png":
            image.save(output, format="PNG", optimize=True)
        else:
            image.save(output, format="JPEG", quality=self.jpeg_quality, optimize=True)
        return output.getvalue()
