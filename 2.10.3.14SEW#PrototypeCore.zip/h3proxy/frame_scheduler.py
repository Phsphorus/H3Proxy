from __future__ import annotations

import time
from dataclasses import dataclass

from .config import ServerConfig


@dataclass
class FrameSendResult:
    changed_tiles: int
    loading: bool
    dom_changed: bool
    capture_ms: int
    immediate: bool = False
    frame_done_sent: bool = True
    metadata_sent: bool = True
    tiles_bytes: int = 0
    send_ms: int = 0


class AdaptiveFrameScheduler:
    """Adaptive page-mode scheduler for ordinary webpage motion.

    Media mode is a separate path. This scheduler keeps CSS animations, GIFs,
    canvas changes, blinking cursors, and dynamic page updates moving while
    backing off when the page is visually stable.
    """

    def __init__(self, config: ServerConfig) -> None:
        self.config = config
        self.client_max_page_fps = config.protocol_max_fps
        self.last_input_at = 0.0
        self.unchanged_streak = 0
        self.animation_streak = 0
        self.last_loading = False
        self.last_dom_changed = False
        self.last_capture_ms = 0

    def mark_input(self) -> None:
        self.last_input_at = time.monotonic()
        self.unchanged_streak = 0

    def set_client_max_page_fps(self, fps: float | None) -> None:
        if fps is None:
            self.client_max_page_fps = self.config.protocol_max_fps
            return
        self.client_max_page_fps = max(0.2, min(self.config.protocol_max_fps, float(fps)))

    def record_frame(self, result: FrameSendResult) -> None:
        self.last_loading = result.loading
        self.last_dom_changed = result.dom_changed
        self.last_capture_ms = result.capture_ms

        changed = result.changed_tiles > 0 or result.dom_changed or result.loading
        recent_input = self.is_recent_input()

        if changed:
            self.unchanged_streak = 0
        else:
            self.unchanged_streak += 1

        if changed and not recent_input and not result.loading and not result.immediate:
            self.animation_streak += 1
        elif not changed:
            self.animation_streak = 0

    def is_recent_input(self) -> bool:
        return (time.monotonic() - self.last_input_at) <= self.config.recent_input_seconds

    def current_fps(self) -> float:
        if self.last_loading or self.last_dom_changed or self.is_recent_input():
            fps = self.config.active_fps
        elif self.animation_streak >= 2:
            fps = self.config.animation_fps
        else:
            fps = self.config.idle_fps

        if self.unchanged_streak >= self.config.unchanged_deep_backoff_after:
            fps = min(fps, 0.5)
        elif self.unchanged_streak >= self.config.unchanged_backoff_after:
            fps = min(fps, 1.0)

        # Panic cap: if capture/encode is already eating a large chunk of time,
        # lower the target before the server starts queueing stale frames.
        if self.last_capture_ms >= 350:
            fps = min(fps, 3.0)
        elif self.last_capture_ms >= 180:
            fps = min(fps, 6.0)

        return max(0.2, min(fps, self.client_max_page_fps, self.config.protocol_max_fps))

    def current_interval_seconds(self) -> float:
        return 1.0 / self.current_fps()
