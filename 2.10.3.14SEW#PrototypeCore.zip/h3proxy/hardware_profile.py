from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_HARDWARE_PROFILES: dict[str, Any] = {
    "profiles": [
        {
            "profile": "New 3DS LL / XL",
            "ram": {
                "safe_budget_bytes": 104857600,
                "aggressive_budget_bytes": 130023424,
                "dom_map_cap_bytes": 524288,
                "text_map_cap_bytes": 1048576,
                "metadata_total_cap_bytes": 2097152,
                "decode_staging_cap_bytes": 2097152,
                "compressed_tile_queue_cap_bytes": 4194304,
                "mjpeg_queue_cap_bytes": 4194304,
                "input_queue_cap_bytes": 262144,
            },
            "vram": {
                "budget_bytes": 6291456,
                "page_tile_format": "RGB565",
                "ui_format": "RGBA8",
                "tile_width": 100,
                "tile_height": 60,
                "tile_rgb565_bytes": 12000,
                "visible_tiles": 16,
                "visible_tiles_bytes": 192000,
                "soft_page_tile_limit": 96,
                "hard_page_tile_limit": 256,
                "bottom_ui_rgba8_bytes": 307200,
                "cursor_overlay_bytes": 16384,
            },
            "sd": {
                "profile_config_bytes": 65536,
                "bookmark_store_bytes": 262144,
                "history_store_bytes": 1048576,
                "optional_tile_cache_bytes": 67108864,
                "download_staging_bytes": 134217728,
            },
            "input": {
                "bottom_screen_width": 320,
                "bottom_screen_height": 240,
                "bottom_dock_height": 60,
                "page_pad_height": 180,
                "browser_viewport_width": 400,
                "browser_viewport_height": 240,
            },
        }
    ]
}


def profiles_path() -> Path:
    return Path(__file__).resolve().parents[1] / "Configs" / "H3Proxy" / "hardware_profiles.json"


def load_hardware_profiles() -> dict[str, Any]:
    path = profiles_path()
    if not path.exists():
        return deepcopy(DEFAULT_HARDWARE_PROFILES)
    with path.open("r", encoding="utf-8") as handle:
        loaded = json.load(handle)
    if not isinstance(loaded, dict) or not isinstance(loaded.get("profiles"), list):
        return deepcopy(DEFAULT_HARDWARE_PROFILES)
    return loaded
